# Log συλλογής — 2026-09-29

- Εγγραφές που μαζεύτηκαν: **36**
- Εκδηλώσεις στη σελίδα: **4** (Βόλος 4, Πήλιο 0) + 6 ταινίες
- Βρέθηκαν σε πολλές πηγές: **1**
- Περασμένες (δεν εμφανίζονται): **15**
- Απορρίφθηκαν: **10**

## Απόδοση ανά πηγή σε αυτή την εκτέλεση

| Πηγή | Εγγραφές | Στη σελίδα ή στις περασμένες |
|---|---:|---:|
| ΠΘ /events | 30 | 20 |
| CinePortal | 6 | 6 |

## Σφάλματα πηγών

- `collect_artandlife`: δεν υπάρχει σημερινή λήψη (δεν έχει ζωντανή λήψη ή απέτυχε)
- `collect_more`: δεν υπάρχει σημερινή λήψη (δεν έχει ζωντανή λήψη ή απέτυχε)
- `collect_fever`: δεν υπάρχει σημερινή λήψη (δεν έχει ζωντανή λήψη ή απέτυχε)
- `collect_public_listing`: δεν υπάρχει σημερινή λήψη (δεν έχει ζωντανή λήψη ή απέτυχε)
- `collect_public_tour`: δεν υπάρχει σημερινή λήψη (δεν έχει ζωντανή λήψη ή απέτυχε)
- `collect_mood`: δεν υπάρχει σημερινή λήψη (δεν έχει ζωντανή λήψη ή απέτυχε)
- `collect_ts_pages`: δεν υπάρχει σημερινή λήψη (δεν έχει ζωντανή λήψη ή απέτυχε)
- `collect_aogoc`: δεν υπάρχει σημερινή λήψη (δεν έχει ζωντανή λήψη ή απέτυχε)

## Υποβολές και feeds διοργανωτών

- Καμία εγκεκριμένη υποβολή feed σε αυτή την εκτέλεση.

## Κατάσταση πηγών

| Κατάσταση | Πηγή | Σημείωση |
|---|---|---|
| ok | [Art&Life, Βόλος](https://www.artandlife.gr/volos/events) | Θέατρο, live, συναυλίες, σινεμά. Δομημένη λίστα. |
| ok | [CinePortal, Βόλος](https://cineportal.gr/bolos/) | Ώρες προβολής ανά ημέρα και αίθουσα (Village, Εξωραϊστική). |
| ok | [Περιφέρεια Θεσσαλίας, εφαρμογή εκδηλώσεων](https://app.thessaly.gov.gr/TourismEventsApp) | Φίλτρο ΠΕ Μαγνησίας. Η βασική πηγή για το Πήλιο. |
| ok | [Πανεπιστήμιο Θεσσαλίας, /events](https://www.uth.gr/events) | Κεντρική λίστα μόνο, χωρίς τα τμήματα. Δίνει ημερομηνία έναρξης· η λήξη βγαίνει από την περίληψη με κανόνα. |
| ok | [TicketServices](https://www.ticketservices.gr/) | Ενιαία λίστα όλης της Ελλάδας με χώρο δίπλα σε κάθε εκδήλωση. Φίλτρο «ΒΟΛΟΣ/ΒΟΛΟΥ» στον χώρο. |
| ok | [More.com (και Ticket365)](https://www.more.com/gr-el/tickets/) | Η σελίδα /gr-el/tickets φέρνει όλη τη λίστα σε στατική μορφή, με φίλτρο «Μαγνησία: Βόλος, Πήλιο, Σκιάθος». Το ticket365.gr ανακατευθύνει εδώ. |
| ok | [Public.gr Tickets (κατάλογος More.com)](https://tickets.public.gr/gr-el/tickets/) | Ίδιος κατάλογος με το More.com. Εδώ βρέθηκαν οι προβολές στο Αχίλλειον (CineDoc Caravan). |
| ok | [Public.gr, σελίδες περιοδειών](https://tickets.public.gr/gr-el/tickets/standupcomedy/lampros-fisfis-poly-kalytera-tora-on-tour/) | Για κάθε «Πολλαπλοί χώροι» της λίστας ο crawler ανοίγει τη σελίδα της περιοδείας, όπου κάθε σταθμός έχει πόλη, χώρο, ώρα και τιμή. Στο More.com οι ίδιες σελίδες απαγορεύουν τα bots, στο public.gr επιτρέπονται. |
| ok | [Mood (musicofourdesire)](https://events.musicofourdesire.com/events/Volos) | Δομημένη λίστα συναυλιών για τον Βόλο, με ώρα και χώρο. Έφερε Ex Silentio, VHS Live, Fann, Buzz Capitano και ώρες που έλειπαν. |
| ok | [TicketServices, μεμονωμένες σελίδες](https://www.ticketservices.gr/event/dimotiko-theatro-volou-vira-tis-agkires/?lang=el) | Περασμένες εκδηλώσεις φεύγουν από την κεντρική λίστα αλλά η σελίδα τους μένει: εδώ κρατιούνται στο αρχείο. Η «Βίρα τις... άγκυρες!» ήταν στις 3/10/2025. |
| ok | [Fever](https://feverup.com/el/volos-ellada) | Candlelight στο Domotel Xenia. Η σελίδα της πόλης αναμειγνύει και Θεσσαλονίκη: φίλτρο στον χώρο. |
| blocked | [Ticketmaster.gr](https://www.ticketmaster.gr/) | Μπλοκάρει τα bots. |
| robots | Ticketportal.gr, Ticketseller.gr | Απαγορεύουν ρητά την αυτόματη πρόσβαση (robots.txt). |
| irrelevant | [TicketBOX, TicketPlus](https://www.ticketbox.gr/) | Λειτουργούν, αλλά καλύπτουν Κέρκυρα, Κρήτη, Αθήνα, Μυτιλήνη. Τίποτα για Βόλο ή Πήλιο. |
| blocked | [Eventbrite](https://www.eventbrite.com/d/greece--volos/events/) | Σφάλμα 405 στα bots. Για την Ελλάδα κυρίως τουριστικά πακέτα· ελάχιστα για Βόλο και Πήλιο. |
| dead | Ticketpro.gr | Ληγμένο domain που ανακατευθύνει σε σελίδα καζίνο. Αποκλείεται. |
| ok | [Όλη η Ελλάδα ένας Πολιτισμός, αναζήτηση «volos»](https://allofgreeceone.culture.gov.gr/en/?s=volos) | Αρχείο 2022–2026 για Αρχαίο Θέατρο Δημητριάδας και Αθανασάκειο. Η αναζήτηση φέρνει και άλλες πόλεις, που κόβει το φίλτρο. |
| sparse | [Δήμος Ζαγοράς-Μουρεσίου, Ατζέντα Εκδηλώσεων](https://www.dimos-zagoras-mouresiou.gr/fullcalendar) | Δομημένο ημερολόγιο 2015–2025 με ώρες και RSS (/ekdilwseis_feed). Αραιή ενημέρωση: τελευταία καταχώριση Ιούλιος 2025. |
| robots | [Δήμος Νοτίου Πηλίου](https://dnpiliou.gov.gr/) | Ενεργό site, με λίστα πανηγυριών του καλοκαιριού, αλλά το robots.txt απαγορεύει τα άρθρα. Χρειάζεται άδεια ή αποστολή feed. |
| ok | Φόρμα υποβολής (εκδήλωση, iCal, RSS, ιστοσελίδα) | Ό,τι εγκρίνει ο διαχειριστής εξάγεται ως submissions.json και διαβάζεται εδώ. Τα feeds iCal/RSS ανανεώνονται σε κάθε εκτέλεση. |
| removed | Ειδησεογραφικά, RSS Δήμου, ραδιόφωνα, τμήματα ΠΘ | Αφαιρέθηκαν: τα άρθρα θέλουν LLM για ημερομηνία και χώρο, τα τμήματα βγήκαν από το scope. |

## Απορρίψεις

Για να αλλάξεις μια απόφαση, πρόσθεσε στο `overrides.json`: `"<key>": {"match_url": "<url>", "area": "volos|pelion|reject"}`

### Εκτός Βόλου και Πηλίου (9)

- `81af978531` 2026-09-25 — **10ο Συνέδριο «Πρόληψη στην Υγεία της Γυναίκας» στο Πανεπιστήμιο Θεσσαλίας** —  — ΠΘ /events — /events/10o-synedrio-prolipsi-stin-ygeia-tis-gynaikas-sto-panepistimio-thessalias
- `c98845d103` 2026-09-25 — **Ευρωπαϊκή Βραδιά Ερευνητή 2026 στη Λαμία** —  — ΠΘ /events — /events/eyropaiki-bradia-ereyniti-2026-sti-lamia
- `d553da5c5c` 2026-09-18 — **Χτίζοντας γέφυρες: Μια ανοιχτή συνάντηση ενημέρωσης και γνωριμίας για νέα μέλη της φοιτητικής κοινότητας με αναπηρία ή/και ειδικές εκπαιδευτικές ανάγκες και για τις οικογένειές τους** —  — ΠΘ /events — /events/htizontas-gefyres-mia-anoihti-synantisi-enimerosis-kai-gnorimias-gia-nea-meli-tis-foititikis
- `dc19bd90ba` 2026-09-16 — **Αναγόρευση ως Επίτιμου Διδάκτορα του Τμήματος Ιατρικής για τον διεθνώς διακεκριμένο παιδονευροογκολόγο Στέργιο Ζαχαρούλη** —  — ΠΘ /events — /events/anagoreysi-os-epitimoy-didaktora-toy-tmimatos-iatrikis-gia-ton-diethnos-diakekrimeno
- `e845b16c56` 2026-07-10 — **Το Πανεπιστήμιο Θεσσαλίας συνδιοργανώνει το 18ο Διεθνές Συνέδριο Σπουδών Ντελέζ και Γκουατταρί στην Αθήνα** —  — ΠΘ /events — /events/panepistimio-thessalias-syndiorganonei-18o-diethnes-synedrio-spoydon-ntelez-kai-gkoyattari-stin
- `3cc9086c1e` 2026-07-07 — **Έξυπνες κοινότητες: το Πανεπιστήμιο Θεσσαλίας συμμετέχει σε ευρωπαϊκή πρωτοβουλία για τις δεξιότητες του μέλλοντος** —  — ΠΘ /events — /events/exypnes-koinotites-panepistimio-thessalias-symmetehei-se-eyropaiki-protoboylia-gia-tis-dexiotites
- `a90bc27c21` 2026-07-03 — **Το Πανεπιστήμιο Θεσσαλίας φιλοξενεί το διεθνές συνέδριο NICE-TEAS 2026 Europe** —  — ΠΘ /events — /events/panepistimio-thessalias-filoxenei-diethnes-synedrio-nice-teas-2026-europe
- `7a0ef8e6ad` 2026-07-01 — **Το 8ο Διεθνές Συνέδριο για τη Βιώσιμη Κινητικότητα CSuM2026 στη Σκύρο** —  — ΠΘ /events — /events/8o-diethnes-synedrio-gia-ti-biosimi-kinitikotita-csum2026-sti-skyro
- `abae8652e5` 2026-07-01 — **Ακαδημαϊκή Ημέρα Erasmus+ Staff Mobility Week στο Τμήμα Επιστήμης Ζωικής Παραγωγής** —  — ΠΘ /events — /events/akadimaiki-imera-erasmus-staff-mobility-week-sto-tmima-epistimis-zoikis-paragogis

### Άγνωστη τοποθεσία (1)

- `6f2691ccfe` 2026-07-09 — **Ορκωμοσίες της Σχολής Γεωπονικών Επιστημών του Πανεπιστημίου Θεσσαλίας - Ιούλιος 2026** —  — ΠΘ /events — /events/orkomosies-tis-sholis-geoponikon-epistimon-toy-panepistimioy-thessalias-ioylios-2026

## Περασμένες εκδηλώσεις (δεν εμφανίζονται στη σελίδα)

- 2026-09-21 — Εκδήλωση Υποδοχής Πρωτοετών Φοιτητών/τριών στο Τμήμα Νοσηλευτικής —  — ΠΘ /events
- 2026-09-03 — HER 2026: Διήμερο για τη γυναικεία υγεία, την επιστημονική ενημέρωση και τον ανοιχτό διάλογο —  — ΠΘ /events
- 2026-07-27 — Τελετές ορκωμοσίας της Πολυτεχνικής Σχολής του Πανεπιστημίου Θεσσαλίας —  — ΠΘ /events
- 2026-07-23 — Φεστιβάλ Πάου 2026: πέντε ημέρες μουσικής και πολιτισμού στο Συνεδριακό και Πολιτιστικό Κέντρο του Πανεπιστημίου Θεσσαλίας —  — ΠΘ /events
- 2026-07-22 — Τελετές ορκωμοσίας της Σχολής Θετικών Επιστημών του Πανεπιστημίου Θεσσαλίας —  — ΠΘ /events
- 2026-07-21 — Τελετές ορκωμοσίας της Σχολής Ανθρωπιστικών και Κοινωνικών Επιστημών του Πανεπιστημίου Θεσσαλίας —  — ΠΘ /events
- 2026-07-20 — Τελετές Ορκωμοσιών Σχολής Επιστημών Υγείας (Ιούλιος 2026) —  — ΠΘ /events
- 2026-07-17 — Τελετές ορκωμοσίας της Σχολής Τεχνολογίας του Πανεπιστημίου Θεσσαλίας —  — ΠΘ /events, ΠΘ /events
- 2026-07-16 — Εκδήλωση για την ιστορία και την ανάδειξη των σανατορίων της Θεσσαλίας στη Δράκεια Πηλίου —  — ΠΘ /events
- 2026-07-13 — Δύο διεθνή workshops του έργου TWIN-RELECT στο Πανεπιστήμιο Θεσσαλίας —  — ΠΘ /events
- 2026-07-01 — Ημερίδα για σύγχρονες τεχνολογίες μέτρησης παροχής υδάτων και μετεωρολογικών παραμέτρων —  — ΠΘ /events
- 2026-06-30 — E-SPFdigit Workshop: Biosensing for Soil Health and Food Safety —  — ΠΘ /events
- 2026-06-27 — Διαδικτυακή ημερίδα για τα ηθικά και γραφειοκρατικά ζητήματα στην έρευνα με ασυνόδευτα ανήλικα παιδιά —  — ΠΘ /events
- 2026-06-26 — Pelion Summer Lab 2026: Πρόσκληση συμμετοχής στο δεκαήμερο διεθνές εργαστήριο «The Planet in the Port: Infrastructures & Undercurrents» (26/6-6/7, Νεοχώρι Πηλίου) —  — ΠΘ /events
- 2026-06-25 — Εναρκτήρια εκδήλωση του νέου κοινού Μεταπτυχιακού HERO-HEALTH του Πανεπιστημίου Θεσσαλίας και του Teachers College, Columbia University —  — ΠΘ /events
