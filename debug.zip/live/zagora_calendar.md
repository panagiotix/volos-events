Ατζέντα Εκδηλώσεων | Δήμος Ζαγοράς - Μουρεσίου

<!--//--><![CDATA[//><!--
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments)};gtag("js", new Date());gtag("set", "developer\_id.dMDhkMT", true);gtag("config", "UA-23407806-11", {"groups":"default","anonymize\_ip":true});
//--><!]]>

<!--//--><![CDATA[//><!--
(function ($) {
if (Drupal.Nucleus == undefined) {
Drupal.Nucleus = {};
}
Drupal.behaviors.skinMenuAction = {
attach: function (context) {
jQuery(".change-skin-button").click(function() {
parts = this.href.split("/");
style = parts[parts.length - 1];
jQuery.cookie("nucleus\_skin", style, {path: "/"});
window.location.reload();
return false;
});
}
}
})(jQuery);
//--><!]]>

<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, {"basePath":"\/","pathPrefix":"","setHasJsCookie":0,"ajaxPageState":{"theme":"tb\_corpal","theme\_token":"dT4dzc\_pd3sBWdQTDgU5vKSFMgxn-51i2Ry7InD7m9U","jquery\_version":"1.12","jquery\_version\_token":"c4y2Mq3EEwMh\_MBqgtaqF7WTrVzAo\_p9sI6gThF7cmY","js":{"0":1,"sites\/all\/modules\/eu\_cookie\_compliance\/js\/eu\_cookie\_compliance.min.js":1,"sites\/all\/modules\/addthis\/addthis.js":1,"sites\/all\/modules\/jquery\_update\/replace\/jquery\/1.12\/jquery.min.js":1,"misc\/jquery-extend-3.4.0.js":1,"misc\/jquery-html-prefilter-3.5.0-backport.js":1,"misc\/jquery.once.js":1,"misc\/drupal.js":1,"sites\/all\/modules\/jquery\_update\/js\/jquery\_browser.js":1,"sites\/all\/modules\/jquery\_update\/replace\/ui\/ui\/minified\/jquery.ui.core.min.js":1,"sites\/all\/modules\/jquery\_update\/replace\/ui\/ui\/minified\/jquery.ui.widget.min.js":1,"sites\/all\/modules\/jquery\_update\/replace\/ui\/ui\/minified\/jquery.ui.effect.min.js":1,"sites\/all\/modules\/eu\_cookie\_compliance\/js\/jquery.cookie-1.4.1.min.js":1,"sites\/all\/modules\/jquery\_update\/replace\/jquery.form\/4\/jquery.form.min.js":1,"sites\/all\/modules\/jquery\_update\/replace\/ui\/ui\/minified\/jquery.ui.mouse.min.js":1,"sites\/all\/modules\/jquery\_update\/replace\/ui\/ui\/minified\/jquery.ui.draggable.min.js":1,"sites\/all\/modules\/jquery\_update\/replace\/ui\/ui\/minified\/jquery.ui.droppable.min.js":1,"sites\/all\/modules\/jquery\_update\/replace\/ui\/ui\/minified\/jquery.ui.resizable.min.js":1,"sites\/all\/modules\/jquery\_update\/replace\/ui\/ui\/minified\/jquery.ui.effect-highlight.min.js":1,"sites\/all\/libraries\/fullcalendar\/fullcalendar.min.js":1,"sites\/all\/libraries\/fullcalendar\/gcal.js":1,"sites\/all\/modules\/fullcalendar\/js\/fullcalendar.library.js":1,"misc\/form-single-submit.js":1,"misc\/ajax.js":1,"sites\/all\/modules\/jquery\_update\/js\/jquery\_update.js":1,"sites\/all\/modules\/entityreference\/js\/entityreference.js":1,"sites\/all\/modules\/modal\_forms\/js\/modal\_forms\_login.js":1,"public:\/\/languages\/el\_pEbV8lvESjgwJbRm\_HKPwYqenSD\_YVximm4QNo9hf5o.js":1,"sites\/all\/libraries\/colorbox\/jquery.colorbox-min.js":1,"sites\/all\/modules\/colorbox\/js\/colorbox.js":1,"sites\/all\/modules\/colorbox\/styles\/default\/colorbox\_style.js":1,"sites\/all\/modules\/colorbox\/js\/colorbox\_load.js":1,"sites\/all\/modules\/colorbox\/js\/colorbox\_inline.js":1,"misc\/progress.js":1,"sites\/all\/modules\/ctools\/js\/modal.js":1,"sites\/all\/modules\/modal\_forms\/js\/modal\_forms\_popup.js":1,"sites\/all\/modules\/fullcalendar\/js\/fullcalendar.fullcalendar.js":1,"sites\/all\/modules\/jcarousel\/js\/jquery.jcarousel.min.js":1,"sites\/all\/modules\/jcarousel\/js\/jcarousel.js":1,"sites\/all\/modules\/google\_analytics\/googleanalytics.js":1,"https:\/\/www.googletagmanager.com\/gtag\/js?id=UA-23407806-11":1,"1":1,"sites\/all\/modules\/rua\/js\/jquery.rua.js":1,"2":1,"sites\/all\/modules\/extlink\/js\/extlink.js":1,"sites\/all\/modules\/fullcalendar\/js\/fullcalendar.views.js":1,"sites\/all\/libraries\/superfish\/jquery.hoverIntent.minified.js":1,"sites\/all\/libraries\/superfish\/sfsmallscreen.js":1,"sites\/all\/libraries\/superfish\/supposition.js":1,"sites\/all\/libraries\/superfish\/superfish.js":1,"sites\/all\/libraries\/superfish\/supersubs.js":1,"sites\/all\/modules\/superfish\/superfish.js":1,"sites\/all\/themes\/nucleus\/nucleus\/js\/jquery.cookie.js":1,"sites\/all\/themes\/tb\_corpal\/js\/jquery.matchHeights.min.js":1,"sites\/all\/themes\/tb\_corpal\/js\/jquery.mousewheel.js":1,"sites\/all\/themes\/tb\_corpal\/js\/jquery.jscrollpane.min.js":1,"sites\/all\/themes\/tb\_corpal\/js\/tb.plugins.js":1,"sites\/all\/themes\/tb\_corpal\/js\/tb\_corpal.js":1,"sites\/all\/themes\/tb\_corpal\/js\/tb\_responsive.js":1},"css":{"modules\/system\/system.base.css":1,"modules\/system\/system.menus.css":1,"modules\/system\/system.messages.css":1,"modules\/system\/system.theme.css":1,"sites\/all\/themes\/nucleus\/nucleus\/css\/base.css":1,"misc\/ui\/jquery.ui.core.css":1,"misc\/ui\/jquery.ui.theme.css":1,"misc\/ui\/jquery.ui.resizable.css":1,"sites\/all\/libraries\/fullcalendar\/fullcalendar.css":1,"sites\/all\/libraries\/fullcalendar\/fullcalendar.print.css":1,"modules\/aggregator\/aggregator.css":1,"modules\/book\/book.css":1,"modules\/comment\/comment.css":1,"modules\/field\/theme\/field.css":1,"modules\/node\/node.css":1,"modules\/poll\/poll.css":1,"modules\/search\/search.css":1,"modules\/user\/user.css":1,"sites\/all\/modules\/extlink\/css\/extlink.css":1,"sites\/all\/modules\/views\/css\/views.css":1,"sites\/all\/modules\/colorbox\/styles\/default\/colorbox\_style.css":1,"sites\/all\/modules\/ctools\/css\/ctools.css":1,"sites\/all\/modules\/ctools\/css\/modal.css":1,"sites\/all\/modules\/modal\_forms\/css\/modal\_forms\_popup.css":1,"sites\/all\/modules\/fullcalendar\/css\/fullcalendar.theme.css":1,"sites\/all\/modules\/jcarousel\/skins\/default\/jcarousel-default.css":1,"sites\/all\/modules\/eu\_cookie\_compliance\/css\/eu\_cookie\_compliance.css":1,"sites\/all\/themes\/tb\_corpal\/css\/views.css":1,"sites\/all\/modules\/addtoany\/addtoany.css":1,"sites\/all\/libraries\/superfish\/css\/superfish.css":1,"public:\/\/ctools\/css\/8695a9d3e23511e74e4cde79b7ae1666.css":1,"sites\/all\/themes\/nucleus\/nucleus\/css\/messages.css":1,"sites\/all\/themes\/tb\_corpal\/css\/html-elements.css":1,"sites\/all\/themes\/tb\_corpal\/css\/forms.css":1,"sites\/all\/themes\/tb\_corpal\/css\/page.css":1,"sites\/all\/themes\/tb\_corpal\/css\/articles.css":1,"sites\/all\/themes\/tb\_corpal\/css\/comments.css":1,"sites\/all\/themes\/tb\_corpal\/css\/forum.css":1,"sites\/all\/themes\/tb\_corpal\/css\/fields.css":1,"sites\/all\/themes\/tb\_corpal\/css\/blocks.css":1,"sites\/all\/themes\/tb\_corpal\/css\/navigation.css":1,"sites\/all\/themes\/tb\_corpal\/css\/fonts.css":1,"sites\/all\/themes\/tb\_corpal\/css\/jquery.jscrollpane.css":1,"sites\/all\/themes\/tb\_corpal\/css\/css3.css":1,"sites\/all\/themes\/nucleus\/nucleus\/css\/responsive\/responsive.css":1,"sites\/all\/themes\/tb\_corpal\/css\/print.css":1,"sites\/all\/themes\/tb\_corpal\/css\/screens\/mobile.css":1,"sites\/all\/themes\/tb\_corpal\/css\/screens\/mobile-vertical.css":1,"sites\/all\/themes\/tb\_corpal\/css\/screens\/tablet-vertical.css":1,"sites\/all\/themes\/tb\_corpal\/css\/screens\/tablet.css":1,"sites\/all\/themes\/tb\_corpal\/css\/screens\/layout-normal.css":1,"sites\/all\/themes\/tb\_corpal\/css\/superfish\/corpal.css":1,"sites\/all\/themes\/nucleus\/nucleus\/css\/ie7.css":1,"sites\/all\/themes\/nucleus\/nucleus\/css\/ie.css":1,"sites\/all\/themes\/tb\_corpal\/css\/ie.css":1,"sites\/all\/themes\/tb\_corpal\/css\/ie8.css":1,"public:\/\/nucleus\/grid-fixed-24-1008px.css":1,"sites\/all\/themes\/tb\_corpal\/skins\/cyan\/style.css":1}},"colorbox":{"opacity":"0.85","current":"{current} of {total}","previous":"\u00ab Prev","next":"Next \u00bb","close":"\u039a\u03bb\u03b5\u03af\u03c3\u03b9\u03bc\u03bf","maxWidth":"98%","maxHeight":"98%","fixed":true,"mobiledetect":true,"mobiledevicewidth":"480px","file\_public\_path":"\/sites\/default\/files","specificPagesDefaultValue":"admin\*\nimagebrowser\*\nimg\_assist\*\nimce\*\nnode\/add\/\*\nnode\/\*\/edit\nprint\/\*\nprintpdf\/\*\nsystem\/ajax\nsystem\/ajax\/\*"},"jcarousel":{"ajaxPath":"\/jcarousel\/ajax\/views","carousels":{"jcarousel-dom-1":{"view\_options":{"view\_args":"","view\_path":"fullcalendar","view\_base\_path":null,"view\_display\_id":"block","view\_name":"gallery","jcarousel\_dom\_id":1},"wrap":"circular","skin":"default","autoPause":1,"start":1,"selector":".jcarousel-dom-1"}}},"CToolsModal":{"loadingText":"\u03a6\u03bf\u03c1\u03c4\u03ce\u03bd\u03b5\u03b9...","closeText":"Close Window","closeImage":"\u003Cimg typeof=\u0022foaf:Image\u0022 src=\u0022https:\/\/www.dimos-zagoras-mouresiou.gr\/sites\/all\/modules\/ctools\/images\/icon-close-window.png\u0022 alt=\u0022\u039a\u03bb\u03b5\u03af\u03c3\u03b9\u03bc\u03bf \u03c0\u03b1\u03c1\u03ac\u03b8\u03c5\u03c1\u03bf\u03c5\u0022 title=\u0022\u039a\u03bb\u03b5\u03af\u03c3\u03b9\u03bc\u03bf \u03c0\u03b1\u03c1\u03ac\u03b8\u03c5\u03c1\u03bf\u03c5\u0022 \/\u003E","throbber":"\u003Cimg typeof=\u0022foaf:Image\u0022 src=\u0022https:\/\/www.dimos-zagoras-mouresiou.gr\/sites\/all\/modules\/ctools\/images\/throbber.gif\u0022 alt=\u0022\u03a6\u03cc\u03c1\u03c4\u03c9\u03c3\u03b7\u0022 title=\u0022\u03a6\u03bf\u03c1\u03c4\u03ce\u03bd\u03b5\u03b9...\u0022 \/\u003E"},"modal-popup-small":{"modalSize":{"type":"fixed","width":300,"height":300},"modalOptions":{"opacity":0.84999999999999997779553950749686919152736663818359375,"background":"#000"},"animation":"fadeIn","modalTheme":"ModalFormsPopup","throbber":"\u003Cimg typeof=\u0022foaf:Image\u0022 src=\u0022https:\/\/www.dimos-zagoras-mouresiou.gr\/sites\/all\/modules\/modal\_forms\/images\/loading\_animation.gif\u0022 alt=\u0022\u03a6\u03bf\u03c1\u03c4\u03ce\u03bd\u03b5\u03b9...\u0022 title=\u0022\u03a6\u03cc\u03c1\u03c4\u03c9\u03c3\u03b7\u0022 \/\u003E","closeText":"\u039a\u03bb\u03b5\u03af\u03c3\u03b9\u03bc\u03bf"},"modal-popup-medium":{"modalSize":{"type":"fixed","width":550,"height":450},"modalOptions":{"opacity":0.84999999999999997779553950749686919152736663818359375,"background":"#000"},"animation":"fadeIn","modalTheme":"ModalFormsPopup","throbber":"\u003Cimg typeof=\u0022foaf:Image\u0022 src=\u0022https:\/\/www.dimos-zagoras-mouresiou.gr\/sites\/all\/modules\/modal\_forms\/images\/loading\_animation.gif\u0022 alt=\u0022\u03a6\u03bf\u03c1\u03c4\u03ce\u03bd\u03b5\u03b9...\u0022 title=\u0022\u03a6\u03cc\u03c1\u03c4\u03c9\u03c3\u03b7\u0022 \/\u003E","closeText":"\u039a\u03bb\u03b5\u03af\u03c3\u03b9\u03bc\u03bf"},"modal-popup-large":{"modalSize":{"type":"scale","width":0.8000000000000000444089209850062616169452667236328125,"height":0.8000000000000000444089209850062616169452667236328125},"modalOptions":{"opacity":0.84999999999999997779553950749686919152736663818359375,"background":"#000"},"animation":"fadeIn","modalTheme":"ModalFormsPopup","throbber":"\u003Cimg typeof=\u0022foaf:Image\u0022 src=\u0022https:\/\/www.dimos-zagoras-mouresiou.gr\/sites\/all\/modules\/modal\_forms\/images\/loading\_animation.gif\u0022 alt=\u0022\u03a6\u03bf\u03c1\u03c4\u03ce\u03bd\u03b5\u03b9...\u0022 title=\u0022\u03a6\u03cc\u03c1\u03c4\u03c9\u03c3\u03b7\u0022 \/\u003E","closeText":"\u039a\u03bb\u03b5\u03af\u03c3\u03b9\u03bc\u03bf"},"fullcalendar":{".view-dom-id-d8c8d8de37f07eb843cdc9c27b5ad5e1":{"sameWindow":true,"grouping":[],"fullcalendar":{"buttonText":{"day":"\u0397\u03bc\u03ad\u03c1\u03b1","week":"\u0395\u03b2\u03b4\u03bf\u03bc\u03ac\u03b4\u03b1","month":"\u039c\u03ae\u03bd\u03b1\u03c2","today":"\u03a3\u03ae\u03bc\u03b5\u03c1\u03b1"},"allDayText":"\u039f\u03bb\u03bf\u03ae\u03bc\u03b5\u03c1\u03bf","monthNames":["\u0399\u03b1\u03bd\u03bf\u03c5\u03ac\u03c1\u03b9\u03bf\u03c2","\u03a6\u03b5\u03b2\u03c1\u03bf\u03c5\u03ac\u03c1\u03b9\u03bf\u03c2","\u039c\u03ac\u03c1\u03c4\u03b9\u03bf\u03c2","\u0391\u03c0\u03c1\u03af\u03bb\u03b9\u03bf\u03c2","\u039c\u03ac\u03b9\u03bf\u03c2","\u0399\u03bf\u03cd\u03bd\u03b9\u03bf\u03c2","\u0399\u03bf\u03cd\u03bb\u03b9\u03bf\u03c2","\u0391\u03cd\u03b3\u03bf\u03c5\u03c3\u03c4\u03bf\u03c2","\u03a3\u03b5\u03c0\u03c4\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2","\u039f\u03ba\u03c4\u03ce\u03b2\u03c1\u03b9\u03bf\u03c2","\u039d\u03bf\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2","\u0394\u03b5\u03ba\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2"],"monthNamesShort":["\u0399\u03b1\u03bd","\u03a6\u03b5\u03b2","\u039c\u03b1\u03c1","\u0391\u03c0\u03c1","\u039c\u03ac\u03b9\u03bf\u03c2","\u0399\u03bf\u03c5\u03bd","\u0399\u03bf\u03c5\u03bb","\u0391\u03c5\u03b3","\u03a3\u03b5\u03c0","\u039f\u03ba\u03c4","\u039d\u03bf\u03b5","\u0394\u03b5\u03ba"],"dayNames":["\u039a\u03c5\u03c1\u03b9\u03b1\u03ba\u03ae","\u0394\u03b5\u03c5\u03c4\u03ad\u03c1\u03b1","\u03a4\u03c1\u03af\u03c4\u03b7","\u03a4\u03b5\u03c4\u03ac\u03c1\u03c4\u03b7","\u03a0\u03ad\u03bc\u03c0\u03c4\u03b7","\u03a0\u03b1\u03c1\u03b1\u03c3\u03ba\u03b5\u03c5\u03ae","\u03a3\u03ac\u03b2\u03b2\u03b1\u03c4\u03bf"],"dayNamesShort":["\u039a\u03c5\u03c1","\u0394\u03b5\u03c5","\u03a4\u03c1\u03af","\u03a4\u03b5\u03c4","\u03a0\u03ad\u03bc","\u03a0\u03b1\u03c1","\u03a3\u03ac\u03b2"],"isRTL":false,"defaultView":"month","firstDay":"0","weekMode":"fixed","header":{"left":"today prev,next","center":"title","right":"month agendaWeek"},"timeFormat":"h:mm{ - h:mm}","axisFormat":"h(:mm)t","theme":true,"droppable":false,"editable":false},"date":{"year":"2026","month":8},"ajax":false,"gcal":[],"view\_name":"fullcalendar","view\_display":"page\_1","weights":["fullcalendar"]}},"eu\_cookie\_compliance":{"cookie\_policy\_version":"1.0.0","popup\_enabled":1,"popup\_agreed\_enabled":0,"popup\_hide\_agreed":0,"popup\_clicking\_confirmation":false,"popup\_scrolling\_confirmation":false,"popup\_html\_info":"\u003Cdiv class=\u0022eu-cookie-compliance-banner eu-cookie-compliance-banner-info eu-cookie-compliance-banner--opt-in\u0022\u003E\n \u003Cdiv class=\u0022popup-content info\u0022\u003E\n \u003Cdiv id=\u0022popup-text\u0022\u003E\n \u003Cp\u003E\u003Cstrong\u003E\u039f \u03b9\u03c3\u03c4\u03cc\u03c4\u03bf\u03c0\u03bf\u03c2 \u03c7\u03c1\u03b7\u03c3\u03b9\u03bc\u03bf\u03c0\u03bf\u03b9\u03b5\u03af cookies \u03b3\u03b9\u03b1 \u03c4\u03b7 \u03b2\u03b5\u03bb\u03c4\u03b9\u03ce\u03c3\u03b7 \u03c4\u03b7\u03c2 \u03b5\u03bc\u03c0\u03b5\u03b9\u03c1\u03af\u03b1\u03c2 \u03c4\u03bf\u03c5 \u03c7\u03c1\u03ae\u03c3\u03c4\u03b7. \u039c\u03b5 \u03c4\u03b7 \u03c7\u03c1\u03ae\u03c3\u03b7 \u03b1\u03c5\u03c4\u03bf\u03cd \u03c4\u03bf\u03c5 \u03b9\u03c3\u03c4\u03cc\u03c4\u03bf\u03c0\u03bf\u03c5, \u03b1\u03c0\u03bf\u03b4\u03ad\u03c7\u03b5\u03c3\u03c4\u03b5 \u03c4\u03b7 \u03c7\u03c1\u03ae\u03c3\u03b7 \u03c4\u03c9\u03bd cookies.\u003C\/strong\u003E\u003C\/p\u003E\n \u003Cbutton type=\u0022button\u0022 class=\u0022find-more-button eu-cookie-compliance-more-button\u0022\u003E\u03a0\u03b5\u03c1\u03b9\u03c3\u03c3\u03cc\u03c4\u03b5\u03c1\u03b1\u003C\/button\u003E\n \u003C\/div\u003E\n \n \u003Cdiv id=\u0022popup-buttons\u0022 class=\u0022\u0022\u003E\n \u003Cbutton type=\u0022button\u0022 class=\u0022agree-button eu-cookie-compliance-secondary-button\u0022\u003E\u0391\u03c0\u03bf\u03b4\u03bf\u03c7\u03ae\u003C\/button\u003E\n \u003Cbutton type=\u0022button\u0022 class=\u0022decline-button eu-cookie-compliance-default-button\u0022 \u003E\u038c\u03c7\u03b9, \u03b5\u03c5\u03c7\u03b1\u03c1\u03b9\u03c3\u03c4\u03ce\u003C\/button\u003E\n \u003C\/div\u003E\n \u003C\/div\u003E\n\u003C\/div\u003E","use\_mobile\_message":false,"mobile\_popup\_html\_info":"\u003Cdiv class=\u0022eu-cookie-compliance-banner eu-cookie-compliance-banner-info eu-cookie-compliance-banner--opt-in\u0022\u003E\n \u003Cdiv class=\u0022popup-content info\u0022\u003E\n \u003Cdiv id=\u0022popup-text\u0022\u003E\n \u003Cbutton type=\u0022button\u0022 class=\u0022find-more-button eu-cookie-compliance-more-button\u0022\u003E\u03a0\u03b5\u03c1\u03b9\u03c3\u03c3\u03cc\u03c4\u03b5\u03c1\u03b1\u003C\/button\u003E\n \u003C\/div\u003E\n \n \u003Cdiv id=\u0022popup-buttons\u0022 class=\u0022\u0022\u003E\n \u003Cbutton type=\u0022button\u0022 class=\u0022agree-button eu-cookie-compliance-secondary-button\u0022\u003E\u0391\u03c0\u03bf\u03b4\u03bf\u03c7\u03ae\u003C\/button\u003E\n \u003Cbutton type=\u0022button\u0022 class=\u0022decline-button eu-cookie-compliance-default-button\u0022 \u003E\u038c\u03c7\u03b9, \u03b5\u03c5\u03c7\u03b1\u03c1\u03b9\u03c3\u03c4\u03ce\u003C\/button\u003E\n \u003C\/div\u003E\n \u003C\/div\u003E\n\u003C\/div\u003E\n","mobile\_breakpoint":"768","popup\_html\_agreed":"\u003Cdiv\u003E\n \u003Cdiv class=\u0022popup-content agreed\u0022\u003E\n \u003Cdiv id=\u0022popup-text\u0022\u003E\n \u003Ch2\u003EThank you for accepting cookies\u003C\/h2\u003E\n\u003Cp\u003EYou can now hide this message or find out more about cookies.\u003C\/p\u003E\n \u003C\/div\u003E\n \u003Cdiv id=\u0022popup-buttons\u0022\u003E\n \u003Cbutton type=\u0022button\u0022 class=\u0022hide-popup-button eu-cookie-compliance-hide-button\u0022\u003E\u0391\u03c0\u03cc\u03ba\u03c1\u03c5\u03c8\u03b7\u003C\/button\u003E\n \u003Cbutton type=\u0022button\u0022 class=\u0022find-more-button eu-cookie-compliance-more-button-thank-you\u0022 \u003E\u03a0\u03b5\u03c1\u03b9\u03c3\u03c3\u03cc\u03c4\u03b5\u03c1\u03b5\u03c2 \u03c0\u03bb\u03b7\u03c1\u03bf\u03c6\u03bf\u03c1\u03af\u03b5\u03c2\u003C\/button\u003E\n \u003C\/div\u003E\n \u003C\/div\u003E\n\u003C\/div\u003E","popup\_use\_bare\_css":false,"popup\_height":"auto","popup\_width":"100%","popup\_delay":1000,"popup\_link":"\/content\/politiki-prostasias-prosopikon-dedomenon","popup\_link\_new\_window":1,"popup\_position":null,"fixed\_top\_position":1,"popup\_language":"el","store\_consent":false,"better\_support\_for\_screen\_readers":0,"reload\_page":0,"domain":"","domain\_all\_sites":null,"popup\_eu\_only\_js":0,"cookie\_lifetime":"100","cookie\_session":false,"disagree\_do\_not\_show\_popup":0,"method":"opt\_in","allowed\_cookies":"","withdraw\_markup":"\u003Cbutton type=\u0022button\u0022 class=\u0022eu-cookie-withdraw-tab\u0022\u003EPrivacy settings\u003C\/button\u003E\n\u003Cdiv class=\u0022eu-cookie-withdraw-banner\u0022\u003E\n \u003Cdiv class=\u0022popup-content info\u0022\u003E\n \u003Cdiv id=\u0022popup-text\u0022\u003E\n \u003Ch2\u003EWe use cookies on this site to enhance your user experience\u003C\/h2\u003E\n\u003Cp\u003EYou have given your consent for us to set cookies.\u003C\/p\u003E\n \u003C\/div\u003E\n \u003Cdiv id=\u0022popup-buttons\u0022\u003E\n \u003Cbutton type=\u0022button\u0022 class=\u0022eu-cookie-withdraw-button\u0022\u003EWithdraw consent\u003C\/button\u003E\n \u003C\/div\u003E\n \u003C\/div\u003E\n\u003C\/div\u003E\n","withdraw\_enabled":false,"withdraw\_button\_on\_info\_popup":false,"cookie\_categories":[],"cookie\_categories\_details":[],"enable\_save\_preferences\_button":true,"cookie\_name":"","cookie\_value\_disagreed":"0","cookie\_value\_agreed\_show\_thank\_you":"1","cookie\_value\_agreed":"2","containing\_element":"body","automatic\_cookies\_removal":true,"close\_button\_action":"close\_banner"},"googleanalytics":{"account":["UA-23407806-11"],"trackOutbound":1,"trackMailto":1,"trackDownload":1,"trackDownloadExtensions":"7z|aac|arc|arj|asf|asx|avi|bin|csv|doc(x|m)?|dot(x|m)?|exe|flv|gif|gz|gzip|hqx|jar|jpe?g|js|mp(2|3|4|e?g)|mov(ie)?|msi|msp|pdf|phps|png|ppt(x|m)?|pot(x|m)?|pps(x|m)?|ppam|sld(x|m)?|thmx|qtm?|ra(m|r)?|sea|sit|tar|tgz|torrent|txt|wav|wma|wmv|wpd|xls(x|m|b)?|xlt(x|m)|xlam|xml|z|zip","trackColorbox":1},"superfish":{"1":{"id":"1","sf":{"animation":{"opacity":"show","height":"show"},"speed":"\u0027fast\u0027","autoArrows":true,"dropShadows":true,"disableHI":false},"plugins":{"smallscreen":{"mode":"window\_width","addSelected":false,"menuClasses":false,"hyperlinkClasses":false,"title":"Main menu"},"supposition":true,"bgiframe":false,"supersubs":{"minWidth":"12","maxWidth":"27","extraWidth":1}}}},"urlIsAjaxTrusted":{"\/fullcalendar":true},"extlink":{"extTarget":"\_blank","extClass":0,"extLabel":"(link is external)","extImgClass":0,"extIconPlacement":"append","extSubdomains":1,"extExclude":"","extInclude":"","extCssExclude":"","extCssExplicit":"","extAlert":0,"extAlertText":"This link will take you to an external web site.","mailtoClass":0,"mailtoLabel":"(link sends e-mail)","extUseFontAwesome":false}});
//--><!]]>

[Παράκαμψη προς το κυρίως περιεχόμενο](#main-content)

[![Αρχική](https://www.dimos-zagoras-mouresiou.gr/sites/all/themes/tb_corpal/skins/cyan/logo.png)](/ "Αρχική")

* [Δήμος](/menu-tree/455)
  + [Γραφείο Δημάρχου](/menu-tree/462)
    - [Μήνυμα Δημάρχου](/content/minyma-dimarhoy)
    - [Δελτία Tύπου](/tracker_deltia)
    - [Διατελέσαντες Δήμαρχοι](/content/diatelesantes-dimarhoi)
  + [Δηλώσεις Περιουσιακών Στοιχείων](/content/diloseis-perioysiakis-katastasis-aireton)
  + [Κέντρο Διά Βίου Μάθησης](/content/kentro-dia-vioy-mathisis)
  + [Αντιδήμαρχοι](/content/antidimarhoi)
  + [Νομικά Πρόσωπα](/menu-tree/7918)
    - [Β/βάθμια Σχολική Επιτροπή](/content/sholiki-epitropi-deyterovathmias-ekpaideysis)
    - [Εταιρία Ανάπτυξης Πηλίου Α.Ε.](/content/etairia-anaptyxis-pilioy-ae)
    - [Κ.Ε.ΔΗ.ΖΑ.Μ.](/content/koinofelis-epiheirisi-dimoy-zagorasmoyresioy)
      * [Μέλη συμβουλίου](/content/meli-symvoylioy-kedizam)
      * [Συνεδριάσεις Συμβουλίου](/tracker_simvoulia-dim/86)
        + [Προσκλήσεις](/tracker_simvoulia-dim/86/2)
        + [Αποφάσεις](/tracker_simvoulia-dim/86/1)
        + [Προϋπολογισμοί](/content/proypologismoi)
    - [Α/βάθμια Σχολική Επιτροπή](/content/sholiki-epitropi-protovathmias-ekpaideysis)
  + [Δημοτικό Συμβούλιο](/content/dimotikoi-symvoyloi)
    - [Προεδρείο Δ.Σ.](/content/proedreio-ds)
    - [Δημοτικοί Σύμβουλοι](/content/dimotikoi-symvoyloi)
    - [Συνεδριάσεις Συμβουλίου](/tracker_simvoulia-dim/3)
      * [Προσκλήσεις](/tracker_simvoulia-dim/3/2)
      * [Αποφάσεις](/tracker_simvoulia-dim/3/1)
  + [Τοπικά Συμβούλια](/content/topikoi-symvoyloi)
    - [Τοπικοί Σύμβουλοι](/content/topikoi-symvoyloi)
    - [Συνεδριάσεις Συμβουλίων](/tracker_simvoulia/79)
      * [Προσκλήσεις](/tracker_simvoulia/79/2)
      * [Αποφάσεις](/tracker_simvoulia/79/1)
  + [Επιτροπές](/content/epitropes)
    - [Δημοτική Επιτροπή](/content/dimotiki-epitropi)
      * [Μέλη Δημοτικής Επιτροπής](/content/meli-dimotikis-epitropis)
      * [Συνεδριάσεις Επιτροπής](/tracker_simvoulia/90)
        + [Προσκλήσεις](/tracker_simvoulia/90/2)
        + [Αποφάσεις](/tracker_simvoulia/90/1)
    - [Επιτροπή Διαβούλευσης](/content/meli-epitropis-diavoyleysis)
      * [Μέλη Επιτροπής](/content/meli-epitropis-diavoyleysis)
      * [Συνεδριάσεις Επιτροπής](/tracker_simvoulia/89)
        + [Προσκλήσεις](/tracker_simvoulia/89/2)
        + [Αποφάσεις](/tracker_simvoulia/89/1)
    - [Παλαιότερες επιτροπές](/content/meli-epitropis-1)
      * [Εκτελεστική Επιτροπή](/content/meli-epitropis-1)
        + [Μέλη Επιτροπής](/content/meli-epitropis-1)
        + [Συνεδριάσεις Επιτροπής](/tracker_simvoulia/5)
          - [Προσκλήσεις](/tracker_simvoulia/5/2)
          - [Αποφάσεις](/tracker_simvoulia/5/1)
      * [Οικονομική Επιτροπή](/content/meli-epitropis-0)
        + [Μέλη Επιτροπής](/content/meli-epitropis-0)
        + [Συνεδριάσεις Επιτροπής](/tracker_simvoulia/4)
          - [Προσκλήσεις](/tracker_simvoulia/4/2)
          - [Αποφάσεις](/tracker_simvoulia/4/1)
  + [Προϋπολογισμοί](/content/proypologismos-etoys)
  + [Υπηρεσίες - Διευθύνσεις](/content/ypiresies-dieythynseis)
  + [Δημοτικές & Τοπικές Κοινότητες](/content/dimotikes-enotites)
* [Δημότες](/menu-tree/456)
  + [Κ.Ε.Π.](/content/kep)
  + [Δικαιώματα του Πολίτη](/content/dikaiomata-toy-politi)
    - [Ο Συνήγορος του Πολίτη](/content/o-synigoros-toy-politi)
    - [Ο Διαμεσολαβητής της Ευρωπαϊκής Ένωσης](/content/o-diamesolavitis-tis-eyropaikis-enosis)
    - [Μεσολαβητής Τραπεζικών Επενδυτικών Υπηρεσιών](/content/mesolavitis-trapezikon-ependytikon-ypiresion)
  + [Νέα - Ανακοινώσεις](/tracker_news)
  + [Συγχρηματοδοτούμενα Προγράμματα](/term-lists-prog)
  + [Ατζέντα Εκδηλώσεων](/fullcalendar)
* [Επισκέπτες](/menu-tree/458)
  + [Τουριστικός Οδηγός](http://www.east-pelion.gr)
  + [Φωτογραφίες](/tracker_album)
* [Επιχειρήσεις](/menu-tree/457)
  + [Προκηρύξεις - Διαγωνισμοί](/tracker_prokirikseis)
* [Υπηρεσίες](/menu-tree/459)
  + [Δημοσκοπήσεις](/poll)
  + [Ερωτηματολόγια](/tracker_erotimatologia)
  + [Πρόγραμμα Διαύγεια](/aggregator/categories/1)
  + [Χάρτης Ιστοχώρου](/sitemap)
  + [RSS feeds](/content/rss-feeds)
* [Επικοινωνία](/contact2)

## Φόρμα αναζήτησης

Αναζήτηση

## Δευτερεύον μενού

* [Είσοδος](/user/login)

# Ατζέντα Εκδηλώσεων

### Εκδήλωση "100 χρόνια από τη γέννηση και 50 από τον θάνατο του Νίκου Γούναρη"

[Κυρ, 02/08/2015 - 21:00 έως Δευ, 03/08/2015 - 20:45](/events/100-hronia-apo-ti-gennisi-kai-50-apo-ton-thanato-toy-nikoy-goynari "Εκδήλωση \"100 χρόνια από τη γέννηση και 50 από τον θάνατο του Νίκου Γούναρη\"")

### Συναυλία του συνόλου εγχόρδων "Ροτόντα" στο προαύλιο του Ι.Ν.Μεταμορφώσεως του Σωτήρος στη Ζαγορά

[Τετ, 29/07/2015 - 20:30](/events/synaylia-toy-synoloy-eghordon-rotonta-sto-proaylio-toy-inmetamorfoseos-toy-sotiros-sti-zagora "Συναυλία του συνόλου εγχόρδων \"Ροτόντα\" στο προαύλιο του Ι.Ν.Μεταμορφώσεως του Σωτήρος στη Ζαγορά")

### Συναυλίες στο Δημοτικό Σχολείο "Ρήγας Φεραίος"

[Παρ, 31/07/2015 - 09:30](/events/synaylies-sto-dimotiko-sholeio-rigas-feraios "Συναυλίες στο Δημοτικό Σχολείο \"Ρήγας Φεραίος\"")

### Ακύρωση της παρουσίασης του συγγραφικού έργου της Αλκυόνης Παπαδάκη

[Σάβ, 01/08/2015 - 21:00 έως Κυρ, 02/08/2015 - 20:45](/events/akyrosi-tis-paroysiasis-toy-syggrafikoy-ergoy-tis-alkyonis-papadaki "Ακύρωση της παρουσίασης του συγγραφικού έργου της Αλκυόνης Παπαδάκη")

### Εγκαίνια έκθεσης "Κίνησαν τα καράβια τα Ζαγοριανά"

[Σάβ, 08/08/2015 - 20:30 έως Δευ, 17/08/2015 - 20:45](/events/egkainia-ekthesis-kinisan-ta-karavia-ta-zagoriana "Εγκαίνια έκθεσης \"Κίνησαν τα καράβια τα Ζαγοριανά\"")

### Βραδιά στη μνήμη του Κώστα Τσαγκαράδα

[Δευ, 10/08/2015 - 21:00 έως Τρί, 11/08/2015 - 20:45](/events/vradia-sti-mnimi-toy-nikoy-tsagkarada "Βραδιά στη μνήμη του Κώστα Τσαγκαράδα")

### Εγκαίνια έκθεσης "Κίνησαν τα καράβια τα Ζαγοριανά"

[Τρί, 18/08/2015 - 21:00 έως Πέμ, 27/08/2015 - 20:45](/events/egkainia-ekthesis-kinisan-ta-karavia-ta-zagoriana-0 "Εγκαίνια έκθεσης \"Κίνησαν τα καράβια τα Ζαγοριανά\"")

### Φύση και Ηχοχρώματα

[Παρ, 28/08/2015 - 20:00 έως Σάβ, 29/08/2015 - 19:45](/events/fysi-kai-ihohromata "Φύση και Ηχοχρώματα")

### Προβολή ντοκιμαντέρ "Το μουσικό ταξίδι του Κωνσταντίνου Δημηνάκη"

[Παρ, 28/08/2015 - 20:30](/events/provoli-ntokimanter "Προβολή ντοκιμαντέρ \"Το μουσικό ταξίδι του Κωνσταντίνου Δημηνάκη\"")

### Προβολή ντοκιμαντέρ "Το μουσικό ταξίδι του Κωνσταντίνου Δημηνάκη"

[Κυρ, 30/08/2015 - 21:30](/events/provoli-ntokimanter-moysiko-taxidi-toy-konstantinoy-diminaki "Προβολή ντοκιμαντέρ \"Το μουσικό ταξίδι του Κωνσταντίνου Δημηνάκη\"")

### Προβολή ντοκιμαντέρ "Οι Ηλιόσποροι"

[Κυρ, 30/08/2015 - 20:30](/events/provoli-ntokimanter-oi-iliosporoi "Προβολή ντοκιμαντέρ \"Οι Ηλιόσποροι\"")

### Προβολή ντοκιμαντέρ "Οι Ηλιόσποροι"

[Σάβ, 29/08/2015 - 20:30](/events/provoli-ntokimanter-oi-iliosporoi-0 "Προβολή ντοκιμαντέρ \"Οι Ηλιόσποροι\"")

### 2η Γιορτή Τσίπουρου στο Μούρεσι 7/11/15

[Σάβ, 07/11/2015 - 00:00 έως 23:45](/events/2i-giorti-tsipoyroy "2η Γιορτή Τσίπουρου στο Μούρεσι 7/11/15")

### 8ο Συνέδριο -Αντάμωμα Θεσσαλών στην Τσαγκαράδα Πηλίου - Πρόγραμμα

[Παρ, 15/07/2016 - 18:00 έως Δευ, 18/07/2016 - 13:45](/events/8o-synedrio-antamoma-thessalon-stin-tsagkarada-pilioy "8ο Συνέδριο -Αντάμωμα Θεσσαλών στην Τσαγκαράδα Πηλίου - Πρόγραμμα")

### "'Αρωμα Κρήτης" Κρητική - Νησιώτικη Βραδιά

[Σάβ, 16/07/2016 - 22:30](/events/aroma-kritis-kritiki-nisiotiki-vradia "\"'Αρωμα Κρήτης\" Κρητική - Νησιώτικη Βραδιά")

### Συναυλία των συμμετεχόντων στα σεμινάρια, σε έγχορδα όργανα - Κισσός

[Τρί, 26/07/2016 - 21:00 έως Τετ, 27/07/2016 - 20:45](/events/synaylia-ton-symmetehonton-sta-seminaria-se-eghorda-organa-kissos "Συναυλία των συμμετεχόντων στα σεμινάρια, σε έγχορδα όργανα - Κισσός")

### Πανηγύρι για τον εορτασμό της Αγίας Παρασκευής

[Τρί, 26/07/2016 - 10:15](/events/panigyri-gia-ton-eortasmo-tis-agias-paraskeyis-plateia-agias-paraskeyis "Πανηγύρι για τον εορτασμό της Αγίας Παρασκευής")

### Συναυλία εγχόρδων και πνευστών, με την συμμετοχή του PelionFestival Violoncello Quartet

[Τετ, 27/07/2016 - 20:30](/events/synaylia-eghordon-kai-pneyston-me-tin-symmetohi-toy-pelionfestival-violoncello-quartet "Συναυλία εγχόρδων και πνευστών, με την συμμετοχή του PelionFestival Violoncello Quartet")

### Πανηγύρι για τον εορτασμό Αγίου Παντελεήμονα

[Τετ, 27/07/2016 - 21:30](/events/panigyri-gia-ton-eortasmo-agioy-panteleimona "Πανηγύρι για τον εορτασμό Αγίου Παντελεήμονα")

### Συναυλία του Συνόλου Σαξοφώνων Φεστιβάλ Πηλίου

[Πέμ, 28/07/2016 - 21:00 έως Παρ, 29/07/2016 - 20:45](/events/synaylia-toy-synoloy-saxofonon-festival-pilioy "Συναυλία του Συνόλου Σαξοφώνων Φεστιβάλ Πηλίου")

### Συναυλία εγχόρδων και πνευστών, φωνής και πιάνου

[Πέμ, 28/07/2016 - 20:30](/events/synaylia-eghordon-kai-pneyston-fonis-kai-pianoy "Συναυλία εγχόρδων και πνευστών, φωνής και πιάνου")

### Συναυλία εγχόρδων και πνευστών, φωνής και πιάνου

[Παρ, 29/07/2016 - 20:30](/events/synaylia-eghordon-kai-pneyston-fonis-kai-pianoy-0 "Συναυλία εγχόρδων και πνευστών, φωνής και πιάνου")

### Συναυλία του Συνόλου Βιολοντσέλων του Φεστιβάλ Πηλίου & Συνόλου Σαξοφών του Φεστιβάλ Πηλίου

[Σάβ, 30/07/2016 - 09:15](/events/synaylia-toy-synoloy-violontselon-toy-festival-pilioy-synoloy-saxofon-toy-festival-pilioy "Συναυλία του Συνόλου Βιολοντσέλων του Φεστιβάλ Πηλίου & Συνόλου Σαξοφών του Φεστιβάλ Πηλίου")

### Θεατρική Παράσταση:"Χαμογελάστε Παρακαλώ!"

[Σάβ, 30/07/2016 - 09:30](/events/theatriki-parastasihamogelaste-parakalo "Θεατρική Παράσταση:\"Χαμογελάστε Παρακαλώ!\"")

### 16ο Τουρνουά Beach Soccer - Χορευτό

[Δευ, 01/08/2016 - 13:45 έως Σάβ, 06/08/2016 - 20:45](/events/16o-toyrnoya-beach-soccer-horeyto "16ο Τουρνουά Beach Soccer - Χορευτό")

### Φεστιβάλ χειροτεχνίας και Παζάρι δημιουργιών στο Χορευτό

[Παρ, 05/08/2016 - 00:00 έως Κυρ, 07/08/2016 - 23:45](/events/festival-heirotehnias-kai-pazari-dimioyrgion-sto-horeyto "Φεστιβάλ χειροτεχνίας και Παζάρι δημιουργιών στο Χορευτό")

### Βραδιά τσίπουρου με συμμετοχή παραδοσιακών χορευτικών συγκροτημάτων - Πλατεία Μεταμόρφωσης του Σωτήρος Αγ.Δημήτριος

[Παρ, 05/08/2016 - 19:00 έως Σάβ, 06/08/2016 - 18:45](/events/vradia-tsipoyroy-me-symmetohi-paradosiakon-horeytikon-sygkrotimaton-plateia-metamorfosis-toy "Βραδιά τσίπουρου με συμμετοχή παραδοσιακών χορευτικών συγκροτημάτων - Πλατεία Μεταμόρφωσης του Σωτήρος Αγ.Δημήτριος")

### Πανηγύρι για τον εορτασμό της Μεταμόρφωσης του Σωτήρος

[Σάβ, 06/08/2016 - 21:00 έως Κυρ, 07/08/2016 - 20:45](/events/panigyri-gia-ton-eortasmo-tis-metamorfosis-toy-sotiros "Πανηγύρι για τον εορτασμό της Μεταμόρφωσης του Σωτήρος")

### 3η Αστροβραδιά Μουρεσίου, θέση Τσούκα Μούρεσι

[Σάβ, 06/08/2016 - 21:00 έως Κυρ, 07/08/2016 - 20:45](/events/3i-astrovradia-moyresioy-thesi-tsoyka-moyresi "3η Αστροβραδιά Μουρεσίου, θέση Τσούκα Μούρεσι")

### Μουσικοχορευτική Παράσταση "Με το φεγγάρι περπατώ με τ' άστριν κουβεντιάζω" Χορευτό

[Σάβ, 06/08/2016 - 21:00 έως Κυρ, 07/08/2016 - 20:45](/events/moysikohoreytiki-parastasi-me-feggari-perpato-me-t-astrin-koyventiazo-horeyto "Μουσικοχορευτική Παράσταση \"Με το φεγγάρι περπατώ με τ' άστριν κουβεντιάζω\" Χορευτό")

### "Βαγγέλης Σκουβαράς", Η Ζωή και το έργο του

[Κυρ, 07/08/2016 - 20:00 έως Δευ, 08/08/2016 - 19:45](/events/vaggelis-skoyvaras-i-zoi-kai-ergo-toy "\"Βαγγέλης Σκουβαράς\", Η Ζωή και το έργο του")

### 5η Έκθεση Τοπικών Προιόντων στο Ανήλιο

[Παρ, 12/08/2016 - 18:00 έως Κυρ, 14/08/2016 - 23:45](/events/5i-ekthesi-topikon-proionton-sto-anilio " 5η Έκθεση Τοπικών Προιόντων στο Ανήλιο")

### Έκθεση Φωτογραφίας του Κώστα Ρούσση, ενός λαϊκού φωτογράφου από τη Ζαγορά Πηλίου «Ανωνύμων Ταυτότητες»

[Τετ, 10/08/2016 - 00:00 έως Δευ, 05/09/2016 - 23:45](/events/ekthesi-fotografias-toy-kosta-royssi-enos-laikoy-fotografoy-apo-ti-zagora-pilioy-anonymon "Έκθεση Φωτογραφίας του Κώστα  Ρούσση, ενός λαϊκού φωτογράφου από τη Ζαγορά Πηλίου «Ανωνύμων Ταυτότητες»")

### Έκθεση Ζωγραφικής του Κώστα Κομνηνού, ενός σύγχρονου καλλιτέχνη από τη Ζαγορά Πηλίου.

[Τετ, 10/08/2016 - 00:00 έως Παρ, 30/09/2016 - 23:45](/events/ekthesi-zografikis-toy-kosta-komninoy-enos-syghronoy-kallitehni-apo-ti-zagora-pilioy "Έκθεση Ζωγραφικής του Κώστα  Κομνηνού, ενός σύγχρονου καλλιτέχνη από τη Ζαγορά Πηλίου.")

### Μουσική βραδιά με τους Clile Verde στο Πουρί

[Πέμ, 11/08/2016 - 21:30](/events/moysiki-vradia-me-toys-clile-verde-sto-poyri "Μουσική βραδιά με τους Clile Verde στο Πουρί")

### Επιμνημόσυνη δέηση για τον Ζαγοριανό μουσικοσυνθέτη και τραγουδιστή Νίκο Γούναρη

[Σάβ, 20/08/2016 - 09:00 έως Κυρ, 21/08/2016 - 08:45](/events/epimnimosyni-deisi-gia-ton-zagoriano-moysikosyntheti-kai-tragoydisti-niko-goynari "Επιμνημόσυνη δέηση για τον Ζαγοριανό μουσικοσυνθέτη και τραγουδιστή Νίκο Γούναρη")

### Βραδιά έντεχνου & λαϊκού τραγουδιού, Μούρεσι, θέση Τσούκα

[Κυρ, 21/08/2016 - 21:00 έως Δευ, 22/08/2016 - 20:45](/events/vradia-entehnoy-laikoy-tragoydioy-moyresi-thesi-tsoyka "Βραδιά έντεχνου & λαϊκού τραγουδιού, Μούρεσι, θέση Τσούκα")

### Ανωνύμων Ταυτότητες, παρουσίαση του φωτογραφικού έργου του Κώστα Ρούσση, στη Ζαγορά

[Κυρ, 28/08/2016 - 20:00 έως Δευ, 29/08/2016 - 19:45](/events/anonymon-taytotites-paroysiasi-toy-fotografikoy-ergoy-toy-kosta-royssi-sti-zagora "Ανωνύμων Ταυτότητες, παρουσίαση του φωτογραφικού έργου του Κώστα Ρούσση, στη Ζαγορά")

### Διήμερο επετειακών εκδηλώσεων μνήμης και τιμής στον συνεταιριστή

[Σάβ, 29/10/2016 - 19:30 έως Κυρ, 30/10/2016 - 21:45](/events/diimero-epeteiakon-ekdiloseon-mnimis-kai-timis-ston-synetairisti "Διήμερο επετειακών εκδηλώσεων μνήμης και τιμής στον συνεταιριστή")

### Αναβολή έναρξης 14η Γιορτής Κάστανου στο Ξουρίχτι, 29-30 Οκτωβρίου

[Σάβ, 29/10/2016 - 10:30 έως Κυρ, 30/10/2016 - 17:30](/events/14i-giorti-kastanoy-sto-xoyryhti-28-29-30-oktovrioy "Αναβολή έναρξης 14η Γιορτής Κάστανου στο Ξουρίχτι, 29-30 Οκτωβρίου")

### Αιμοδοσία στην Πλατεία Αγ. Γεωργίου στη Ζαγορά

[Πέμ, 17/11/2016 - 09:00 έως Παρ, 18/11/2016 - 12:45](/events/aimodosia-stin-plateia-ag-georgioy-sti-zagora "Αιμοδοσία στην Πλατεία Αγ. Γεωργίου στη Ζαγορά")

### 3η Γιορτή Τσίπουρου στο Μούρεσι

[Σάβ, 05/11/2016 - 12:00 έως Κυρ, 06/11/2016 - 11:45](/events/3i-giorti-tsipoyroy-sto-moyresi "3η Γιορτή Τσίπουρου στο Μούρεσι")

### Έκθεση Ζωγραφικής του Γιάννη Μηλιώνη

[Κυρ, 06/11/2016 - 19:00 έως Δευ, 28/11/2016 - 20:45](/events/ekthesi-zografikis-toy-gianni-milioni "Έκθεση Ζωγραφικής του Γιάννη Μηλιώνη")

### 1ος Μαθηματικός Διαγωνισμός: Μαθαίνω να Αγωνίζομαι και να Προσφέρω

[Κυρ, 11/12/2016 - 10:00 έως Δευ, 12/12/2016 - 09:45](/events/1os-mathimatikos-diagonismos-mathaino-na-agonizomai-kai-na-prosfero "1ος Μαθηματικός Διαγωνισμός: Μαθαίνω να Αγωνίζομαι και να Προσφέρω")

### Εορταστική Εκδήλωση με το Μουσικό Γυμνάσιο Βόλου και Χριστουγεννιάτικο Bazaar στο Δημοτικό Σχολείο Ζαγοράς

[Κυρ, 18/12/2016 - 10:00 έως Δευ, 19/12/2016 - 09:45](/events/hristoygenniatiko-bazaar-sto-dimotiko-sholeio-zagoras "Εορταστική Εκδήλωση με το Μουσικό Γυμνάσιο Βόλου και Χριστουγεννιάτικο Bazaar στο Δημοτικό Σχολείο Ζαγοράς")

### Διάλεξη με θέμα: Καινοτομία και Εθελοντισμός από τον δρ. Νίκο Λυγερό

[Πέμ, 05/01/2017 - 18:00 έως Παρ, 06/01/2017 - 17:45](/events/dialexi-me-thema-kainotomia-kai-ethelontismos-apo-ton-dr-niko-lygero "Διάλεξη με θέμα: Καινοτομία και Εθελοντισμός από τον δρ. Νίκο Λυγερό")

### Εκδήλωση με ομιλητή τον συγγραφέα Γιάννη Καλπούζο

[Τρί, 24/01/2017 - 11:30](/events/ekdilosi-me-omiliti-ton-syggrafea-gianni-kalpoyzo "Εκδήλωση με ομιλητή τον συγγραφέα Γιάννη Καλπούζο ")

### Παιδική Παράσταση με τίτλο Όνειρο Αποκριάς

[Τετ, 22/03/2017 - 10:15](/events/paidiki-parastasi-me-titlo-oneiro-apokrias "Παιδική Παράσταση με τίτλο Όνειρο Αποκριάς ")

### 10th International TFG Centaur 2017

[Κυρ, 30/04/2017 - 09:30 έως Δευ, 01/05/2017 - 16:45](/events/10o-international-tfg-centaur-2017 "10th International TFG Centaur 2017")

### Ο Όμιλος ΑγκαλιάΖΩ πραγματοποιεί εκστρατεία για την πρόληψη – έγκαιρη διάγνωση του Καρκίνου του Δέρματος και του Μελανώματος στο Δήμο Ζαγοράς - Μουρεσίου

[Σάβ, 10/06/2017 - 10:00 έως Δευ, 12/06/2017 - 16:45](/events/o-omilos-agkaliazo-pragmatopoiei-ekstrateia-gia-tin-prolipsi-egkairi-diagnosi-toy-karkinoy "Ο Όμιλος ΑγκαλιάΖΩ πραγματοποιεί εκστρατεία  για την πρόληψη – έγκαιρη διάγνωση του Καρκίνου του Δέρματος  και του Μελανώματος στο Δήμο Ζαγοράς - Μουρεσίου")

### 3ο ΖΑΓΟΡΑΘΛΟΝ 2017

[Σάβ, 10/06/2017 - 18:00 έως Δευ, 12/06/2017 - 14:45](/events/3o-zagorathlon-2017 "3ο ΖΑΓΟΡΑΘΛΟΝ 2017")

### Κλήδωνας 2017, κάψιμο στεφανιών, Παπά Νερό Μούρεσι

[Παρ, 23/06/2017 - 21:00 έως Σάβ, 24/06/2017 - 20:45](/events/klidonas-2017-kapsimo-stefanion-papa-nero-moyresi "Κλήδωνας 2017, κάψιμο στεφανιών, Παπά Νερό Μούρεσι")

### 6η Έκθεση Τοπικών Προϊόντων - Ανήλιο - Κεντρική Πλατεία

[Σάβ, 12/08/2017 - 18:00 έως Δευ, 14/08/2017 - 23:30](/events/6i-ekthesi-topikon-proionton-anilio-kentriki-plateia "6η Έκθεση Τοπικών Προϊόντων - Ανήλιο - Κεντρική Πλατεία")

### 15η Γιορτή Κάστανου, 27-28-29/10/17, Ξορύχτι, Άγιοι Πάντες

[Παρ, 27/10/2017 - 17:00 έως Κυρ, 29/10/2017 - 17:30](/events/15i-giorti-kastanoy-27-28-291017-xoryhti-agoi-pantes "15η Γιορτή Κάστανου, 27-28-29/10/17, Ξορύχτι, Άγιοι Πάντες")

### 4η Γιορτή Τσίπουρου στην πλατεία Τ.Κ. Μούρεσι

[Σάβ, 04/11/2017 - 12:00 έως Κυρ, 05/11/2017 - 11:45](/events/4i-giorti-tsipoyroy-stin-plateia-tk-moyresi "4η Γιορτή Τσίπουρου στην πλατεία Τ.Κ. Μούρεσι")

### 2oς Μαθηματικός Διαγωνισμός «Μαθαίνω να Αγωνίζομαι και να προσφέρω»

[Κυρ, 10/12/2017 - 10:00 έως Δευ, 11/12/2017 - 09:45](/events/2os-mathimatikos-diagonismos-mathaino-na-agonizomai-kai-na-prosfero "2oς Μαθηματικός Διαγωνισμός «Μαθαίνω να Αγωνίζομαι και να προσφέρω»")

### Duo plegma με βιολοντσέλο και πιάνο στην Τσαγκαράδα

[Παρ, 05/01/2018 - 18:00 έως Σάβ, 06/01/2018 - 17:45](/events/duo-plegma-me-violontselo-kai-piano-stin-tsagkarada "Duo plegma με βιολοντσέλο και πιάνο στην Τσαγκαράδα")

### Παρουσίαση επιστημονικής έρευνας με θέμα: Η Ελληνίδα Αγρότισσα

[Παρ, 13/04/2018 - 12:00 έως Σάβ, 14/04/2018 - 11:45](/events/paroysiasi-epistimonikis-ereynas-me-thema-i-ellinida-agrotissa "Παρουσίαση επιστημονικής έρευνας με θέμα: Η Ελληνίδα Αγρότισσα")

### 13th International TFG Centaur 2018, Ξυρόβρυση, Άγιος Δημήτριος

[Κυρ, 27/05/2018 - 10:00 έως Δευ, 28/05/2018 - 19:45](/events/13th-international-tfg-centaur-2018-xyrovrysi-agios-dimitrios "13th International TFG Centaur 2018, Ξυρόβρυση, Άγιος Δημήτριος")

### 19o Inernational Pelion Festival, Music Festival & Academy

[Παρ, 20/07/2018 - 10:45 έως Σάβ, 04/08/2018 - 20:45](/events/19o-inernational-pelion-festival-music-festival-academy "19o Inernational Pelion Festival, Music Festival & Academy")

### 1ο Διεθνές Σκακιστικό Τουρνουά ΠΗΛΙΟ 2018, Άι Γιάννης Πηλίου

[Σάβ, 16/06/2018 - 08:30 έως Κυρ, 24/06/2018 - 19:45](/events/1o-diethnes-skakistiko-toyrnoya-pilio-2018-ai-giannis-pilioy "1ο Διεθνές Σκακιστικό Τουρνουά ΠΗΛΙΟ  2018, Άι Γιάννης Πηλίου ")

### 1ο Διεθνές Φεστιβάλ Κλασικής Μουσικής Δωματίου Θεσσαλίας

[Κυρ, 17/06/2018 - 09:00 έως Πέμ, 28/06/2018 - 23:15](/events/1o-diethnes-festival-klasikis-moysikis-domatioy-thessalias "1ο Διεθνές Φεστιβάλ Κλασικής Μουσικής Δωματίου Θεσσαλίας")

### Κλήδονας, κάψιμο στεφανιών, Παπά Νερό, Μούρεσι, θέατρο Αρίων

[Σάβ, 23/06/2018 - 21:00 έως Κυρ, 24/06/2018 - 20:45](/events/klidonas-kapsimo-stefanion-papa-nero-moyresi-theatro-arion "Κλήδονας, κάψιμο στεφανιών, Παπά Νερό, Μούρεσι, θέατρο Αρίων")

### 5ο Θερινό Σχολείο Ομοιοπαθητικής Ιατρικής

[Πέμ, 30/08/2018 - 15:00 έως Δευ, 03/09/2018 - 14:45](/events/5o-therino-sholeio-omoiopathitikis-iatrikis "5ο Θερινό Σχολείο Ομοιοπαθητικής Ιατρικής ")

### Εκδήλωση για δράσεις προστασίας των καλλιεργητών από φυσικά φαινόμενα

[Δευ, 20/08/2018 - 19:00 έως Τρί, 21/08/2018 - 18:45](/events/ekdilosi-gia-draseis-prostasias-ton-kalliergiton-apo-fysika-fainomena "Εκδήλωση για δράσεις προστασίας των καλλιεργητών από φυσικά φαινόμενα")

### Συζητάμε για την ομοιοπαθητική - Ανοιχτή εκδήλωση για το κοινό - Είσοδος Ελεύθερη

[Σάβ, 01/09/2018 - 18:00 έως Κυρ, 02/09/2018 - 17:45](/events/syzitame-gia-tin-omoiopathitiki-anoihti-ekdilosi-gia-koino-eisodos-eleytheri "Συζητάμε για την ομοιοπαθητική - Ανοιχτή εκδήλωση για το κοινό - Είσοδος Ελεύθερη")

### Θεσμός για το Πήλιο η γιορτή κάστανου στο Ξορύχτι

[Παρ, 26/10/2018 - 17:30 έως Δευ, 29/10/2018 - 14:45](/events/16i-giorti-kastanoy-sto-xoryhti-pilioy-proin-dimotiko-sholeio "Θεσμός για το Πήλιο  η γιορτή κάστανου στο Ξορύχτι")

### 5η Γιορτή Τσίπουρου στην πλατεία Τ.Κ. Μουρεσίου

[Σάβ, 03/11/2018 - 12:00 έως Κυρ, 04/11/2018 - 11:45](/events/5i-giorti-tsipoyroy-stin-plateia-tk-moyresioy "5η Γιορτή Τσίπουρου στην πλατεία Τ.Κ. Μουρεσίου")

### 3ος Μαθηματικός Διαγωνισμός, Μαθαίνω να Αγωνίζομαι και να προσφέρω

[Κυρ, 02/12/2018 - 10:00 έως Δευ, 03/12/2018 - 09:45](/events/3os-mathimatikos-diagonismos-mathaino-na-agonizomai-kai-na-prosfero "3ος Μαθηματικός Διαγωνισμός, Μαθαίνω να Αγωνίζομαι και να προσφέρω")

### 3ος Μαθηματικός Διαγωνισμός: Μαθαίνω να Αγωνίζομαι και να Προσφέρω

[Δευ, 03/12/2018 - 08:45](/events/3os-mathimatikos-diagonismos-mathaino-na-agonizomai-kai-na-prosfero-0 "3ος Μαθηματικός Διαγωνισμός: Μαθαίνω να Αγωνίζομαι και να Προσφέρω")

### 3ος Μαθηματικός Διαγωνισμός: Μαθαίνω να Αγωνίζομαι και να Προσφέρω

[Δευ, 03/12/2018 - 09:00 έως Τρί, 04/12/2018 - 08:45](/events/3os-mathimatikos-diagonismos-mathaino-na-agonizomai-kai-na-prosfero-1 "3ος Μαθηματικός Διαγωνισμός: Μαθαίνω να Αγωνίζομαι και να Προσφέρω")

### Πρόσκληση για το μνημόσυνο υπέρ των ευεργετών

[Κυρ, 17/03/2019 - 10:00 έως Δευ, 18/03/2019 - 09:45](/events/prosklisi-gia-mnimosyno-yper-ton-eyergeton "Πρόσκληση για το μνημόσυνο υπέρ των ευεργετών ")

### Πρόσκληση - Εγκαίνια Κέντρου Δημιουργικής Απασχόλησης Παιδιών

[Σάβ, 11/05/2019 - 19:00 έως Κυρ, 12/05/2019 - 18:45](/events/prosklisi-egkainia-kentroy-dimioyrgikis-apasholisis-paidion "Πρόσκληση - Εγκαίνια Κέντρου Δημιουργικής Απασχόλησης Παιδιών")

### Δωρεάν Γυναικολογική εξέταση - τεστ παπ

[Σάβ, 08/06/2019 - 09:00 έως Κυρ, 09/06/2019 - 13:45](/events/dorean-gynaikologiki-exetasi-test-pap "Δωρεάν Γυναικολογική εξέταση - τεστ παπ")

### Αναβίωση του εθίμου του Κλήδονα - Θέατρο Αρίων

[Κυρ, 23/06/2019 - 21:00 έως Δευ, 24/06/2019 - 20:45](/events/anaviosi-toy-ethimoy-toy-klidona-theatro-arion "Αναβίωση του εθίμου του Κλήδονα - Θέατρο Αρίων ")

### International PelionFestival Music Festival and Academy 18.7-4.8.2019 Ζαγορά, Τσαγκαράδα, Κισσός

[Πέμ, 18/07/2019 - 13:00 έως Κυρ, 04/08/2019 - 23:30](/events/international-pelionfestival-music-festival-and-academy-187-482019-zagora-tsagkarada-kissos "International PelionFestival Music Festival and Academy 18.7-4.8.2019 Ζαγορά, Τσαγκαράδα, Κισσός")

### 8η Έκθεση Τοπικών Προϊόντων στην Πλατεία Ανηλίου

[Παρ, 16/08/2019 - 21:00 έως Κυρ, 18/08/2019 - 23:30](/events/8i-ekthesi-topikon-proionton-stin-plateia-anilioy "8η Έκθεση Τοπικών Προϊόντων στην Πλατεία Ανηλίου")

### Πρόσκληση Ορκωμοσίας Νέας Δημοτικής Αρχής 2019

[Πέμ, 29/08/2019 - 19:00 έως Παρ, 30/08/2019 - 18:45](/events/prosklisi-orkomosias-neas-dimotikis-arhis-2019 "Πρόσκληση Ορκωμοσίας Νέας Δημοτικής Αρχής 2019")

### 3η γιορτή μανιταριού και βοτάνων στη Μακρυράχη

[Σάβ, 12/10/2019 - 19:00 έως Δευ, 14/10/2019 - 14:45](/events/3i-giorti-manitarioy-kai-votanon-sti-makryrahi "3η γιορτή μανιταριού και βοτάνων στη Μακρυράχη")

### Γιορτή Κάστανου 2019 στο Ξορύχτι Πηλίου

[Σάβ, 26/10/2019 - 10:00 έως Τρί, 29/10/2019 - 20:45](/events/giorti-kastanoy-2019-sto-xoryhti-pilioy-0 "Γιορτή Κάστανου 2019 στο Ξορύχτι Πηλίου")

### 6η Γιορτή Τσίπουρου στο Μούρεσι Πηλίου

[Σάβ, 02/11/2019 - 12:00 έως Κυρ, 03/11/2019 - 11:45](/events/6i-giorti-tsipoyroy-sto-moyresi-pilioy "6η Γιορτή Τσίπουρου στο Μούρεσι Πηλίου")

### Αφιέρωμα στον Πηλιορείτη Αρχιτέκτονα Άργη Φιλιππίδη

[Τετ, 15/06/2022 - 20:30](/events/afieroma-ston-pilioreiti-arhitektona-argi-filippidi "Αφιέρωμα στον Πηλιορείτη Αρχιτέκτονα Άργη Φιλιππίδη ")

### Πρόγραμμα Pelion Festival 22/7 - 5/8/22

[Παρ, 22/07/2022 - 07:45 έως Παρ, 05/08/2022 - 12:00](/events/programma-pelion-festival-227-5822 "Πρόγραμμα Pelion Festival 22/7 - 5/8/22")

### 20η Γιορτή Κάστανου στο Ξορύχτι 28,29 & 30/10/22

[Παρ, 28/10/2022 - 13:30 έως Κυρ, 30/10/2022 - 18:30](/events/20i-giorti-kastanoy-sto-xoryhti-2829-301022 "20η Γιορτή Κάστανου στο Ξορύχτι 28,29 & 30/10/22")

### 7η Γιορτή Τσίπουρου 5-11-22 στο Μούρεσι

[Σάβ, 05/11/2022 - 12:00](/events/7i-giorti-tsipoyroy-5-11-22-sto-moyresi "7η Γιορτή Τσίπουρου 5-11-22 στο Μούρεσι")

### Έκθεση φωτογραφιών του James Becket στην Ζαγορά

[Τρί, 15/08/2023 - 09:00 έως Σάβ, 30/09/2023 - 21:00](/events/ekthesi-fotografion-toy-james-becket-stin-zagora "Έκθεση φωτογραφιών του James Becket στην Ζαγορά")

### 21η Ετήσια Γιορτή Κάστανου στο Ξουρίχτι

[Σάβ, 28/10/2023 - 09:00 έως Κυρ, 29/10/2023 - 16:00](/events/21i-etisia-giorti-kastanoy-sto-xoyrihti "21η Ετήσια Γιορτή Κάστανου στο Ξουρίχτι ")

### 12η Έκθεση Τοπικών Προϊόντων στις 9 & 10/8/24 Κοινότητα Ανηλίου

[Παρ, 09/08/2024 - 20:00 έως Σάβ, 10/08/2024 - 23:00](/events/12i-ekthesi-topikon-proionton-stis-9-10824-koinotita-anilioy "12η Έκθεση Τοπικών Προϊόντων στις 9 & 10/8/24 Κοινότητα Ανηλίου")

### Δωρεάν Ιατρικές εξετάσεις από Εθελοντές Ιατρούς σε Κινητή Μονάδα (Δημοτικό Σχολείο Πουρίου) Αλλαγή ημερομηνίας 26-3-25

[Τετ, 26/03/2025 - 17:30](/events/dorean-iatrikes-exetaseis-apo-ethelontes-iatroys-se-kiniti-monada-dimotiko-sholeio-poyrioy "Δωρεάν Ιατρικές εξετάσεις από Εθελοντές Ιατρούς σε Κινητή Μονάδα (Δημοτικό Σχολείο Πουρίου) Αλλαγή ημερομηνίας 26-3-25")

### 25ο Διεθνές Φεστιβάλ Πηλίου Πρόγραμμα - 25th International Pelion Festival

[Δευ, 14/07/2025 - 08:15](/events/25o-diethnes-festival-pilioy-programma-25th-international-pelion-festival "25ο Διεθνές Φεστιβάλ Πηλίου Πρόγραμμα - 25th International Pelion Festival")

### 1ο Φεστιβάλ Ανηλίου 30/7/25 - 02/08/25

[Τετ, 30/07/2025 - 20:00 έως Σάβ, 02/08/2025 - 23:30](/events/1o-festival-anilioy-30725-020825 "1ο Φεστιβάλ Ανηλίου 30/7/25 - 02/08/25")

[![Εγγραφή στο Ατζέντα Εκδηλώσεων](https://www.dimos-zagoras-mouresiou.gr/misc/feed.png)](https://www.dimos-zagoras-mouresiou.gr/ekdilwseis_feed "Εγγραφή στο Ατζέντα Εκδηλώσεων")

## Ερωτηματολόγιο Ικανοποίησης Επισκεπτών

[Πείτε μας τη γνώμη σας](/webform/erotimatologio-ikanopoiisis-episkepton)

## Βρίσκεστε εδώ

1. [Αρχική](/)
»2. [Δημότες](/menu-tree/456)

[Αρχή σελίδας](#Top "Αρχή σελίδας")

## Σχετικά με το Δήμο

Ο Δήμος Ζαγοράς - Μουρεσίου προέρχεται από τη συνένωση των δύο Δημοτικών Ενοτήτων Ζαγοράς, Μουρεσίου.

* [Διαβάστε περισσότερα](?q=content/dimotikes-enotites "Διαβάστε περισσότερα")

## Άλμπουμ

* [![](https://www.dimos-zagoras-mouresiou.gr/sites/default/files/styles/gallery/public/field/image/slider/0809.jpg?itok=wcPusx0f)](https://www.dimos-zagoras-mouresiou.gr/sites/default/files/styles/gallery_colorbox/public/field/image/slider/0809.jpg?itok=xjl6lOBZ "Άποψη του Αγίου Δημητρίου")
* [![](https://www.dimos-zagoras-mouresiou.gr/sites/default/files/styles/gallery/public/field/image/slider/slider-2.jpg?itok=jQGpSTQX)](https://www.dimos-zagoras-mouresiou.gr/sites/default/files/styles/gallery_colorbox/public/field/image/slider/slider-2.jpg?itok=80Od8BTF "Παραλία Χορευτού")
* [![](https://www.dimos-zagoras-mouresiou.gr/sites/default/files/styles/gallery/public/field/image/slider/slider-3.jpg?itok=vj-1vQ0T)](https://www.dimos-zagoras-mouresiou.gr/sites/default/files/styles/gallery_colorbox/public/field/image/slider/slider-3.jpg?itok=_3d5ydlS "Άποψη της Ζαγοράς")
* [![](https://www.dimos-zagoras-mouresiou.gr/sites/default/files/styles/gallery/public/field/image/slider/slider-1.jpg?itok=92o3r0fS)](https://www.dimos-zagoras-mouresiou.gr/sites/default/files/styles/gallery_colorbox/public/field/image/slider/slider-1.jpg?itok=gyOgyLFu "Παραλία Αγίων Σαράντα")
* [![](https://www.dimos-zagoras-mouresiou.gr/sites/default/files/styles/gallery/public/field/image/slider/slider-4.jpg?itok=iHLOHFK-)](https://www.dimos-zagoras-mouresiou.gr/sites/default/files/styles/gallery_colorbox/public/field/image/slider/slider-4.jpg?itok=7_mcRj95 "Πλατεία του Κισσού με την Αγ. Μαρίνα")
* [![](https://www.dimos-zagoras-mouresiou.gr/sites/default/files/styles/gallery/public/field/image/slider/h2_0.jpg?itok=ELWFJZcQ)](https://www.dimos-zagoras-mouresiou.gr/sites/default/files/styles/gallery_colorbox/public/field/image/slider/h2_0.jpg?itok=Cc89-F5Q "Μυλοπόταμος - Παραλία της Τσαγκαράδας")

* [Twitter](http://www.twitter.com "Twitter")
* [Facebook](http://www.facebook.com "Facebook")
* [Goole](# "Goole")

Copyright © 2014 Δήμος Ζαγοράς - Μουρεσίου. [Όροι χρήσης – Προστασία Προσωπικών Δεδομένων](/node/7). 
Σχεδιασμός και δημιουργία από την [ΓΝΩΣΙΣ Computers](http://www.gnosis.com.gr "www.gnosis.com.gr")

## Δημότες

* [Νέα - Ανακοινώσεις](https://www.dimos-zagoras-mouresiou.gr/tracker_news)
* [Ατζέντα Εκδηλώσεων](https://www.dimos-zagoras-mouresiou.gr/fullcalendar)
* [Δικαιώματα του πολίτη](https://www.dimos-zagoras-mouresiou.gr/content/dikaiomata-toy-politi)
* [Κ.Ε.Π.](https://www.dimos-zagoras-mouresiou.gr/content/kep)

## Επισκέπτες

* [Φωτογραφίες](https://www.dimos-zagoras-mouresiou.gr/tracker_album)

## Επικοινωνία

Δήμος Ζαγοράς - Μουρεσίου (Δημοτικές Ενότητες Ζαγοράς και Μουρεσίου).

Τηλέφωνο: 24263 50103Τ.Κ.: 37001Email: [dzag.mour@gmail.com](mailto:dzag.mour@gmail.com)

<!--//--><![CDATA[//><!--
window.eu\_cookie\_compliance\_cookie\_name = "";
//--><!]]>