window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'G-SCDSBP0PBR');

Προβολές Σήμερα - ΒΟΛΟΣ | CinePortal

{
"@context": "https://schema.org",
"@type": "WebSite",
"name": "CinePortal",
"url": "https://cineportal.gr/bolos/",
"description": "Προβολές ταινιών στους κινηματογράφους της ΒΟΛΟΣ"
}

/\* --- VARIABLES: MODERN CINEMA THEME --- \*/
:root {
--bg-color: #0a0a0a;
--card-bg: rgba(18, 18, 18, 0.95);
--text-main: #ffffff;
--text-muted: #b3b3b3;
--accent-color: #E50914;
--accent-hover: #ff1f2a;
--badge-bg: rgba(38, 38, 38, 0.8);
--radius: 12px;
--card-glow: 0 8px 32px rgba(229, 9, 20, 0.3);
--gradient-overlay: linear-gradient(180deg, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.4) 50%, rgba(0,0,0,0.9) 100%);
}
\* {
box-sizing: border-box;
margin: 0;
padding: 0;
}
body {
font-family: 'Roboto', sans-serif;
background-color: var(--bg-color);
color: var(--text-main);
line-height: 1.6;
position: relative;
}
body::before {
content: '';
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background-image: url('/static/back\_drop\_home.webp');
background-size: cover;
background-position: center;
background-repeat: no-repeat;
background-attachment: fixed;
opacity: 0.5;
z-index: -2;
}
body::after {
content: '';
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background: var(--gradient-overlay);
z-index: -1;
}
/\* --- HEADER --- \*/
header {
background: rgba(0, 0, 0, 0.85);
backdrop-filter: blur(20px);
-webkit-backdrop-filter: blur(20px);
padding: 20px 0;
position: sticky;
top: 0;
z-index: 100;
border-bottom: 1px solid rgba(229, 9, 20, 0.3);
box-shadow: 0 4px 30px rgba(0, 0, 0, 0.5);
transition: all 0.3s ease;
}
/\* --- FOOTER --- \*/
footer {
background: rgba(0, 0, 0, 0.85);
backdrop-filter: blur(20px);
-webkit-backdrop-filter: blur(20px);
padding: 30px 0;
margin-top: 60px;
border-top: 1px solid rgba(229, 9, 20, 0.3);
box-shadow: 0 -4px 30px rgba(0, 0, 0, 0.5);
}
.footer-content {
max-width: 1200px;
margin: 0 auto;
padding: 0 20px;
text-align: center;
}
.footer-email {
color: var(--text-main);
font-size: 1rem;
font-weight: 500;
text-decoration: none;
transition: all 0.3s ease;
display: inline-flex;
align-items: center;
gap: 8px;
}
.footer-email:hover {
color: var(--accent-color);
text-shadow: 0 0 10px rgba(229, 9, 20, 0.5);
}
.footer-email i {
color: var(--accent-color);
}
.header-content {
max-width: 1200px;
margin: 0 auto;
padding: 0 20px;
display: flex;
justify-content: center;
align-items: center;
}
.logo {
font-size: 2.5rem;
font-weight: 900;
text-transform: uppercase;
letter-spacing: 3px;
transition: all 0.3s ease;
text-decoration: none;
cursor: pointer;
display: inline-flex;
align-items: center;
gap: 12px;
}
.logo .fa-film {
color: var(--accent-color);
font-size: 2.2rem;
filter: drop-shadow(0 0 8px rgba(229, 9, 20, 0.7));
transition: filter 0.3s ease;
}
.logo-cine {
color: var(--accent-color);
text-shadow: 0 0 12px rgba(229, 9, 20, 0.6), 0 0 24px rgba(229, 9, 20, 0.3);
}
.logo-portal {
color: #fff;
text-shadow: 0 0 12px rgba(255, 255, 255, 0.4), 0 0 24px rgba(255, 255, 255, 0.2);
}
.logo:hover .fa-film {
filter: drop-shadow(0 0 14px rgba(229, 9, 20, 0.9));
}
.logo:hover .logo-cine {
text-shadow: 0 0 18px rgba(229, 9, 20, 0.8), 0 0 32px rgba(229, 9, 20, 0.4);
}
.logo:hover .logo-portal {
text-shadow: 0 0 18px rgba(255, 255, 255, 0.6), 0 0 32px rgba(255, 255, 255, 0.3);
}
.logo:hover {
transform: scale(1.03);
}
/\* --- HERO SECTION --- \*/
.hero-section {
text-align: center;
padding: 10px 20px 8px;
margin-bottom: 10px;
position: relative;
}
.hero-title {
font-size: 3.5rem;
font-weight: 900;
color: white;
margin-bottom: 15px;
text-shadow: 0 4px 20px rgba(0, 0, 0, 0.8), 0 0 30px rgba(229, 9, 20, 0.3);
letter-spacing: 2px;
text-transform: uppercase;
}
.hero-subtitle {
font-size: 1.2rem;
color: var(--text-muted);
font-weight: 300;
letter-spacing: 1px;
}
.hero-accent {
color: var(--accent-color);
text-shadow: 0 0 20px rgba(229, 9, 20, 0.6);
}
/\* --- MAIN CONTAINER --- \*/
.container {
max-width: 1200px;
margin: 0 auto;
padding: 5px 20px;
}
h1.section-title {
margin-bottom: 10px;
font-size: 2.5rem;
color: white;
text-align: center;
text-transform: uppercase;
font-weight: 900;
letter-spacing: 3px;
text-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
position: relative;
padding-bottom: 8px;
}
h1.section-title::after {
content: '';
position: absolute;
bottom: 0;
left: 50%;
transform: translateX(-50%);
width: 100px;
height: 4px;
background: linear-gradient(90deg, transparent, var(--accent-color), transparent);
border-radius: 2px;
}
/\* Day Section \*/
.day-section {
margin-bottom: 40px;
}
.day-section:last-child {
margin-bottom: 0;
}
.day-header {
margin-bottom: 20px;
}
.day-title {
font-size: 1.8rem;
font-weight: 700;
color: white;
margin-bottom: 8px;
padding: 15px 20px;
background: var(--card-bg);
border-left: 5px solid var(--accent-color);
border-radius: var(--radius);
display: flex;
align-items: center;
gap: 15px;
box-shadow: var(--card-glow);
}
.day-title i {
color: var(--accent-color);
font-size: 1.5rem;
}
.day-label {
text-transform: uppercase;
letter-spacing: 2px;
font-weight: 900;
}
.day-label.today {
color: var(--accent-color);
text-shadow: 0 0 10px rgba(229, 9, 20, 0.6);
}
.day-label.tomorrow {
color: #3b82f6;
}
.day-date {
margin-left: auto;
font-size: 1.5rem;
font-weight: 800;
color: white;
letter-spacing: 1px;
}
/\* City Section \*/
.city-section {
margin-bottom: 15px;
}
.city-section:last-child {
margin-bottom: 0;
}
.city-title {
font-size: 1.8rem;
font-weight: 700;
color: white;
margin-bottom: 8px;
padding-bottom: 6px;
border-bottom: 2px solid var(--accent-color);
text-transform: uppercase;
letter-spacing: 2px;
}
/\* --- GRID LAYOUT --- \*/
.movies-grid {
display: grid;
grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
gap: 12px;
animation: fadeInUp 0.6s ease-out;
align-items: stretch;
}
/\* Auto Ads / οποιοδήποτε μη-card μέσα στο grid: πλήρης σειρά, το card πάει από κάτω \*/
.movies-grid > :not(.movie-card) {
grid-column: 1 / -1;
width: 100% !important;
max-width: 100%;
min-width: 0;
box-sizing: border-box;
justify-self: stretch;
}
.movies-grid > .movie-card {
min-width: 0;
width: 100%;
}
@keyframes fadeInUp {
from {
opacity: 0;
transform: translateY(30px);
}
to {
opacity: 1;
transform: translateY(0);
}
}
.movie-card {
animation: fadeIn 0.6s ease-out;
animation-fill-mode: both;
}
.movie-card:nth-child(1) { animation-delay: 0.1s; }
.movie-card:nth-child(2) { animation-delay: 0.2s; }
.movie-card:nth-child(3) { animation-delay: 0.3s; }
.movie-card:nth-child(4) { animation-delay: 0.4s; }
.movie-card:nth-child(5) { animation-delay: 0.5s; }
.movie-card:nth-child(6) { animation-delay: 0.6s; }
@keyframes fadeIn {
from {
opacity: 0;
transform: translateY(20px);
}
to {
opacity: 1;
transform: translateY(0);
}
}
@media (min-width: 1400px) {
.movies-grid {
grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
}
}
/\* --- MOVIE CARD --- \*/
.movie-card {
cursor: pointer;
transition: transform 0.3s ease;
position: relative;
display: flex;
flex-direction: column;
height: 100%;
}
.movie-card:hover {
transform: translateY(-5px);
}
/\* Overlay link που καλύπτει όλο το card \*/
.movie-card-link {
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 100%;
z-index: 1;
text-decoration: none;
}
/\* Τα links και buttons μέσα στο card πρέπει να έχουν z-index πιο ψηλά \*/
.cinema-button,
.btn-book {
position: relative;
z-index: 10;
}
.poster-wrapper {
position: relative;
margin-bottom: 8px;
border-radius: 4px;
overflow: visible;
}
.poster,
.card-image img {
width: 100%;
aspect-ratio: 2/3;
object-fit: cover;
border-radius: 4px;
box-shadow: 0 15px 40px rgba(0,0,0,0.6), 0 5px 15px rgba(0,0,0,0.4);
display: block;
}
.card-image {
position: relative;
overflow: hidden;
}
.rating-badge {
position: absolute;
top: 10px;
right: 10px;
width: 35px;
height: 35px;
background-color: #dc2626;
color: white;
border-radius: 50%;
display: flex;
align-items: center;
justify-content: center;
font-size: 12px;
font-weight: bold;
box-shadow: 0 4px 10px rgba(220, 38, 38, 0.4);
z-index: 2;
}
.card-content {
padding: 0;
display: flex;
flex-direction: column;
flex-grow: 1;
}
.movie-title {
font-size: 15px;
font-weight: 600;
margin-bottom: 3px;
color: var(--text-main);
line-height: 1.3;
}
.movie-info {
display: none;
}
.movie-genre {
font-size: 13px;
color: var(--text-muted);
margin-bottom: 5px;
}
.showtimes-label {
font-size: 16px;
color: var(--text-muted);
margin-bottom: 4px;
font-weight: 500;
display: flex;
align-items: center;
gap: 4px;
}
.showtimes-label i {
color: var(--accent-color);
font-size: 10px;
}
.cinema-name-link {
color: var(--text-muted);
text-decoration: none;
transition: all 0.2s ease;
cursor: pointer;
}
.cinema-name-link:hover {
color: var(--accent-color);
text-shadow: 0 0 10px rgba(229, 9, 20, 0.5);
}
.times-list {
display: flex;
flex-wrap: wrap;
gap: 4px;
margin-bottom: 6px;
}
.cinema-section {
margin-bottom: 6px;
}
.cinema-section:last-child {
margin-bottom: 0;
}
/\* Cinema Button \*/
.cinema-button {
display: block;
margin-bottom: 6px;
text-decoration: none;
background: rgba(38, 38, 38, 0.6);
border: 1px solid rgba(255, 255, 255, 0.1);
border-radius: 4px;
padding: 8px 12px;
transition: all 0.2s ease;
cursor: pointer;
outline: none !important;
box-shadow: none !important;
}
.cinema-button:visited,
.cinema-button:visited:hover,
.cinema-button:visited:focus {
background: rgba(38, 38, 38, 0.6) !important;
border-color: rgba(255, 255, 255, 0.1) !important;
color: var(--text-main) !important;
}
.cinema-button:focus,
.cinema-button:focus:hover,
.cinema-button:focus:visited,
.cinema-button:focus-visible {
background: rgba(38, 38, 38, 0.6) !important;
border-color: rgba(255, 255, 255, 0.1) !important;
outline: none !important;
box-shadow: none !important;
color: var(--text-main) !important;
}
.cinema-button:link {
background: rgba(38, 38, 38, 0.6);
border-color: rgba(255, 255, 255, 0.1);
color: var(--text-main);
}
.cinema-button:hover:not(:visited):not(:focus) {
background: var(--accent-color);
border-color: var(--accent-color);
transform: translateY(-1px);
}
.cinema-button:active {
background: var(--accent-color);
border-color: var(--accent-color);
}
.cinema-button:last-child {
margin-bottom: 0;
}
.cinema-button-content {
display: flex;
flex-direction: column;
gap: 6px;
}
.cinema-button-name {
font-size: 14px;
font-weight: 600;
color: var(--text-main);
display: flex;
align-items: center;
gap: 6px;
}
.cinema-button-name i {
color: var(--accent-color);
font-size: 12px;
}
.cinema-button:hover:not(:visited):not(:focus) .cinema-button-name i {
color: white;
}
.cinema-button:visited .cinema-button-name i,
.cinema-button:focus .cinema-button-name i {
color: var(--accent-color) !important;
}
.cinema-button-times {
display: flex;
flex-wrap: wrap;
gap: 4px;
}
.time-pill {
background: rgba(38, 38, 38, 0.6);
color: #ddd;
padding: 3px 8px;
border-radius: 3px;
font-size: 14px;
font-weight: 500;
cursor: pointer;
transition: all 0.2s ease;
border: 1px solid rgba(255, 255, 255, 0.1);
}
.time-pill:hover {
background: var(--accent-color);
border-color: var(--accent-color);
color: white;
}
.hall-label {
color: var(--accent-color);
font-size: 12px;
font-weight: 600;
margin-left: 4px;
}
.time-pill:hover .hall-label {
color: white;
}
.btn-book {
margin-top: 5px;
background: var(--accent-color);
color: white;
border: none;
padding: 6px 10px;
width: 100%;
border-radius: 4px;
font-weight: 600;
text-transform: uppercase;
cursor: pointer;
transition: all 0.2s ease;
display: flex;
justify-content: center;
align-items: center;
gap: 6px;
text-decoration: none;
letter-spacing: 0.5px;
font-size: 11px;
}
.btn-book:hover {
background: #ff1f2a;
transform: translateY(-1px);
}
::-webkit-scrollbar {
width: 10px;
}
::-webkit-scrollbar-track {
background: #000;
}
::-webkit-scrollbar-thumb {
background: #333;
border-radius: 5px;
}
::-webkit-scrollbar-thumb:hover {
background: var(--accent-color);
}
@media (max-width: 768px) {
.hero-title {
font-size: 2.5rem;
}
.hero-subtitle {
font-size: 1rem;
}
.movies-grid {
grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
gap: 12px;
}
h1.section-title {
font-size: 2rem;
}
}
@media (max-width: 600px) {
.header-content {
flex-direction: column;
gap: 15px;
}
h1.section-title {
font-size: 1.8rem;
letter-spacing: 2px;
}
.hero-title {
font-size: 2rem;
letter-spacing: 1px;
}
.hero-section {
padding: 8px 20px 5px;
}
.movies-grid {
grid-template-columns: repeat(2, 1fr);
gap: 10px;
align-items: stretch;
}
.movie-card {
height: 100%;
}
.card-content {
flex-grow: 1;
display: flex;
flex-direction: column;
}
.btn-book {
margin-top: auto;
}
.logo {
font-size: 1.9rem;
letter-spacing: 2px;
}
.day-title {
font-size: 1.2rem;
padding: 12px 15px;
flex-direction: row;
align-items: center;
gap: 8px;
flex-wrap: nowrap;
white-space: nowrap;
}
.day-title i {
font-size: 1.2rem;
}
.day-label {
font-size: 1.1rem;
font-weight: 800;
letter-spacing: 1px;
}
.day-date {
margin-left: auto;
font-size: 1.1rem;
font-weight: 800;
}
.cinema-button {
-webkit-tap-highlight-color: transparent;
-webkit-touch-callout: none;
-webkit-user-select: none;
user-select: none;
}
.cinema-button:active,
.cinema-button:focus,
.cinema-button:focus-visible {
outline: none !important;
box-shadow: none !important;
-webkit-tap-highlight-color: transparent;
}
}
/\* Touch devices \*/
@media (hover: none) and (pointer: coarse) {
.cinema-button {
-webkit-tap-highlight-color: transparent;
-webkit-touch-callout: none;
}
.cinema-button:active,
.cinema-button:focus,
.cinema-button:focus-visible,
.cinema-button:visited {
outline: none !important;
box-shadow: none !important;
-webkit-tap-highlight-color: transparent;
}
}
.empty-state {
text-align: center;
padding: 100px 20px;
color: var(--text-muted);
background: rgba(18, 18, 18, 0.5);
backdrop-filter: blur(10px);
border-radius: var(--radius);
border: 1px solid rgba(255, 255, 255, 0.1);
}
.empty-state i {
font-size: 5rem;
color: var(--accent-color);
margin-bottom: 30px;
opacity: 0.7;
animation: pulse 2s ease-in-out infinite;
}
@keyframes pulse {
0%, 100% {
opacity: 0.7;
transform: scale(1);
}
50% {
opacity: 1;
transform: scale(1.1);
}
}
.empty-state h3 {
font-size: 1.8rem;
color: white;
margin-bottom: 15px;
font-weight: 700;
}
.empty-state p {
font-size: 1.1rem;
color: var(--text-muted);
}
/\* --- UNIFIED SEARCH --- \*/
.unified-search-container {
max-width: 1200px;
margin: 15px auto 0;
padding: 0 20px;
position: relative;
}
.unified-search-wrapper {
position: relative;
max-width: 600px;
margin: 0 auto;
}
.unified-search-input {
width: 100%;
padding: 16px 50px 16px 20px;
font-size: 16px;
background: rgba(18, 18, 18, 0.95);
backdrop-filter: blur(10px);
color: white;
border: 2px solid rgba(255, 255, 255, 0.2);
border-radius: 30px;
outline: none;
transition: all 0.3s ease;
font-family: 'Roboto', sans-serif;
}
.unified-search-input::placeholder {
color: rgba(255, 255, 255, 0.5);
}
.unified-search-input:focus {
border-color: var(--accent-color);
box-shadow: 0 0 0 4px rgba(229, 9, 20, 0.2), 0 8px 32px rgba(0, 0, 0, 0.5);
background: rgba(18, 18, 18, 1);
}
.unified-search-icon {
position: absolute;
right: 20px;
top: 50%;
transform: translateY(-50%);
color: var(--accent-color);
font-size: 18px;
pointer-events: none;
}
.search-results-dropdown {
position: absolute;
top: calc(100% + 10px);
left: 0;
right: 0;
background: rgba(18, 18, 18, 0.98);
backdrop-filter: blur(20px);
border-radius: 12px;
box-shadow: 0 8px 32px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.1);
max-height: 500px;
overflow-y: auto;
z-index: 1000;
display: none;
}
.search-results-dropdown.show {
display: block;
animation: fadeInDown 0.2s ease-out;
}
@keyframes fadeInDown {
from {
opacity: 0;
transform: translateY(-10px);
}
to {
opacity: 1;
transform: translateY(0);
}
}
.search-category {
padding: 12px 16px;
border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}
.search-category:last-child {
border-bottom: none;
}
.search-category-title {
font-size: 12px;
font-weight: 700;
color: var(--accent-color);
text-transform: uppercase;
letter-spacing: 1px;
margin-bottom: 8px;
display: flex;
align-items: center;
gap: 6px;
}
.search-result-item {
display: flex;
align-items: center;
gap: 12px;
padding: 12px;
cursor: pointer;
transition: all 0.2s ease;
border-radius: 8px;
margin-bottom: 4px;
}
.search-result-item:hover {
background: rgba(229, 9, 20, 0.1);
transform: translateX(4px);
}
.search-result-icon {
color: var(--accent-color);
font-size: 18px;
width: 24px;
text-align: center;
}
.search-result-content {
flex: 1;
}
.search-result-title {
font-size: 15px;
font-weight: 600;
color: white;
margin-bottom: 2px;
}
.search-result-subtitle {
font-size: 13px;
color: var(--text-muted);
}
.search-empty {
padding: 30px;
text-align: center;
color: var(--text-muted);
font-size: 14px;
}

[CINEPORTAL](/)

# ΒΟΛΟΣ

Δείτε το πρόγραμμα προβολών των κινηματογράφων της πόλης

## ΣΗΜΕΡΑ 29/09/2026

![Αφίσα ταινίας ΕΚΔΙΚΗΤΕΣ: Η ΤΕΛΕΥΤΑΙΑ ΠΡΑΞΗ](https://image.tmdb.org/t/p/w500/nAMWcCVH6RZczERv6ATD6aJlPUP.jpg)
8,2

## ΕΚΔΙΚΗΤΕΣ: Η ΤΕΛΕΥΤΑΙΑ ΠΡΑΞΗ

[VILLAGE CINEMAS VOLOS 18:00 Αίθουσα: 4 21:45 Αίθουσα: 4](/bolos/village-cinemas-volos/)
[ΠΛΗΡΟΦΟΡΙΕΣ](/tainia/avengers-i-teleytaia-praxi-encore/)

![Αφίσα ταινίας ΣΟΝ ΤΟ ΠΡΟΒΑΤΟ ΚΑΙ ΤΟ ΤΕΡΑΣ ΤΗΣ ΦΑΡΜΑΣ](https://image.tmdb.org/t/p/w500/911mZmR41QUbsOk9MlzNT9WYRi1.jpg)
6,6

## ΣΟΝ ΤΟ ΠΡΟΒΑΤΟ ΚΑΙ ΤΟ ΤΕΡΑΣ ΤΗΣ ΦΑΡΜΑΣ

[VILLAGE CINEMAS VOLOS 18:15 Αίθουσα: 2](/bolos/village-cinemas-volos/)
[ΠΛΗΡΟΦΟΡΙΕΣ](/tainia/son-to-probato-kai-to-teras-tis-farmas/)

![Αφίσα ταινίας MINIONS & ΤΕΡΑΤΑ](https://image.tmdb.org/t/p/w500/zyVkAF2ndPODAUGcaBKx5zBjZ1B.jpg)
7,6

## MINIONS & ΤΕΡΑΤΑ

[VILLAGE CINEMAS VOLOS 18:30 Αίθουσα: 3](/bolos/village-cinemas-volos/)
[ΠΛΗΡΟΦΟΡΙΕΣ](/tainia/minions-terata/)

![Αφίσα ταινίας ΣΤΗΝ ΚΑΡΔΙΑ ΤΟΥ ΚΤΗΝΟΥΣ](https://image.tmdb.org/t/p/w500/1ApfSA8JTqeha3GTFEY8syV4auq.jpg)
7,7

## ΣΤΗΝ ΚΑΡΔΙΑ ΤΟΥ ΚΤΗΝΟΥΣ

[VILLAGE CINEMAS VOLOS 19:00 Αίθουσα: 1 21:20 Αίθουσα: 1](/bolos/village-cinemas-volos/)
[ΕΞΩΡΑΙΣΤΙΚΗ ΘΕΡΙΝΟΣ 20:30 Αίθουσα: 1](/bolos/exoraistiki-therinos/)
[ΠΛΗΡΟΦΟΡΙΕΣ](/tainia/stin-kardia-toy-ktinoys/)

![Αφίσα ταινίας RESIDENT EVIL](https://image.tmdb.org/t/p/w500/i7UyjfPio0VFHB9rBUZSFyhOoM8.jpg)
8,1

## RESIDENT EVIL

[VILLAGE CINEMAS VOLOS 20:15 Αίθουσα: 2 22:30 Αίθουσα: 2](/bolos/village-cinemas-volos/)
[ΠΛΗΡΟΦΟΡΙΕΣ](/tainia/resident-evil/)

![Αφίσα ταινίας ΟΔΥΣΣΕΙΑ](https://image.tmdb.org/t/p/w500/5rhTDKUhPYvpdQIijFIs5VoWsON.jpg)
10,0

## ΟΔΥΣΣΕΙΑ

[VILLAGE CINEMAS VOLOS 20:40 Αίθουσα: 3](/bolos/village-cinemas-volos/)
[ΠΛΗΡΟΦΟΡΙΕΣ](/tainia/odysseia/)

## ΑΥΡΙΟ 30/09/2026

![Αφίσα ταινίας ΕΚΔΙΚΗΤΕΣ: Η ΤΕΛΕΥΤΑΙΑ ΠΡΑΞΗ](https://image.tmdb.org/t/p/w500/nAMWcCVH6RZczERv6ATD6aJlPUP.jpg)
8,2

## ΕΚΔΙΚΗΤΕΣ: Η ΤΕΛΕΥΤΑΙΑ ΠΡΑΞΗ

[VILLAGE CINEMAS VOLOS 18:00 Αίθουσα: 4 21:45 Αίθουσα: 4](/bolos/village-cinemas-volos/)
[ΠΛΗΡΟΦΟΡΙΕΣ](/tainia/avengers-i-teleytaia-praxi-encore/)

![Αφίσα ταινίας ΣΟΝ ΤΟ ΠΡΟΒΑΤΟ ΚΑΙ ΤΟ ΤΕΡΑΣ ΤΗΣ ΦΑΡΜΑΣ](https://image.tmdb.org/t/p/w500/911mZmR41QUbsOk9MlzNT9WYRi1.jpg)
6,6

## ΣΟΝ ΤΟ ΠΡΟΒΑΤΟ ΚΑΙ ΤΟ ΤΕΡΑΣ ΤΗΣ ΦΑΡΜΑΣ

[VILLAGE CINEMAS VOLOS 18:15 Αίθουσα: 2](/bolos/village-cinemas-volos/)
[ΠΛΗΡΟΦΟΡΙΕΣ](/tainia/son-to-probato-kai-to-teras-tis-farmas/)

![Αφίσα ταινίας MINIONS & ΤΕΡΑΤΑ](https://image.tmdb.org/t/p/w500/zyVkAF2ndPODAUGcaBKx5zBjZ1B.jpg)
7,6

## MINIONS & ΤΕΡΑΤΑ

[VILLAGE CINEMAS VOLOS 18:30 Αίθουσα: 3](/bolos/village-cinemas-volos/)
[ΠΛΗΡΟΦΟΡΙΕΣ](/tainia/minions-terata/)

![Αφίσα ταινίας ΣΤΗΝ ΚΑΡΔΙΑ ΤΟΥ ΚΤΗΝΟΥΣ](https://image.tmdb.org/t/p/w500/1ApfSA8JTqeha3GTFEY8syV4auq.jpg)
7,7

## ΣΤΗΝ ΚΑΡΔΙΑ ΤΟΥ ΚΤΗΝΟΥΣ

[VILLAGE CINEMAS VOLOS 19:00 Αίθουσα: 1 21:20 Αίθουσα: 1](/bolos/village-cinemas-volos/)
[ΕΞΩΡΑΙΣΤΙΚΗ ΘΕΡΙΝΟΣ 20:30 Αίθουσα: 1](/bolos/exoraistiki-therinos/)
[ΠΛΗΡΟΦΟΡΙΕΣ](/tainia/stin-kardia-toy-ktinoys/)

![Αφίσα ταινίας RESIDENT EVIL](https://image.tmdb.org/t/p/w500/i7UyjfPio0VFHB9rBUZSFyhOoM8.jpg)
8,1

## RESIDENT EVIL

[VILLAGE CINEMAS VOLOS 20:15 Αίθουσα: 2 22:30 Αίθουσα: 2](/bolos/village-cinemas-volos/)
[ΠΛΗΡΟΦΟΡΙΕΣ](/tainia/resident-evil/)

![Αφίσα ταινίας ΟΔΥΣΣΕΙΑ](https://image.tmdb.org/t/p/w500/5rhTDKUhPYvpdQIijFIs5VoWsON.jpg)
10,0

## ΟΔΥΣΣΕΙΑ

[VILLAGE CINEMAS VOLOS 20:40 Αίθουσα: 3](/bolos/village-cinemas-volos/)
[ΠΛΗΡΟΦΟΡΙΕΣ](/tainia/odysseia/)

// Stop event propagation για cinema buttons
document.querySelectorAll('.cinema-button').forEach(function(button) {
button.addEventListener('click', function(e) {
e.stopPropagation();
// Αφαιρούμε το focus αμέσως μετά το click
setTimeout(function() {
button.blur();
button.style.outline = 'none';
button.style.boxShadow = 'none';
}, 0);
});
button.addEventListener('touchstart', function() {
this.style.outline = 'none';
this.style.boxShadow = 'none';
});
button.addEventListener('touchend', function() {
setTimeout(function() {
button.blur();
button.style.outline = 'none';
button.style.boxShadow = 'none';
}, 0);
});
// Επαναφορά του button state όταν επιστρέφει στη σελίδα
button.addEventListener('blur', function() {
this.style.background = '';
this.style.borderColor = '';
this.style.outline = 'none';
this.style.boxShadow = 'none';
});
});
// Επαναφορά όλων των buttons όταν φορτώνει η σελίδα
window.addEventListener('pageshow', function(event) {
document.querySelectorAll('.cinema-button').forEach(function(button) {
button.style.background = '';
button.style.borderColor = '';
button.style.color = '';
button.style.outline = 'none';
button.style.boxShadow = 'none';
button.blur();
// Αφαιρούμε το focus state
if (document.activeElement === button) {
button.blur();
}
});
});
// Επαναφορά όταν φορτώνει η σελίδα
window.addEventListener('load', function() {
document.querySelectorAll('.cinema-button').forEach(function(button) {
button.style.outline = 'none';
button.style.boxShadow = 'none';
button.blur();
});
});
// Επαναφορά όταν γίνεται DOMContentLoaded
document.addEventListener('DOMContentLoaded', function() {
document.querySelectorAll('.cinema-button').forEach(function(button) {
button.style.outline = 'none';
button.style.boxShadow = 'none';
});
});

// --- UNIFIED SEARCH AUTCOMPLETE ---
(function() {
const searchInput = document.getElementById('unified-search-input');
const resultsDropdown = document.getElementById('search-results-dropdown');
let searchTimeout;
let currentResults = null;
// Debounce function για να μην κάνουμε πολλά requests
function debounce(func, wait) {
return function(...args) {
clearTimeout(searchTimeout);
searchTimeout = setTimeout(() => func.apply(this, args), wait);
};
}
// Αναζήτηση στο backend
function performSearch(query) {
if (query.length < 2) {
resultsDropdown.classList.remove('show');
return;
}
fetch(`/api/search/?q=${encodeURIComponent(query)}`)
.then(response => response.json())
.then(data => {
currentResults = data;
displayResults(data);
})
.catch(error => {
console.error('Search error:', error);
resultsDropdown.classList.remove('show');
});
}
// Εμφάνιση αποτελεσμάτων
function displayResults(data) {
resultsDropdown.innerHTML = '';
const hasResults = data.cities.length > 0 ||
data.cinemas.length > 0 ||
data.movies.length > 0;
if (!hasResults) {
resultsDropdown.innerHTML = '<div class="search-empty">Δεν βρέθηκαν αποτελέσματα</div>';
resultsDropdown.classList.add('show');
return;
}
// Πόλεις
if (data.cities.length > 0) {
const categoryDiv = document.createElement('div');
categoryDiv.className = 'search-category';
categoryDiv.innerHTML = `
<div class="search-category-title">
<i class="fas fa-map-marker-alt"></i>
Πόλεις
</div>
`;
data.cities.forEach(city => {
const item = document.createElement('div');
item.className = 'search-result-item';
item.innerHTML = `
<i class="fas fa-map-marker-alt search-result-icon"></i>
<div class="search-result-content">
<div class="search-result-title">${escapeHtml(city.name)}</div>
</div>
`;
item.addEventListener('click', () => {
window.location.href = city.url;
});
categoryDiv.appendChild(item);
});
resultsDropdown.appendChild(categoryDiv);
}
// Σινεμά
if (data.cinemas.length > 0) {
const categoryDiv = document.createElement('div');
categoryDiv.className = 'search-category';
categoryDiv.innerHTML = `
<div class="search-category-title">
<i class="fas fa-video"></i>
Σινεμά
</div>
`;
data.cinemas.forEach(cinema => {
const item = document.createElement('div');
item.className = 'search-result-item';
item.innerHTML = `
<i class="fas fa-video search-result-icon"></i>
<div class="search-result-content">
<div class="search-result-title">${escapeHtml(cinema.name)}</div>
<div class="search-result-subtitle">${escapeHtml(cinema.city)}</div>
</div>
`;
item.addEventListener('click', () => {
window.location.href = cinema.url;
});
categoryDiv.appendChild(item);
});
resultsDropdown.appendChild(categoryDiv);
}
// Ταινίες
if (data.movies.length > 0) {
const categoryDiv = document.createElement('div');
categoryDiv.className = 'search-category';
categoryDiv.innerHTML = `
<div class="search-category-title">
<i class="fas fa-film"></i>
Ταινίες
</div>
`;
data.movies.forEach(movie => {
const item = document.createElement('div');
item.className = 'search-result-item';
item.innerHTML = `
<i class="fas fa-film search-result-icon"></i>
<div class="search-result-content">
<div class="search-result-title">${escapeHtml(movie.title)}</div>
</div>
`;
item.addEventListener('click', () => {
window.location.href = movie.url;
});
categoryDiv.appendChild(item);
});
resultsDropdown.appendChild(categoryDiv);
}
resultsDropdown.classList.add('show');
}
// Escape HTML για ασφάλεια
function escapeHtml(text) {
const div = document.createElement('div');
div.textContent = text;
return div.innerHTML;
}
// Event listeners
const debouncedSearch = debounce(performSearch, 300);
searchInput.addEventListener('input', function(e) {
const query = e.target.value.trim();
debouncedSearch(query);
});
searchInput.addEventListener('focus', function() {
if (currentResults) {
displayResults(currentResults);
}
});
// Κλείσιμο dropdown όταν κάνουμε click έξω
document.addEventListener('click', function(e) {
const searchWrapper = searchInput.closest('.unified-search-wrapper');
if (searchWrapper && !searchWrapper.contains(e.target)) {
resultsDropdown.classList.remove('show');
}
});
// Keyboard navigation
searchInput.addEventListener('keydown', function(e) {
if (e.key === 'Escape') {
resultsDropdown.classList.remove('show');
searchInput.blur();
}
});
})();

[info@cineportal.gr](mailto:info@cineportal.gr)
|
[Όροι Χρήσης (Terms & Conditions)](/oroi-xrisis/)
|
[Πολιτική Απορρήτου (Privacy Policy)](/politiki-aporriptou/)