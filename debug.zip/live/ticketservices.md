window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'G-25VP16V8D7');
gtag('config', 'UA-3912369-11');

Υπηρεσία Εισιτηρίων - Ticket Services

var lang = "el";
var \_lang = lang;
var path = "./";
var articleid = 747;
var start\_menu\_id = 7;
var host = 'ticketservices';
var IMAGES\_SITE\_URL = 'https://stream.ticketservices.gr/www.ticketservices.gr';
var PICTURES\_SITE\_URL = 'https://stream.ticketservices.gr/www.ticketservices.gr';
var BANNERS\_SITE\_URL = 'https://stream.ticketservices.gr/www.ticketservices.gr';

function MM\_openBrWindow(theURL,winName,features) { //v2.0
window.open(theURL,winName,features+",resize=yes,menubar=yes,toolbar=no,personalbars=no,scrollbars=yes,status=yes");
}
var fontSizee=13;
function h(x){
document.getElementById(x).style.display='none';
}
function check\_email(e) {
ok = "1234567890qwertyuiop[]asdfghjklzxcvbnm.@-\_QWERTYUIOPASDFGHJKLZXCVBNM";
for(i=0; i < e.length ;i++){if(ok.indexOf(e.charAt(i))<0){return (false);}}
if (document.images) {
re = /(@.\*@)|(\.\.)|(^\.)|(^@)|(@$)|(\.$)|(@\.)/;
re\_two = /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
if (!e.match(re) && e.match(re\_two)) {return (-1);}
}
}
function empty\_input(){
if(document.getElementById('search\_input').value=='Search'){
document.getElementById('search\_input').value='';
}
}
function gotoStart(){
window.location.hash="start";
}
function reloadToPath(){
selection=document.getElementById('quick\_sel');
selIndex=selection.selectedIndex;
value=selection.options[selIndex].value;
window.location.href=value;
}
function explode (delimiter, string, limit) {
var emptyArray = { 0: '' };
// third argument is not required
if ( arguments.length < 2 ||
typeof arguments[0] == 'undefined' || typeof arguments[1] == 'undefined' ) {
return null;
}
if ( delimiter === '' || delimiter === false ||
delimiter === null ) {
return false;
}
if ( typeof delimiter == 'function' ||
typeof delimiter == 'object' ||
typeof string == 'function' ||
typeof string == 'object' ) {
return emptyArray; }
if ( delimiter === true ) {
delimiter = '1';
}
if (!limit) {
return string.toString().split(delimiter.toString());
} else {
// support for limit argument var splitted = string.toString().split(delimiter.toString());
var partA = splitted.splice(0, limit - 1);
var partB = splitted.join(delimiter.toString());
partA.push(partB);
return partA; }
}
var thisShowCaptures=0;
var totalShowsCaptured=0;
function updateshortbasket(callback, wantfullupdateplan, usethisdatainsteadofajax, do\_trigger\_updatedshortbasket = true){
var showid = '' + (window.showid >> 0); // Αν είμαστε σε σελίδα παράστασης
function applyBasketData(data) {
// var element\_to\_keep\_track = $('#pickseats\_section')[0]; // 04/02/23
// var oldY = element\_to\_keep\_track.getBoundingClientRect().top + window.scrollY; // 04/02/23
//dlog('top before: ', oldY);
window.last\_applied\_basket\_data = data;
bask=explode('|',data);
thisShowCaptures=bask[2];
totalShowsCaptured=bask[3];
var allItemsCount = bask[5] >> 0; // 20/2/21
var ticketsCount = bask[6] >> 0; // 27/2/21
if(thisShowCaptures>0){
$('#shortbasket').html(bask[0]+"<div id='shortbasketmsg' class='shortbasketmsg'></div><div class='clear'></div>"+ "<form class='removeshow' id='form" + showid + "' method='post' style='padding:0;margin:0;'><input type='hidden' name='showid' value='" + showid + "'><input type='hidden' name='removefromcart' value='1'></form><div class='shortbasket\_buttons'><a href='javascript:;' onclick='return removeAllSeatsFromShow(" + showid + ");' id='btnshortbasketremoveall' class='remove\_full btnshortbasketremoveall cbtn\_plain' >ΑΦΑΙΡΕΣΗ ΟΛΩΝ</a><a id='btnshortbasketcompleteorder' class='completeorder btnshortbasketcompleteorder cbtn\_bold' href='" + path + lang + "/cart/' target='\_parent'>ΟΛΟΚΛΗΡΩΣΗ ΠΑΡΑΓΓΕΛΙΑΣ</a></div><div class='clear'></div>");
} else {
$('#shortbasket').html(bask[0]+"<div id='shortbasketmsg' class='shortbasketmsg'></div><div class='clear'></div>");
}
if(totalShowsCaptured>0){
$('#basketlink').html('<a href="' + path + lang + '/cart/">'+bask[1]+'</a>');
$('body').addClass('ticketspending').removeClass('noticketspending');
} else {
$('#basketlink').html('<a href="javascript:;" class="nolink">'+bask[1]+'</a>');
$('body').addClass('noticketspending').removeClass('ticketspending');
}
// Τελικά δεν δουλεύει και πολύ καλά αυτό το keep scroll position, οπότε ... άστο (false)
/\* false && (thisShowCaptures == 1) && setTimeout(function() {
var newY = element\_to\_keep\_track.getBoundingClientRect().top + window.scrollY;
var difference = oldY - newY; // 04/02/23
dlog('top before: ', oldY);
dlog('top after: ', newY);
window.scrollBy(0, -difference); // 04/02/23
}, 10);\*/
if(window.limitSelectTickets) limitSelectTickets();
if(window.updatePlan) window.updatePlan(wantfullupdateplan);
if(window.newgui) {
//console.log(data, bask, allItemsCount);
// console.log(allItemsCount);
var a = $('a.link\_tocart');
var img = a.find('img.img\_tocart');
var span = a.find('span.text\_tocart');
var cartbtnlabel = lang\_elen('Παραγγελία', 'Check out');
if(ticketsCount >= 1 && ticketsCount <= 9) {
a.removeClass('empty').addClass('hasitems');
img.attr('src', IMAGES\_SITE\_URL + '/images/basket-green' + ticketsCount + '.png');
span.html(cartbtnlabel);
} else if(ticketsCount > 9) {
a.removeClass('empty').addClass('hasitems');
img.attr('src', IMAGES\_SITE\_URL + '/images/basket.png');
span.html('(' + ticketsCount + ') ' + cartbtnlabel);
} else {
a.addClass('empty').removeClass('hasitems');
img.attr('src', IMAGES\_SITE\_URL + '/images/basket.png');
span.html(cartbtnlabel);
}
}
if(callback) callback();
if(do\_trigger\_updatedshortbasket) {
$(document).trigger('updatedshortbasket');
}
}
if(usethisdatainsteadofajax) {
applyBasketData(usethisdatainsteadofajax);
} else {
waiting(true);
$.ajax({
type: 'GET',
url: './showshortbasket.php',
data: 'showid=' + showid,
async: true,
success: function(returnBasketData) {
applyBasketData(returnBasketData);
},
complete: function() {
waiting(false);
}
});
}
}
function fixCapturedSeatsFromShortBasket() {
var seat ;
$('ul#seats li').each(function() {
var li = $(this);
var seatid = li.attr('data-seatid')>>0;
var state = li.attr('data-state')>>0;
var cl = li.attr('class');
if((cl.substr(0, 4)=='hold') && !$('#sb' + seatid).length) {
// δεν είναι πια ελεύθερη
li.attr('class', 'free' + cl.substr(4)).attr('data-state', '0');
seat = seats && seats[seatid];
if(seat) { seat.free = true; seat.mine = false; }
} else if($('#sb' + seatid).length && cl.substr(0, 4) !== 'hold') {
li.attr('class', 'hold' + li.attr('data-zoneid')).attr('data-state', '2');
if(seat) { seat.free = true; seat.mine = true; }
}
});
}
function applyofferprices(showid){
$.ajax({
type: 'GET',
url: './ajax\_applyofferprices.php',
data: 'action=APPLYOFFERPRICES&showid='+showid,
async: true,
success: function(result) {
if(result == 'OK') {
updateshortbasket();
} else {
if(console && console.log) console.log(result);
if(result.indexOf('ERROR\_OFFER\_LIMIT') >= 0) {
var p = result.indexOf('ERROR\_MSG=') + 10;
var n = parseInt(result.substr(p));
if(n > 0) {
alert('Για την συγκεκριμένη παράσταση ο αριθμός των εισιτηρίων που απομένουν για αγορά στην τιμή της προσφοράς είναι:' + n);
} else {
alert('Για την συγκεκριμένη παράσταση έχουν εξαντληθεί τα εισιτήρια της προσφοράς');
}
return ;
}
alert('Δεν ήταν εφικτή η εφαρμογή των τιμών της προσφοράς\nστα εισιτήρια που έχετε επιλέξει\n\nΠαρακαλούμε ελέγξτε αν τα εισιτήρια που έχετε επιλέξει\nikανοποιούν τις προδιαγραφές της προσφοράς\n(πχ αριθμός εισιτηρίων, ζώνη τιμών όπου η προσφορά ισχύει κτλ)\n\nΓια οποιαδήποτε πληροφορία, μπορείτε να επικοινωνήσετε με την Ticket Services στο 2107234567');
}
}
});
}
function applyofferpricesincart(showid){
$.ajax({
type: 'GET',
url: './run.php',
data: 'action=APPLYOFFERPRICES&showid='+showid,
async: true,
success: function(result) {
if(result == 'OK') {
window.location.href = window.location.href.split('#')[0];
} else {
if(console && console.log) console.log(result);
if(result.indexOf('ERROR\_OFFER\_LIMIT') >= 0) {
var p = result.indexOf('ERROR\_MSG=') + 10;
var n = parseInt(result.substr(p));
if(n > 0) {
alert('Για την συγκεκριμένη παράσταση ο αριθμός των εισιτηρίων που απομένουν για αγορά στην τιμή της προσφοράς είναι:' + n);
} else {
alert('Για την συγκεκριμένη παράσταση έχουν εξαντληθεί τα εισιτήρια της προσφοράς');
}
return ;
}
alert('Δεν ήταν εφικτή η εφαρμογή των τιμών της προσφοράς');
}
}
});
}
function removeShow(showid, alterconfirmmsg){
if(alterconfirmmsg) {
var msg = alterconfirmmsg;
} else {
var msg = 'Όλα τα δεσμευμένα εισιτήρια αυτής της εκδήλωσης θα αποδεσμευτούν και θα αφαιρεθούν από την παραγγελία σας. Θέλετε να προχωρήσετε;';
}
if(msg == 'noconfirm') {
$('body').addClass('reloading');
$('#form'+showid).submit();
return false;
}
if(confirm(msg)){
$('body').addClass('reloading');
$('#form'+showid).submit();
return false;
} else {
return false;
}
}
function uncaptureseats(ticketcount){
if(ticketcount==1) {
if(confirm('Θέλετε πράγματι να αποδεσμευτεί το εισιτήριο που επιλέχτηκε;')){
$('#uncaptureseats').submit(); // εδώ το id είναι σωστά #uncaptureseats (πληθ.)
} else {
return false;
}
} else {
if(confirm('Θέλετε πράγματι να αποδεσμευτούν τα εισιτήρια που επιλέχτηκαν;')){
$('#uncaptureseats').submit();
} else {
return false;
}
}
}
function LuhnCheck(str) {
var result = true;var sum = 0;var mul = 1;var strLen = str.length;var c = str.substring(0, 1);
if(str.substring(0, 4) == '4444')
{
// debugging - 31/1/11 - CHRIS
return true;
}
if ( (c!='4') && (c!='5') && (c!='6') && (c!='3') && (c!='2'))
{
alert('Ο αριθμός κάρτας που εισαγάγατε δεν είναι έγκυρος.');
return false;
}
for (i = 0; i < strLen; i++){
var digit = str.substring(strLen-i-1,strLen-i);var tproduct = parseInt(digit ,10)\*mul;
if (tproduct >= 10) sum += (tproduct % 10) + 1;
else sum += tproduct;
if (mul == 1) mul++;
else mul--;
}
if ((sum % 10) != 0) result = false;
if (!result){ alert('Ο αριθμός κάρτας που εισαγάγατε δεν είναι έγκυρος.');}
return result;
}
function numeric(e){
if(e.length != 3){
alert('Ο αριθμός cvv που δηλώσατε δεν είναι έγκυρος (ελέγξτε ότι δώσατε τα τρια τελευταία ψηφία του αριθμού στην πίσω πλευρά της κάρτας).');
return false;
}
ok ="1234567890";
for(i=0; i < e.length ;i++){
if(ok.indexOf(e.charAt(i))<0){
alert('Ο αριθμός cvv που δηλώσατε δεν είναι έγκυρος (ελέγξτε ότι δώσατε τα τρια τελευταία ψηφία του αριθμού στην πίσω πλευρά της κάρτας).');
return false;}
}
if((e>999)||(e<0)){
alert('Ο αριθμός cvv που δηλώσατε δεν είναι έγκυρος (ελέγξτε ότι δώσατε τα τρια τελευταία ψηφία του αριθμού στην πίσω πλευρά της κάρτας).');
return false;
}
return true;
}
function checkAccept() {
var a$ = $('#cbconfirmrules');
if(a$.length == 0) return true; // δεν υπάρχει checkbox
// #@#@#@#@#@#@#@
if(a$.prop && a$.prop('checked')) return true;
//if(a$.prop('checked')) return true;
if(a$.is(':checked')) return true;
$('.acceptnotice').fadeOut('fast', function() {
$('.acceptnotice').fadeIn('fast');
});
return false;
}
function checkForm(){
if(!LuhnCheck(document.proceedtocheckout.ccn.value)){ return false;}
if(!numeric(document.proceedtocheckout.cvccvv.value)){return false;}
if(!checkAccept()) {return false;}
document.proceedtocheckout.submit();
document.getElementById('pr').style.display='none';
document.getElementById('ca').style.display='none';
document.getElementById('chargewait').style.display='block';
return true;
}
function waitreload() {
$('body').addClass('reloading');
window.location.href = window.location.href.split('#')[0];
return false;
// var dw = $(
// "<div style='position:fixed; top:0; left:0; width:100%; height: 100%; z-index:10000; background-color: #0C0C0C;'>"
// + "<div style='position:fixed; display:table; top:0; left:0; width:100%; height: 100%;'>"
// + "<div style=' display: table-cell; width: 100%; height: 100%; vertical-align: middle; text-align: center;'>"
// + "<span style='font-size: 20px;'>Please wait...</span>"
// + "</div></div></div>");
// $('body').append(dw);
// dw.animate( { oppacity: 0.5 }, 'fast', function() {
// window.location.reload();
// });
}

var webuserid = 158764466;
var newgui = true;
useeventfilters = 1;
useonlydatefilters = 1;
var exclude\_eventids = "3916,2541,2567,2561,2596,2820,3029,3114,3095,3096,3097,3098,3099,3196,3232,3255,3333,3466,3589,3797,4106,4130,4152,4190,4364,4374,4318,4528,4639,4640,4641,4642,4643,4644,4645,4646,4647,4648,4649,4650,4651,4702,4820,4872,4974,5231,5382,5406,5451,5501,5517,5534,5577,5754,5757,6022,6043";
var exclude\_firmids = "589";
var lastsearchtext = '';
var searchchangedtimeout = null;
function doSearch(doitnow) {
if(typeof doitnow == 'undefined') doitnow = false;
if(!doitnow) {
clearTimeout(searchchangedtimeout);
searchchangedtimeout = setTimeout(function() { doSearch(true); }, 300);
} else {
clearTimeout(searchchangedtimeout);
var txt = $('#searchbox').val();
if(!txt) clearResults();
if(txt == lastsearchtext) return;
doAjaxSearch();
}
}
function initSearchField()
{
var sf = $('#searchbox');
clearResults();
sf.on('input', function() {
doSearch(false);
});
if(false) sf.bind('keyup', function(e) {
var txt = $('#searchbox').val();
if(!txt) clearResults();
if(txt == lastsearchtext) return;
doAjaxSearch();
return;
});
sf.bind('keyup', function(e) {
var sf = $('#searchbox');
var txt = sf.val();
if(e.which == 27) {
clearSearchInputAndResults();
}
});
}
function closeSearch()
{
//$('#searchboxwrap').fadeOut('fast');
$('#searchboxwrap').slideUp('fast');
$('#searchbox').val('');
$('#searchresults').html('').hide();
$('#searchboxdiv').removeClass('searched');
}
function initResults()
{
$('table.tsearch tr')
.mouseenter( function() { $(this).addClass('mouseover'); })
.mouseleave( function() { $(this).removeClass('mouseover');})
;
}
function clearSearchInputAndResults() {
$('#searchresults').hide().html('');
$('#searchboxdiv').removeClass('searched');
clearTimeout(searchchangedtimeout);
if($('#searchbox').val() == '' && $('body').hasClass('newgui')) {
$('#searchbox').val('');
$('#searchboxwrap').fadeOut('fast');
return ;
}
$('#searchbox').val('').focus();
}
function clearResults()
{
$('#searchresults').hide().html('');
$('#searchboxdiv').removeClass('searched');
}
function doAjaxSearch()
{
var txt = $('#searchbox').val();
lastsearchtext = txt;
if(txt.length > 0)
{
$.ajax({
type: 'POST',
url: '/search.php',
async: true,
cache: false,
contentType: 'application/x-www-form-urlencoded;charset=ISO-8859-7',
data: { isajax: '1', ip: '194.214.183.60', keywords: txt, path: './', lang: 'el'},
success: function(response){
var sr = $('#searchresults');
sr.html(response);
sr.show();
initResults();
$('#searchboxdiv').addClass('searched');
}
});
}
else
{
clearResults();
}
}
$(function() {
// loaded in index.php instead of ajaxing after page load
var shortbasketdata = "<p>Δεν έχετε επιλέξει εισιτήρια για αυτήν την παράσταση.<\/p>|Δεν έχετε επιλεγμένα εισιτήρια|0|0|0|0|0";
updateshortbasket(null, null, shortbasketdata);
})

function changeLanguage(tolang) {
var uri = location && location.href ? location.href : '//www.ticketservices.gr/';
var currentlang = window['\_lang'] || 'el';
if(currentlang != 'el' && currentlang != 'en') currentlang = 'el';
if(typeof tolang == "undefined") {
tolang = currentlang == 'el' ? 'en' : 'el';
}
uri = uri.replace('/' + currentlang + '/', '/' + tolang + '/');
uri = uri.replace('lang=' + currentlang, 'lang=' + tolang);
if(uri.indexOf('/' + tolang + '/') == -1 && uri.indexOf('lang=' + tolang) == -1) {
if(uri.indexOf('?') == -1) {
uri += "?lang=" + tolang;
} else {
uri += "&lang=" + tolang;
}
}
window.location.href = uri;
return uri;
}
$(document).on('click', 'a.changelang', function(e) {
e.preventDefault();
var a = $(this);
var currentlang = window['\_lang'] || 'el';
if(currentlang != 'el' && currentlang != 'en') currentlang = 'el';
var tolang = a.attr('data-lang');
if(currentlang == tolang) return ;
changeLanguage(tolang);
});
$(window).on('jajaxresult', function(e, \_lastjajaxresult) {
//console.log('jajax\_lastjajaxresult: ', arguments);
// triggered at functions.new.js
if(\_lastjajaxresult && \_lastjajaxresult['result'] && \_lastjajaxresult['result']['forceredirecturl']) {
window.top.location.href = \_lastjajaxresult['result']['forceredirecturl'];
}
});

!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f.\_fbq)f.\_fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en\_US/fbevents.js');
if(!window.fbq\_983778949195467\_initialized) {
fbq('init', '983778949195467');
window.fbq\_983778949195467\_initialized = true;
}
fbq('trackSingle', '983778949195467', 'PageView');
![](https://www.facebook.com/tr?id=983778949195467&ev=PageView&noscript=1)

[![](https://stream.ticketservices.gr/www.ticketservices.gr/images/menu_icon.png)![](https://stream.ticketservices.gr/www.ticketservices.gr/images/x-menu-icon.png)](javascript:;)

[![](https://stream.ticketservices.gr/www.ticketservices.gr/images/ts-logo-circle.png "Ticketservices.gr")](./)

$(function() {
$(document).on('click', '.topmenubutton', function(e) {
e.preventDefault();
var body = $('body');
body.toggleClass('topmenuexpanded');
});
});

* [EN](/?lang=en)
* [EL](/?lang=el)

* [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/button-gmaps.png)
  Πανεπιστημίου 39, Αθήνα](http://goo.gl/maps/cnVA)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/phone_icon.png)
  210 7234567](tel:2107234567)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/email_icon_transparent.png)
  info@ticketservices.gr](mailto:info@ticketservices.gr)

* [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/search-white.png) Αναζήτηση](javascript:;)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/customeraccount.png) Σύνδεση/Εγγραφή](./el/customeraccount/)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/basket.png) Παραγγελία](./el/cart/)
* [Αναζήτηση παραγγελίας](./el/receipt/)
* [Προσωπικά Δεδομένα](./el/personal-data/)
* [Πληροφορίες](./el/information/)

* [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/button-gmaps.png)
  Πανεπιστημίου 39, Αθήνα](http://goo.gl/maps/cnVA)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/phone_icon.png)
  210 7234567](tel:2107234567)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/email_icon_transparent.png)
  info@ticketservices.gr](mailto:info@ticketservices.gr)

* [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/search-white.png) Αναζήτηση](javascript:;)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/customeraccount.png) Σύνδεση/Εγγραφή](./el/customeraccount/)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/basket.png) Παραγγελία](./el/cart/)
* [Αναζήτηση παραγγελίας](./el/receipt/)
* [Προσωπικά Δεδομένα](./el/personal-data/)
* [Πληροφορίες](./el/information/)

.banners\_outer\_wrap {
max-width: 1024px;
width: 99%;
margin-inline: auto;
margin-top: 52px;
max-height: 408px;
border-radius: 10px;
overflow: hidden;
}
.bannerswrap { position: relative; background-color: #fff; overflow: hidden; max-width: 1024px; margin-inline: auto; width: 100%; height: 0; padding-bottom: 40%; }
.bannerswrap > .glide {
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 100%;
}
.hasbanners div#header { margin-top: 1rem; }
.bannerblock { display: block; width: 100%; color: #000; font-size: 1.5rem; margin: 0 auto; padding: 0; max-width: 1020px; max-height: 408px; position: relative; overflow: hidden}
.bannerblock.for\_el { display: none; }
.bannerblock.for\_en { display: none; }
.el .bannerblock.for\_el { display: block; }
.en .bannerblock.for\_en { display: block; }
.bannerblock img { width: 100%; }
.bannerblock a { text-decoration: none; }
.bannerblock img {
display: block; /\* remove any default spacing \*/
margin: 0 auto; /\* center the image horizontally \*/
position: relative; /\* make the image position relative \*/
left: 50%; /\* move the image 50% to the right \*/
transform: translateX(-50%); /\* move the image back 50% to the left \*/
/\*min-width: 500px;\*/
}
.bannerblock .bannertext { position: absolute; position: absolute; bottom: 5px; left: 5px; right: 5px; padding: 1rem; }
.bannerblock .bannertext { background: rgba(0,0,0,0.2) }
.bannerblock h2 { color: #fff; font-size: 2.5rem; text-shadow: 0 0 10px #000; text-align: center; margin: 0 auto; padding: 0;}
.bannerblock h3 { color: #fff; font-size: 1.5rem; text-shadow: 0 0 10px #000; text-align: center; margin: 0 auto; padding: 0;}
@media (max-width: 700px) {
.bannerblock h2 { font-size: 1.8rem;}
.bannerblock h3 { font-size: 1.2rem; }
}
@media (max-width: 600px) {
.bannerblock h2 { font-size: 1.8rem;}
.bannerblock h3 { display: none; }
}
@media (max-width: 350px) {
.bannerblock .bannertext { display: none; }
}
.bannerblock a { position: absolute; top: 0; left: 0; bottom: 0; right: 0; }
.glide\_\_arrow {
color: #fff;
text-shadow: 0 0 10px #000;
box-shadow: 0 0 0px #000;
font-size: 3rem;
font-weight: bold;
border: 0px solid #fff;
}
.glide\_\_arrows img { width: 50px; }
.glide\_\_arrow--left { left: 10px; }
.glide\_\_arrow--right { right: 10px; }
.glide\_\_arrows { display: none; }
.glide:hover .glide\_\_arrows { display: block; }
.glide\_\_bullets {
bottom: 3px;
}

* ![](https://stream.ticketservices.gr/www.ticketservices.gr/banners/images/vaginahood-vol-2_20260919195202.jpg)
* ![](https://stream.ticketservices.gr/www.ticketservices.gr/banners/images/theatro-mets_20260924102925.jpg)
* ![](https://stream.ticketservices.gr/www.ticketservices.gr/banners/images/titanic_20260824153104.jpg)
* ![](https://stream.ticketservices.gr/www.ticketservices.gr/banners/images/van-gogh-the-immersive-experience-thessaloniki_20260926100656.jpg)
* ![](https://stream.ticketservices.gr/www.ticketservices.gr/banners/images/theatro-alkmini-o-megas-ieroexetastis_20260928145530.jpg)
* ![](https://stream.ticketservices.gr/www.ticketservices.gr/banners/images/theatro-alkmini-kitrini-tapetsaria_20260928145628.jpg)
* ![](https://stream.ticketservices.gr/www.ticketservices.gr/banners/images/alkmini-john-gabriel-borkman-2os-xronos_20260929155333.jpg)

![](https://stream.ticketservices.gr/www.ticketservices.gr/images/small_arrow_left_white.png)
![](https://stream.ticketservices.gr/www.ticketservices.gr/images/small_arrow_right_white.png)

var glide; // https://glidejs.com/docs/
$(function() {
glide = new Glide(".glide", {
type: 'carousel',
startAt: 0,
perView: 1,
autoplay: 6000,
hoverpause: true,
animationDuration: 800
});
glide.mount();
$('.glide .bannerblock a').on('click', function(e) {
var a = $(this);
var href = a.attr('href');
var bannerid = a.closest('.glide\_\_slide').attr('data-bannerid');
if(!href) return;
e.preventDefault();
jajax('bannerclicked', { page: href, bannerid: bannerid, '\_noajaxwait': 1 }, function(result) {
window.location = href;
});
});
});
// $(document).on('click', '.bannerblock a', function(e) {
// e.preventDefault();
// var a = $(this);
// var href = a.attr('href');
// jajax('bannerclicked', { page: href }, function(result) {
// window.location = href;
// });
// });

[ΥΠΗΡΕΣΙΑ ΕΙΣΙΤΗΡΙΩΝ - TICKET SERVICES](./el)

|  |
| --- |
| * [Αρχική σελίδα](./el/home/) * [Online παραστάσεις](./el/online-events/) * [Συναυλίες](./el/LiveConcerts/) * [Θέατρο](./el/theatre/) * [Χορός/Χοροθέατρο](./el/DanceTheater/) * [Παιδικά](./el/kids/) * [Εθνικό Θέατρο](./el/NationalTheatre/) * [Εθνική Λυρική Σκηνή](./el/greek-national-opera/) * [Φιλολογικός Σύλλογος Παρνασσός](./el/ParnassosEvents/) * [Μουσική Βιβλιοθήκη](./el/mmb/) * [Θέατρο Απόλλων - Σύρος](./el/apollo-theater-syros/) * [Κέντρο Πολιτισμού Ίδρυμα Σταύρος Νιάρχος (ΚΠΙΣΝ)](./el/snfcc/) * [Λυκόφως](./el/lykofos-productions/) * [Μικρός Κεραμεικός](./el/mikros-kerameikos/) * [Εκθέσεις](./el/exhibitions/) * [Προσφορές](./el/events_with_offers/) * [Νέες εκδηλώσεις](./el/added_recently/) |

[![](/images/x-button-30x30.png)](javascript:clearSearchInputAndResults();)

Συμπληρώστε στο πεδίο τα στοιχεία αναζήτησης

# Αρχική σελίδα

* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66105_front.jpg)
  Κυριακή 22 Νοεμβρίου 2026

  ##### JIM CURTIS Μια ξεχωριστή εμπειρία προσωπικής μεταμόρφωσης στο Μέγαρο Μουσικής Αθηνών*ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ ΑΘΗΝΩΝ*](/event/jim-curtis/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63061_th8m.jpg)
  29 & 30 Σεπτεμβρίου 2026

  ##### ΓΙΑΝΝΗΣ ΚΟΤΣΙΡΑΣ «30 Χρόνια»*ΒΕΑΚΕΙΟ ΘΕΑΤΡΟ ΠΕΙΡΑΙΑ*](/event/veakeio-2026-giannis-kotsiras/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65056_thum.jpg)
  Καλοκαίρι 2026

  ##### Ευριπίδη, ΜΗΔΕΙΑ*ΠΟΛΛΑΠΛΟΙ ΧΩΡΟΙ*](/event/medea-tour-summer-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65525_thumbnail.jpg)
  Από 13 Νοεμβρίου 2026

  ##### ΜΑΚΜΠΕΘ*ΘΕΑΤΡΟ ΚΑΤΕΡΙΝΑ ΒΑΣΙΛΑΚΟΥ*](/event/theatro-vassilakou-macbeth/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65597_thym.jpg)
  Από 30 Νοεμβρίου 2026  
  Δευτέρα & Τρίτη: 21:00

  ##### ΣΑΠΦΩ*ΘΕΑΤΡΟ ΚΑΤΕΡΙΝΑ ΒΑΣΙΛΑΚΟΥ*](/event/theatro-vassilakou-sappho/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66488_thumb.jpg)
  Κυριακή 01 Νοεμβρίου 2026   
  -Κυριακή 03 Ιανουαρίου 2027

  ##### ΤΟΥΣ ΕΙΔΑ*ΘΕΑΤΡΟ ΤΖΕΝΗ ΚΑΡΕΖΗ*](/event/tous-eida/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66140_front-02-09-2026.jpg)
  Από 1 Οκτωβρίου 2026

  ##### Η ΦΟΝΙΣΣΑ του Αλέξανδρου Παπαδιαμάντη*ΘΕΑΤΡΟ ΕΡΓΟΝ*](/event/theatro-ergon-i-fonissa/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_64737_front.jpg)
  Από 11 Οκτωβρίου 2026

  ##### ΜΙΑ ΚΑΝΟΝΙΚΗ ΜΕΡΑ της Κατερίνας Γιαννάκου*ΘΕΑΤΡΟ ΕΡΓΟΝ*](/event/mia-kanoniki-mera/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_64784_thum.jpg)
  Από 26 Σεπτεμβρίου 2026

  ##### VAN GOGH - The Immersive Experience ΘΕΣΣΑΛΟΝΙΚΗ*ΔΕΘ HELEXPO - Κτίριο 5 ΘΕΣΣΑΛΟΝΙΚΗ*](/event/van-gogh-the-immersive-experience-thessaloniki/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_64761_th8m.jpg)
  Από 12 Οκτωβρίου 2026

  ##### TITANIC, AN IMMERSIVE VOYAGE*Digital Theater, Γουδί*](/event/titanic/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65846_thum.jpg)
  Πέμπτη 01 Οκτωβρίου 2026   
  -Δευτέρα 05 Οκτωβρίου 2026

  ##### Το Φονικό της Ιζαμπέλας Μόλναρ*Πειραιώς 260 - Αίθουσα Η*](/event/to-foniko-tis-isabella-molnar/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66041_THUMB.jpg)
  Από 16 Οκτωβρίου 2026

  ##### VAGINAHOOD Vol.2*SHAMONE CLUB*](/event/vaginahood-vol-2/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65586_thumb.jpg)
  Από Πέμπτη 29 Οκτωβρίου 2026

  ##### ΓΙΓΑΝΤΑΣ*ΘΕΑΤΡΟ ΟΔΟΥ ΚΥΚΛΑΔΩΝ ΛΕΥΤΕΡΗΣ ΒΟΓΙΑΤΖΗΣ*](/event/theatro-odou-kykladon-gigantas/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66454_228X222-LARISA.jpg)
  Τετάρτη 30 Σεπτεμβρίου 2026

  ##### «30 χρόνια ΜΙΚΡΗ ΠΑΤΡΙΔΑ»*ΔΗΜΟΤΙΚΟ ΩΔΕΙΟ ΛΑΡΙΣΑΣ*](/event/larisa-30-xronia-mikri-patrida/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66397_thum.jpg)
  Δευτέρα 05 Οκτωβρίου 2026

  ##### «30 χρόνια ΜΙΚΡΗ ΠΑΤΡΙΔΑ»*ΔΗΜΟΤΙΚΟ ΘΕΑΤΡΟ ΑΣΤΕΡΙΑ - ΣΕΡΡΕΣ*](/event/serres-30-xronia-mikri-patrida/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65658__PAROYSIASTHS_AFISA_THU.jpg)
  Πέμπτη 15 Οκτωβρίου 2026   
  -Παρασκευή 01 Ιανουαρίου 2027

  ##### Ο Παρουσιαστής*ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΠΟΛΥΧΩΡΟΣ ΤΕΧΝΩΝ ΠΕΙΡΑΙΑΣ*](/event/avlaia-peiraias-o-parousiastis/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65481_ticket_mets_228x222.jpg)
  2026 - 2027

  ##### ΘΕΑΤΡΟ ΜΕΤΣ](/event/theatro-mets/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63578_morfes-front.jpg)
  Φθινόπωρο 2026

  ##### Μορφές Έκφρασης - Παραμύθια στο Δάσος*Στον Βοτανικό Κήπο Διομήδους*](/event/morfes-ekfrasis-paramythia-sto-dasos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66154_b_65108_or_thum2_1_.jpg)
  18.09.2026 - 28.09.2026

  ##### Circo National De Cuba - ΗΡΑΚΛΕΙΟ*Γήπεδο Αμμουδάρας όπισθεν Σκλαβενίτη επί της οδού Κώστα Μητσοτάκη*](/event/circo-national-de-cuba-hrakleio/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65886_b_37328_or_front.jpg)
  Τρίτη 29 Σεπτεμβρίου 2026   
  -Τετάρτη 30 Σεπτεμβρίου 2026

  ##### ΣΕΜΠΑΣΤΙΑΝ*ΠΛΥΦΑ*](/event/plyfa-sebastian/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65448_b_58901_or_thum.jpg)
  Από 28 Σεπτεμβρίου 2026

  ##### Ο ΑΡΧΙΤΕΚΤΩΝ της Φώφης Τρέζου 2ος χρόνος*ΘΕΑΤΡΟ 104 - BLACK BOX*](/event/theatro-104-o-arxitekton-2os-xronos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_54369_b_27987_or_images_1_.jpg)
  2026

  ##### Ξεναγήσεις στο Κέντρο Πολιτισμού Ίδρυμα Σταύρος Νιάρχος (ΚΠΙΣΝ)*ΚΕΝΤΡΟ ΠΟΛΙΤΙΣΜΟΥ ΙΔΡΥΜΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ - ΞΕΝΑΓΗΣΕΙΣ*](/event/snfcc-guided-tours/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66046_thumbnail.jpg)
  Από 30 Σεπτεμβρίου 2026

  ##### ΛΟΥΠΑ της Εύης Κολιαδήμα (2ος χρόνος)*ΘΕΑΤΡΟ ΚΑΛΛΙΡΡΟΗΣ*](/event/loupa-theatro-kallirrois/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66870_65plus-front.jpg)
  Πέμπτη 1 Οκτωβρίου 2026

  ##### 65+ Μια ολοήμερη γιορτή από το Εθνικό Θέατρο με αφορμή την παγκόσμια ημέρα τρίτης ηλικίας*Σχολείον της Αθήνας - Ειρήνη Παπά*](/event/n-t-65-plus/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_62197_front.jpg)
  Πέμπτη 01 Οκτωβρίου 2026   
  -Σάββατο 03 Οκτωβρίου 2026

  ##### SUPER STORY MARKET*Ταράτσα Πολιτιστικού Πολυχώρου itravelpoetry*](/event/super-story-market/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67053_thum11.jpg)
  Πέμπτη 01 Οκτωβρίου 2026   
  -Τετάρτη 07 Οκτωβρίου 2026

  ##### Ακόμα κι αν φύγεις...: Αφιέρωμα στη Μαριανίνα Κριεζή*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ*](/event/gno-2627-akoma-ki-an-fygeis/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65868_1.jpg)
  Από 01 Οκτωβρίου 2026

  ##### ΙΕΡΟΤΕΛΕΣΤΙΑ*ΕΘΝΙΚΟ ΘΕΑΤΡΟ - ΣΚΗΝΗ «ΝΙΚΟΣ ΚΟΥΡΚΟΥΛΟΣ»*](/event/n-t-ierotelestia-2/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65873_th8m.jpg)
  Πέμπτη 01 Οκτωβρίου 2026

  ##### Η Προίκα μου Κωνσταντίνα Πάλλα*Μικρός Κεραμεικός*](/event/mikros-kerameikos-i-proika-mou-konstantina-palla/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66512_th8mm.jpg)
  ΚΑΛΟΚΑΙΡΙ 2026

  ##### Η Παρέα του ΜΙΚΥ και το Τραγούδι της Χαράς - ΠΕΡΙΟΔΕΙΑ*ΠΟΛΛΑΠΛΟΙ ΧΩΡΟΙ*](/event/i-parea-tou-mickey-kai-to-tragoudi-tis-xaras-periodeia-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66502_b_66121_or_thum_1_.jpg)
  02.10.2026 - 01.11.2026

  ##### CIRCO MUNDIAL - ΘΕΣΣΑΛΟΝΙΚΗ*Εμπορικό Κέντρο Μακεδονία (Parking P3) Πυλαία Θεσσαλονίκης*](/event/circo-mundial-thessaloniki/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65976_Gioi_kai_Kores_th8mt.jpg)
  Παρασκευή 02 Οκτωβρίου 2026   
  -Κυριακή 04 Οκτωβρίου 2026

  ##### ΓΙΟΙ & ΚΟΡΕΣ*ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ ΚΟΜΟΤΗΝΗΣ*](/event/dipethe-komotinis-gioi-kai-kores/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65282_ecdb2f7ed517d0217b68b0046481158a_M_1_.jpg)
  Παρασκευή 02 Οκτωβρίου 2026   
  -Κυριακή 18 Οκτωβρίου 2026

  ##### Τόσαις φοραίς τόσο κοντά να είμαι*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-to-have-been-so-close-so-many-times/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66681_thum.jpg)
  Παρασκευή 02 Οκτωβρίου 2026

  ##### KωΓιαΜαν with special guest Hussain Badran *BAUMSTRASSE*](/event/baumstrasse-kogiaman/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67123_Monologues 228x222 (1).jpg)
  Παρασκευή 02 Οκτωβρίου 2026   
  -Σάββατο 03 Οκτωβρίου 2026

  ##### ΠΡΩΤΟΤΥΠΟΙ ΜΟΝΟΛΟΓΟΙ ΕΠΙ ΣΚΗΝΗΣ *41 Street Cafe*](/event/prwtotypoi-monologoi-epi-skhnhs-41-street-cafe/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65380_thum.jpg)
  Παρασκευή 02 Οκτωβρίου 2026   
  -Παρασκευή 23 Οκτωβρίου 2026

  ##### «Το ΜΕΙΔΙΑΜΑ»*Μικρός Κεραμεικός*](/event/mikros-kerameikos-to-meidiama/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66645_th8m.jpg)
  Παρασκευή 02 Οκτωβρίου 2026   
  -Κυριακή 04 Οκτωβρίου 2026

  ##### Ο ΜΠΟΓΙΑΤΖΗΣ του Donald Churchill*ΕΠΙΚΕΝΤΡΟ+ / ΠΑΤΡΑ*](/event/patra-epikentro-o-bogiatzis/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67105_thum.jpg)
  Παρασκευή 02 Οκτωβρίου 2026

  ##### ΣΟΦΙΑ ΑΝΔΡΙΑΝΟΥ ΕΦ'ΟΛΗΣ ΤΗΣ ΥΛΗΣ*ΧΩΡΟΣ ΤΕΧΝΗΣ ΑΣΩΜΑΤΩΝ*](/event/art-space-asomaton-sofia-andrianou/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66141_b_56599_or_thum.jpg)
  Aπό 12 Σεπτεμβρίου 2026

  ##### Hello Kids Δημιουργικά εργαστήρια*Πολυχώρος hello kids*](/event/hello-kids-dimiourgika-ergastiria/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66258_baby ) (228 x 222 px).jpg)
  Σάββατο 03 Οκτωβρίου 2026   
  -Σάββατο 02 Ιανουαρίου 2027

  ##### 'Ατα 'Ατα χρώματα *ΘΕΑΤΡΟ ΕΛΕΡ - ΕΛΕΝΗ ΕΡΗΜΟΥ*](/event/ata-ata-xrwmata-theatro-eler/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65733_thumbnail.jpg)
  Από 19 Σεπτεμβρίου 2026

  ##### Η ΠΕΝΤΑΜΟΡΦΗ & ΤΟ ΤΕΡΑΣ 4ος χρόνος*ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΠΟΛΥΧΩΡΟΣ ΤΕΧΝΩΝ ΠΕΙΡΑΙΑΣ*](/event/avlaia-i-pentamorfi-kai-to-teras/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_62419_psarotromaras-front.jpg)
  ΠΕΡΙΟΔΕΙΑ 2026

  ##### Ο ΨΑΡΟΤΡΟΜΑΡΑΣ*ΠΟΛΛΑΠΛΟΙ ΧΩΡΟΙ*

  *Το λυθρίνι, το μπαρμπούνι και η γόπα μαθαίνουν τα σχέδια του Ψαροτρομάρα. Μόνα τους ψάχνουν να βρουν μία λύση αλλά ο φόβος ότι θα τους κάνει μια χαψιά τα απογοητεύει ακόμα περισσότερο. Ώσπου στο δρόμο τους θα βρεθεί η γοργόνα...*](/event/o-psarotromaras/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65952_thum drakos.jpg)
  Από 5 Σεπτεμβρίου 2026

  ##### Ο Δράκος των Χρωμάτων*Βοτανικός Κήπος Διομήδους*](/event/morfes-ekfrasis-o-drakos-ton-xromaton/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65857_Thumb 228x222.jpg)
  Σάββατο 03 Οκτωβρίου 2026   
  -Κυριακή 01 Νοεμβρίου 2026

  ##### ΔΕΚΑΞΙ (2ος χρόνος)*ΘΕΑΤΡΟ 104 - BLACK BOX*](/event/theatro-104-dekaxi-2os-xronos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67054_thum.jpg)
  Σάββατο 03 Οκτωβρίου 2026

  ##### ΜΕΛΙΣΜΑ ΙΙΙ 'Υδατα: Μελωδίες από τις πηγές των ατμών*Το Κύμα, Λουτρά Αιδηψού*](/event/gno-melisma-III-ydata/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_64748_12.jpg)
  Σάββατο 03 Οκτωβρίου 2026   
  -Κυριακή 08 Νοεμβρίου 2026

  ##### «Η Ανάστασις» του Λέοντος Τολστόι - 2ος χρόνος*ΘΕΑΤΡΟ NOŪS*](/event/theatro-nous-i-anastasi-2os-xronos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67114_thumb.jpg)
  Σάββατο 03 Οκτωβρίου 2026   
  -Κυριακή 04 Οκτωβρίου 2026

  ##### Μια Συλλογική Ανάσα Συμμετοχική παράσταση σύγχρονου χορού*3ερκαλο -  Sonart Space*](/event/mia-syllogiki-anasa/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65974_th8m.jpg)
  Σάββατο 03 Οκτωβρίου 2026

  ##### Με της οθόνης τραγούδια ταξίδι στο χρόνο Ειρήνη Τουμπάκη - Μάριος Στρόφαλης*Μικρός Κεραμεικός*](/event/mikros-kerameikos-me-tis-othonis-tragoudia-taksidi-sto-xrono/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66753_228x222.jpg)
  Σάββατο 03 Οκτωβρίου 2026   
  -Κυριακή 17 Ιανουαρίου 2027

  ##### ΙΩΑΝΝΗΣ ΓΑΒΡΙΗΛ ΜΠΟΡΚΜΑΝ*ΘΕΑΤΡΟ ΑΛΚΜΗΝΗ - ΣΚΗΝΗ INTERMEDIA*](/event/alkmini-john-gabriel-borkman-2os-xronos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66739_b_60115_or_ntosto.jpg)
  Σάββατο 03 Οκτωβρίου 2026

  ##### Ο φίλος μου ο Ντοστογιέφσκι*ΠΟΛΛΑΠΛΟΙ ΧΩΡΟΙ*](/event/periodeia-2026-27-o-filos-mou-o-dostoyevsky/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65699_b_45228_or_ticketservice_a_nato_228X220.jpg)
  Aπό 4 Οκτωβρίου 2026

  ##### «α ΝαΤο» (3ος Χρόνος)*ΘΕΑΤΡΟ ΑΛΚΜΗΝΗ - ΣΚΗΝΗ INTERMEDIA*](/event/theatro-alkmini-a-nato/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63607_thum koukou.jpg)
  Από 6 Σεπτεμβρίου 2026

  ##### Κούκου!...μια βόλτα στο δάσος*ΒΟΤΑΝΙΚΟΣ ΚΗΠΟΣ ΔΙΟΜΗΔΟΥΣ - ΘΕΑΤΡΟ ΜΟΡΦΕΣ ΕΚΦΡΑΣΗΣ*](/event/morfes-ekfrasis-koukou-mia-volta-sto-dasos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65979_thumbnail.jpg)
  Από 4 Οκτωβρίου 2026, κάθε Κυριακή στις 11:30 το πρωί

  ##### Κόκκινο Κίτρινο Μπλε Ιστορίες με τα χρώματα*ΘΕΑΤΡΟ ΤΗΣ ΗΜΕΡΑΣ - ΠΑΙΔΙΚΗ ΣΚΗΝΗ*](/event/kokkino-kitrino-mple-theatro-tis-hmeras/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65725_thumbnail.jpg)
  Από 20 Σεπτεμβρίου 2026

  ##### Η Χιονάτη και οι 7 Νάνοι 2ος χρόνος*ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΠΟΛΥΧΩΡΟΣ ΤΕΧΝΩΝ ΠΕΙΡΑΙΑΣ*](/event/i-xionati-kai-oi-epta-nanoi-theatro-avlaia-peiraias/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65649_th8m.jpg)
  Από 4 Οκτωβρίου 2026

  ##### Ο ΑΝΘΡΩΠΟΣ ΤΩΝ ΘΑΥΜΑΤΩΝ*ΘΕΑΤΡΟ ΑΛΚΜΗΝΗ - ΚΕΝΤΡΙΚΗ ΣΚΗΝΗ*](/event/alkmini-o-anthropos-ton-thavmaton/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66024_FRONT.jpg)
  Από 4 Οκτωβρίου, κάθε Κυριακή στις 15:00

  ##### Ο Σκεπαστής του Φεγγαριού*ΘΕΑΤΡΟ ΤΗΣ ΗΜΕΡΑΣ - ΠΑΙΔΙΚΗ ΣΚΗΝΗ*](/event/o-skepastis-tou-feggariou-theatro-tis-imeras/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65953_thum xeip.jpg)
  Από 13 Σεπτεμβρίου 2026

  ##### Χέη Χοπ! Παιχνίδια στη φάρμα*Βοτανικός Κήπος Διομήδους*](/event/morfes-ekfrasis-hey-hop-paixnidia-sti-farma/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66491_FRONT.jpg)
  Από 4 Οκτωβρίου 2026

  ##### Πίτσα ΜERCEDES*ΘΕΑΤΡΟ ΑΒΑΤΟΝ*](/event/pizza-mercedes/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66007_th8m.jpg)
  Από 4 Οκτωβρίου 2026

  ##### ΟΙ ΕΥΘΥΜΕΣ ΚΥΡΑΔΕΣ*ΔΙΑΧΡΟΝΟ ΘΕΑΤΡΟ*](/event/diaxrono-theatro-euthimes-kirades/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66152_thumb.jpg)
  Κυριακή 04 Οκτωβρίου 2026

  ##### Brillante!*ΜΟΥΣΙΚΗ ΒΙΒΛΙΟΘΗΚΗ ΣΤΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ - ΑΙΘΟΥΣΑ ΔΙΔΑΣΚΑΛΙΑΣ*](/event/brillante/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66605_b_54577_or_rockthumb.jpg)
  Κυριακή 04 Οκτωβρίου 2026

  ##### Tavern Music / De Profundis Ensemble*Architecture Rock Cafe - Live Stage*](/event/tavern-music-de-profundis-ensemble/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_64679_2.jpg)
  Κυριακή 04 Οκτωβρίου 2026

  ##### (Α)γνώστου Πατρός Η ΚΡΥΦΗ ΚΑΣΕΤΑ*Κέντρο Πολιτισμού & Τέχνων «Θεατρίνη» ΒΟΛΟΣ*](/event/agnostou-patros-volos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66757_thum.jpg)
  Από 5 Οκτωβρίου 2026

  ##### «'Oνειρο Καλοκαιρινής Νύχτας» Ουίλλιαμ Σαίξπηρ*ΣΚΗΝΗ BRECHT 2510*](/event/brecht-2510-oneiro-kalokairinis-nyxtas/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66092_thumbnail.jpg)
  Aπό 6 Οκτωβρίου 2026

  ##### ΑΛΗΘΕΙΑ ΣΟΥ ΛΕΩ ΨΕΜΑΤΑ*ΘΕΑΤΡΟ ΑΛΦΑ - ΛΗΝΑΙΟΣ-ΦΩΤΙΟΥ*](/event/alpha-theater-alitheia-sou-leo-psemata/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66562_center.jpg)
  Πρεμιέρα 6 Οκτωβρίου 2026

  ##### «Το Υπόγειο» του Φιόντορ Ντοστογιέφσκι 3ος χρόνος*ΘΕΑΤΡΟ ΒΑΦΕΙΟ - ΛΑΚΗΣ ΚΑΡΑΛΗΣ*](/event/theatro-vafeio-to-ypogeio-fyodor-dostoevsky-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63872_megas-front.jpg)
  Από 7 Οκτωβρίου 2026

  ##### «Ο ΜΕΓΑΣ ΙΕΡΟΕΞΕΤΑΣΤΗΣ» του Φιόντορ Ντοστογιέφσκι 14ος χρόνος*ΘΕΑΤΡΟ ΑΛΚΜΗΝΗ - ΚΕΝΤΡΙΚΗ ΣΚΗΝΗ*](/event/theatro-alkmini-o-megas-ieroexetastis/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_62170_th8m.jpg)
  Τετάρτη 07 Οκτωβρίου 2026   
  -Τετάρτη 16 Δεκεμβρίου 2026

  ##### Ιστορίες για την τέχνη*ΔΗΠΕΘΕ ΚΟΜΟΤΗΝΗΣ*](/event/dipethe-komotinis-istories-gia-tin-texni-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65550_front.jpg)
  Τετάρτη 07 Οκτωβρίου 2026

  ##### Death Over Europe Part II MAYHEM (Norway) + UNLEASHED (Sweden)*Gagarin 205 Live Music Space*](/event/gagarin-death-over-europe-part-ii-mayhem-unleashed/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65277_228x222.jpg)
  Τετάρτη 07 Οκτωβρίου 2026

  ##### BILLY COBHAM QUINTET*Συνεδριακό Κέντρο «ΙΩΑΝΝΗΣ ΒΕΛΛΙΔΗΣ» Θεσσαλονίκη*](/event/vellidio-billy-cobham-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66069_thumbnail.jpg)
  Από 7 Οκτωβρίου 2026

  ##### «Η ΚΙΤΡΙΝΗ ΤΑΠΕΤΣΑΡΙΑ» της Σάρλοτ Πέρκινς Γκίλμαν*ΘΕΑΤΡΟ ΑΛΚΜΗΝΗ - SECRET ROOM*](/event/theatro-alkmini-kitrini-tapetsaria/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_64267_2_year_228x222 ticketservices_2year.jpg)
  Πέμπτη 08 Οκτωβρίου 2026   
  -Σάββατο 17 Οκτωβρίου 2026

  ##### «ΜΕΝΓΚΕΛΕ» του Θανάση Τριαρίδη 2ος Χρόνος*ΠΛΥΦΑ - ΚΤΗΡΙΟ 7Α*](/event/plyfa-mengkele-2os-xronos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65957_thumb.jpg)
  Πέμπτη 08 Οκτωβρίου 2026   
  -Πέμπτη 29 Οκτωβρίου 2026

  ##### El Che Teatro*ΘΕΑΤΡΟ NOŪS*](/event/el-che-theatro-nous-oktovrios-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66203_noha-228-x-222-px.jpg)
  Πέμπτη 08 Οκτωβρίου 2026   
  -Παρασκευή 18 Δεκεμβρίου 2026

  ##### Νοχαβελάνδη - ένα western δωματίου του Γιάννη Αποσκίτη*ΘΕΑΤΡΟ 104*](/event/theatro-104-noxavelandi/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65869_2.jpg)
  Από 09 Οκτωβρίου 2026

  ##### KONTAKTΗOF της Pina Bausch*ΕΘΝΙΚΟ ΘΕΑΤΡΟ - ΚΕΝΤΡΙΚΗ ΣΚΗΝΗ*](/event/n-t-kontakthof-2/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66701_front.jpg)
  Παρασκευή 09 Οκτωβρίου 2026   
  -Σάββατο 10 Οκτωβρίου 2026

  ##### «Τα κορίτσια δεν πρέπει να παίζουν ποδόσφαιρο» της βραβευμένης Μάρτα Μπουτσάκα Σκηνοθεσία Αποστόλης Ψαρρός*ΕΠΙΚΕΝΤΡΟ+ / ΠΑΤΡΑ*](/event/ta-koritsia-den-prepei-na-paizoyn-podosfairo-epikentro-patra/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67101_thumb.jpg)
  Παρασκευή 09 Οκτωβρίου 2026

  ##### Γιάννης Σφακιανός "Φεγγαρόστρατα"*BAUMSTRASSE*](/event/baumstrasse-feggarostrata/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66525_press_4_2.jpg)
  Παρασκευή 09 Οκτωβρίου 2026   
  -Σάββατο 28 Νοεμβρίου 2026

  ##### «Τo κομπλεξικό» του Αχιλλέα ΙΙΙ*Θέατρο Αλκμήνη - Σκηνή Intermedia*](/event/theatro-alkmini-to-koblexiko-tou-achillea-iii/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_62690_thum.jpg)
  Aπό 10 Οκτωβρίου 2026

  ##### «Όταν το Βελούδο Πέσει» της Ισμήνης Σκούταρη*Μικρός Κεραμεικός*](/event/mikros-kerameikos-otan-to-veloudo-pesei/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_64317_thumb.jpg)
  Σάββατο 10 Οκτωβρίου 2026   
  -Κυριακή 11 Οκτωβρίου 2026

  ##### (Α)ΓΝΩΣΤΟΥ ΠΑΤΡΟΣ Η ΚΡΥΦΗ ΚΑΣΕΤΑ*ΓΡΑΜΜΕΣ ΤΕΧΝΗΣ - ΠΑΤΡΑ*](/event/agnostou-patros-patra/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66715_thuml.jpg)
  Σάββατο 10 Οκτωβρίου 2026   
  -Πέμπτη 15 Οκτωβρίου 2026

  ##### ΚΑΣΣΥ / CASSIE*ΦΙΑΤ Φαλήρου 97, Κουκάκι*](/event/cassie/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66746_thum.jpg)
  Σάββατο 10 Οκτωβρίου 2026

  ##### VIVALDI 4 Εποχές*ΔΗΜΟΤΙΚΟ ΘΕΑΤΡΟ ΒΟΛΟΥ «ΒΑΓΓΕΛΗΣ ΠΑΠΑΘΑΝΑΣΙΟΥ»*](/event/dimos-volou-vivaldi/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65800_thumbnail.jpg)
  Από 10 Οκτωβρίου 2026

  ##### ΕΔΩ ΔΕΝ ΠΕΝΘΟΥΝ*ΘΕΑΤΡΟ 104*](/event/edo-den-penthoun-theatro-104/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66238_thumb.jpg)
  Σάββατο 10 Οκτωβρίου 2026   
  -Κυριακή 25 Οκτωβρίου 2026

  ##### Νεφέλωμα Ωμέγα*ΘΕΑΤΡΟ ΡΟΕΣ*](/event/theatro-roes-nefeloma-omega/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66910_thumb.jpg)
  Σάββατο 10 Οκτωβρίου 2026   
  -Κυριακή 11 Οκτωβρίου 2026

  ##### "Μαμά;"*ΘΕΑΤΡΟ ARROYO*](/event/mama-arroyo/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_61783_1.jpg)
  Σάββατο 10 Οκτωβρίου 2026   
  -Κυριακή 25 Οκτωβρίου 2026

  ##### ΠΡΙΓΚΙΠΙSSΕS*Μικρός Κεραμεικός*](/event/mikros-kerameikos-prigkipisses/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66479_th8m.jpg)
  Σάββατο 10 Οκτωβρίου 2026

  ##### OMMA & Γιάννης Μήτσης*BAUMSTRASSE*](/event/baumstrasse-omma-kai-giannis-mitsis/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67004_SIGA TO 8EAMA II INSTA.jpg)
  Σάββατο 10 Οκτωβρίου 2026   
  -Σάββατο 31 Οκτωβρίου 2026

  ##### «Σιγά το θέαμα Νο2»*Gustav Athens*](/event/gustav-siga-to-theama-no2/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66437_1.jpg)
  Από 11 Οκτωβρίου 2026

  ##### To μαγικό εισιτήριο*ΜΟΥΣΙΚΗ ΒΙΒΛΙΟΘΗΚΗ ΣΤΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ - ΑΙΘΟΥΣΑ ΓΙΑΝΝΗΣ ΜΑΡΙΝΟΣ*](/event/mmb-to-magiko-eisitirio-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_64579_thumbnail2.jpg)
  Από 11 Οκτωβρίου 2026

  ##### ΟΔΥΣΣΕΙΑ του Ομήρου*ΘΕΑΤΡΟ ΚΑΠΠΑ*](/event/theatro-kappa-odysseia/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65419_228x222.jpg)
  Κυριακή 11 Οκτωβρίου 2026

  ##### «Η Πριγκίπισσα και η Μαγική της Βεντάλια»*ΩΔΕΙΟ ΑΘΗΝΩΝ - ΑΜΦΙΘΕΑΤΡΟ ΙΩΑΝΝΗΣ ΔΕΣΠΟΤΟΠΟΥΛΟΣ*](/event/i-prigkipissa-kai-i-magiki-tis-ventalia/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66400_thumbnail1.jpg)
  Από 11 Οκτωβρίου 2026

  ##### Ο θησαυρός του Μίκη*ΜΟΥΣΙΚΗ ΒΙΒΛΙΟΘΗΚΗ ΣΤΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ - ΑΙΘΟΥΣΑ ΔΙΔΑΣΚΑΛΙΑΣ*](/event/mmb-o-thisavros-tou-miki-2026-27/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66407_thumbnail1.jpg)
  Από 11 Οκτωβρίου 2026

  ##### Ο Καπετάν Σαματάς*ΜΟΥΣΙΚΗ ΒΙΒΛΙΟΘΗΚΗ ΣΤΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ - MusiX LAB*](/event/mmb-o-kapetan-samatas-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66419_b_66418_or_b_54904_or_BASILISSA_20TWN_20PANTWN_1_.jpg)
  Από 11 Οκτωβρίου 2026

  ##### Η ΒΑΣΙΛΙΣΣΑ ΤΩΝ ΠΑΝΤΩΝ *ΜΟΥΣΙΚΗ ΒΙΒΛΙΟΘΗΚΗ ΣΤΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ - ΑΙΘΟΥΣΑ ΓΙΑΝΝΗΣ ΜΑΡΙΝΟΣ*](/event/mmb-i-vasilissa-ton-panton-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66260_thumbnail.jpg)
  Δευτέρα 12 Οκτωβρίου 2026   
  -Δευτέρα 02 Νοεμβρίου 2026

  ##### «Η ΣΟΝΑΤΑ ΤΟΥ ΣΕΛΗΝΟΦΩΤΟΣ» του Γιάννη Ρίτσου*ΘΕΑΤΡΟ ΑΛΚΜΗΝΗ - ΣΚΗΝΗ INTERMEDIA*](/event/theatro-alkmini-i-sonata-tou-selinofwtos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66315_228X222 copy.jpg)
  12.10.2026 - 30.11.2026

  ##### ΝΕΚΥΙΑ*ΜΟΥΣΙΚΗ ΒΙΒΛΙΟΘΗΚΗ ΣΤΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ - ΑΙΘΟΥΣΑ ΓΙΑΝΝΗΣ ΜΑΡΙΝΟΣ*](/event/nekyia/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66391_Voudi Thumbnail Ticket Services.jpg)
  Από 12 Οκτωβρίου 2026

  ##### Ο Γιάννης το Βούδι*NO52 - ΑΘΗΝΑ*](/event/o-giannis-to-voudi-no52/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66925_thum.jpg)
  Δευτέρα 12 Οκτωβρίου 2026   
  -Κυριακή 08 Νοεμβρίου 2026

  ##### Η εγκληματική οργάνωση μιας παράστασης*ΘΕΑΤΡΟ ΧΩΡΟΣ*](/event/theatro-xoros-i-egklimatiki-organosi-mias-parastasis/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66055_PanosNefeli_Ticket_Services_S22.jpg)
   Από 12 Οκτωβρίου 2026

  ##### ΜΙΚΡΕΣ ΤΑΠΕΙΝΩΣΕΙΣ*BAUMSTRASSE*](/event/mikres-tapeinwseis-baumstrasse/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66790_front.jpg)
  από 12 Οκτωβρίου 2026

  ##### «Σχέδιο Προμηθεύς» του Γιώργου Αδαμαντιάδη *ΘΕΑΤΡΟ ΚΑΛΛΙΡΡΟΗΣ*](/event/theatro-kallirrois-sxedio-promithevs/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66830_thum.jpg)
  Δευτέρα 12 Οκτωβρίου 2026   
  -Τρίτη 20 Οκτωβρίου 2026

  ##### Σλάντεκ του Έντεν φον Χόρβατ*Goethe - Institut Thessaloniki - Αίθουσα SAL*](/event/sladek/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66868_loft.jpg)
  Από 12 Οκτωβρίου 2026

  ##### ΤΗΓΑΝΗΤΕΣ ΠΑΤΑΤΕΣ | Ζήσης Ρούμπος Stand Up Comedy show*TGI Fridays™ Loft Kapnikareas*](/event/fridays-tiganites-patates-zisis-roubos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65502_A8ANASIA-1080x1080.jpg)
  από 13 Οκτωβρίου 2026

  ##### ΑΘΑΝΑΣΙΑ*ΣΥΓΧΡΟΝΟ ΘΕΑΤΡΟ*](/event/athanasia-sychrono-theatro/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65139_b_60784_or_tickerserv_1_.jpg)
  Από 14 Οκτωβρίου 2026

  ##### «Η Ανθρώπινη Φωνή» του Jean Cocteau*ΘΕΑΤΡΟ ΑΛΚΜΗΝΗ - SECRET ROOM*](/event/alkmini-i-anthropini-foni-3os-xronos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66058_thumbnail.jpg)
  Από 14 Οκτωβρίου 2026

  ##### ΚΟΙΜΩΜΕΝΟΣ ΧΑΛΕΠΑΣ / ο ΣΑΛόΣ άΓΙΟΣ (5ος Χρόνος) *ΘΕΑΤΡΟ ΚΑΛΛΙΡΡΟΗΣ*](/event/theatro-kallirrois-koimomenos-xalepas-o-salos-agios/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_62679_th8m.jpg)
  Τετάρτη 14 Οκτωβρίου 2026   
  -Τετάρτη 02 Δεκεμβρίου 2026

  ##### Πέρσες του Αισχύλου (2η Χρονιά)*ΘΕΑΤΡΟ ΦΟΥΡΝΟΣ*](/event/theatro-fournos-perses-tou-aisxylou-2h-xronia/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65879_th8m.jpg)
  Από 14 Οκτωβρίου 2026

  ##### Πτήση 717 Αθήνα - Ρώμη*Μικρός Κεραμεικός*](/event/ptisi-717-athina-romi/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66466_1.jpg)
  ΤΟΥΡ - ΦΘΙΝΟΠΩΡΟ 2026

  ##### ΠΟΛΥ ΚΟΥΛ Game Nights OΝ ΤΟΥΡ*ΡΟΔΟΣ - ΘΕΣΣΑΛΟΝΙΚΗ - ΙΩΑΝΝΙΝΑ - ΠΑΤΡΑ*](/event/poli-cool-on-tour/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66222_Thumbnail_228x222.jpg)
  Πέμπτη 15 Οκτωβρίου 2026   
  -Πέμπτη 17 Δεκεμβρίου 2026

  ##### Ο Παρίας του August Strindberg*Μικρός Κεραμεικός*](/event/o-parias/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66078_thumb.jpg)
  Από 15 Οκτωβρίου 2026

  ##### ΓΥΜΝΗ*ΘΕΑΤΡΟ ΚΑΛΛΙΡΡΟΗΣ*](/event/gymni-theatro-kallirrois/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66691_thumb.jpg)
  Παρασκευή 16 Οκτωβρίου 2026

  ##### Bel Canto Classico Μια Ιταλική βραδιά στην Πλάκα*ΙΩΝΙΚΟ ΚΕΝΤΡΟ - Πλάκα*](/event/ioniko-kentro-bel-canto-classico/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66017_thumbnai.jpg)
  Παρασκευή 16 Οκτωβρίου 2026

  ##### Η ΓΕΝΝΗΣΗ ΕΝΟΣ ΦΑΣΙΣΤΑ Η ΑΠΟΛΟΓΙΑ ΤΟΥ ΘΕΟΦΙΛΟΥ ΤΣΑΦΟΥ - ΠΑΤΡΑ*ΓΡΑΜΜΕΣ ΤΕΧΝΗΣ - ΠΑΤΡΑ*](/event/h-gennisi-enos-fasista-grammes-texnis-patra/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66937_b_59997_or_thumbSocial-Media-Post.jpg)
  Παρασκευή 16 Οκτωβρίου 2026   
  -Κυριακή 18 Οκτωβρίου 2026

  ##### «Ζαχαροπλαστείον ο Πελαργός»*ΘΕΑΤΡΟ SUREAL - ΘΕΣΣΑΛΟΝΙΚΗ*](/event/theatro-sureal-zaxaroplasteion-o-pelargos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65655_th8mmm2222222mm.jpg)
  Παρασκευή 16 Οκτωβρίου 2026   
  -Κυριακή 29 Νοεμβρίου 2026

  ##### ΣΥΝΑΙΝΕΣΗ*ΣΥΓΧΡΟΝΟ ΘΕΑΤΡΟ*](/event/synainesi-sychrono-theatro/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66318_1.jpg)
  Από 16 Οκτωβρίου 2026

  ##### Γιοι και κόρες*ΘΕΑΤΡΟ ΕΛΕΡ - ΕΛΕΝΗ ΕΡΗΜΟΥ*](/event/gioi-kai-kores-theatro-eler/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65523_thum.jpg)
  Παρασκευή 16 Οκτωβρίου 2026

  ##### TUBER LIVE RECORDING PROJECT*ΚΥΤΤΑΡΟ LIVE*](/event/kyttaro-tuber/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66377_rhum.jpg)
  Παρασκευή 16 Οκτωβρίου 2026

  ##### ΧΑΡΗΣ ΛΑΜΠΡΑΚΗΣ - TIM KARP ΝΙΚΟΣ ΣΙΔΗΡΟΚΑΣΤΡΙΤΗΣ - DUNJA BOTIC «impromptu»*BAUMSTRASSE*](/event/baumstrasse-impromptu/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66977_chmiths.jpg)
  Παρασκευή 16 Οκτωβρίου 2026

  ##### «ΑΜΑΛΦΙ Live» Νίκος Ψημίτης - Σταύρος Σιόλας*Gustav Athens*](/event/gustav-amalfi-live/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66343_Kokkino Skoyfi .jpg)
  Σάββατο 17 Οκτωβρίου 2026   
  -Σάββατο 19 Δεκεμβρίου 2026

  ##### Μ' ένα κόκκινο σκουφί*ΘΕΑΤΡΟ ΑΛΚΜΗΝΗ - ΚΕΝΤΡΙΚΗ ΣΚΗΝΗ*](/event/theatro-alkmini-me-ena-kokkino-skoufi/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66947_thum.jpg)
  Σάββατο 17 Οκτωβρίου 2026

  ##### Σπύρος και Μάκης Καραβιώτης «Πάμε σαν άλλοτε...»*ΜΟΥΣΙΚΗ ΒΙΒΛΙΟΘΗΚΗ ΣΤΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ - ΑΙΘΟΥΣΑ ΔΙΔΑΣΚΑΛΙΑΣ*](/event/mmb-afoi-karavioti-pame-san-allote/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_64300_1.jpg)
  Σάββατο 17 Οκτωβρίου 2026   
  -Κυριακή 18 Οκτωβρίου 2026

  ##### ΜΙΣΗ ΠΑΤΡΙΔΑ - ΠΑΤΡΑ*ΓΡΑΜΜΕΣ ΤΕΧΝΗΣ - ΠΑΤΡΑ*](/event/misi-patrida-patra/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_62320_AFISA NEA SEZON.jpg)
  Από 17 Οκτωβρίου 2026

  ##### TA ΚΟΚΚΙΝΑ ΦΑΝΑΡΙΑ*ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΠΟΛΥΧΩΡΟΣ ΤΕΧΝΩΝ ΠΕΙΡΑΙΑΣ*](/event/avlaia-peiraias-ta-kokkina-fanaria/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66497_front.jpg)
  Σάββατο 17 Οκτωβρίου 2026

  ##### SINEMA ACOUSTIC LIVE*Αγγλικανική Εκκλησία Αγίου Παύλου Φιλελλήνων 27, Αθήνα*](/event/sinema-acoustic-live/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66684_th8m.jpg)
  Σάββατο 17 Οκτωβρίου 2026

  ##### ΚΡΕΩΝ ΚΑΝΑΚΑΡΗΣ Λίβελοι, Καντάδες,Ζωγραφιές & Συναξάρια Η παρουσίαση*BAUMSTRASSE*](/event/baumstrasse-kreon-kanakaris/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67125_th8m.jpg)
  Σάββατο 17 Οκτωβρίου 2026

  ##### ΚΑΤΕΡΙΝΑ ΛΑΖΑΡΙΔΟΥ Accoustic Live*ΚΑΦΩΔΕΙΟ ΕΛΛΗΝΙΚΟ*](/event/kafodeio-katerina-ladariou-accoustic-live/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67058_1600x1000_masks.jpg)
  Κυριακή 18 Οκτωβρίου 2026

  ##### MASK PLAY | Ανοιχτό Μάθημα Γνωριμίας Ερευνητικό Εργαστήριο Μάσκας με τον Γιώργο Κασαπάκη*ΘΕΑΤΡΟ ΜΕΤΣ*](/event/theatro-mets-mask-play/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65591_th8m.jpg)
  Από 18 Οκτωβρίου 2026

  ##### Η ΜΩΒ ΟΜΠΡΕΛΑ*ΘΕΑΤΡΟ ΠΟΡΕΙΑ*](/event/theatro-poreia-i-mob-omprela/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66327_TICKET SERVICES-MIKROS PRIGIPAS (2026) (228X222).jpg)
  Κυριακή 18 Οκτωβρίου 2026   
  -Κυριακή 20 Δεκεμβρίου 2026

  ##### «Ο ΜΙΚΡΟΣ ΠΡΙΓΚΙΠΑΣ»*ΘΕΑΤΡΟ ΚΙΒΩΤΟΣ*](/event/theatro-kivotos-o-mikros-prigkipas/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67003_thum.jpg)
  Από 18 Οκτωβρίου 2026

  ##### Το μυστικό της χαμένης μελωδίας*Τεχνοχώρος Εργοτάξιον*](/event/ergotaxion-to-mystiko-tis-xamenis-melodias/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66433_thumbnail.jpg)
  Από 18 Οκτωβρίου 2026

  ##### Ο φίλος μου ο Φρανκενστάιν*ΜΟΥΣΙΚΗ ΒΙΒΛΙΟΘΗΚΗ ΣΤΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ - ΑΙΘΟΥΣΑ ΔΙΔΑΣΚΑΛΙΑΣ*](/event/mmb-o-filos-mou-o-frankenstain/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66924_thumb.jpg)
  Κυριακή 18 Οκτωβρίου 2026   
  -Κυριακή 31 Ιανουαρίου 2027

  ##### Τα παιδιά του κόσμου τραγουδούν την Ειρήνη*ΘΕΑΤΡΟ ARROYO*](/event/ta-paidia-tou-kosmou-tragoudoun-tin-eirini/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66785_thumb.jpg)
  Από 18 Οκτωβρίου 2026

  ##### Ποιος είναι ο Μάγος του Οζ;*ΜΟΥΣΙΚΗ ΒΙΒΛΙΟΘΗΚΗ ΣΤΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ - ΑΙΘΟΥΣΑ ΓΙΑΝΝΗΣ ΜΑΡΙΝΟΣ*](/event/mmb-poios-einai-o-magos-tou-oz/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66832_thum.jpg)
  Κυριακή 18 Οκτωβρίου 2026

  ##### Ανάμεσα στις σιωπές*BAUMSTRASSE*](/event/baumstrasse-anamesa-stis-siopes/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63422_1.jpg)
  Δευτέρα 19 Οκτωβρίου 2026   
  -Τρίτη 10 Νοεμβρίου 2026

  ##### ΝΤΑΡFΣΤΕΛΕΡ*ΡΕΚΤΙΦΙΕ - Κέντρο Έρευνας Μεικτών Παραστατικών Τεχνών*](/event/rektifie-ntarfsteler/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66770_thumb.jpg)
  Πρεμιέρα 19 Οκτωβρίου 2026

  ##### ΑΙΑΣ του Γιάννη Ρίτσου ΜΟΝΟΣ*ΘΕΑΤΡΟ ΒΑΦΕΙΟ - ΛΑΚΗΣ ΚΑΡΑΛΗΣ*](/event/theatro-vafeio-aias/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66879_th8m.jpg)
  Δευτέρα 19 Οκτωβρίου 2026   
  -Τρίτη 24 Νοεμβρίου 2026

  ##### ΛΕΥΚΕΣ ΝΥΧΤΕΣ ΕΝΟΣ ΚΛΟΟΥΝ*ΘΕΑΤΡΟ ΜΑΒΙΛΗ*](/event/theatro-mavili-lefkes-nixtes-enos-klooun/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67109_thumb.jpg)
  Δευτέρα 19 Οκτωβρίου 2026   
  -Τρίτη 01 Δεκεμβρίου 2026

  ##### «stΕΛΛΑΣ travel»*ΘΕΑΤΡΟ ΔΡΟΜΟΣ*](/event/theatro-dromos-stellas-travel/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66445_thumb.jpg)
  Από 19 Οκτωβρίου 2026

  ##### Ο Δίδυμος Μπελάς*ΘΕΑΤΡΟ ΑΛΚΜΗΝΗ - ΚΕΝΤΡΙΚΗ ΣΚΗΝΗ*](/event/theatro-alkmini-didymos-mpelas/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67143_thumb.jpg)
  Τρίτη 20 Οκτωβρίου 2026

  ##### ΧΡΙΣΤΙΝΑ ΣΑΜΑΡΑ LIVE*Σταυρός του Νότου Club*](/event/christina-samara-live/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67008_thum1.jpg)
  Τετάρτη 21 Οκτωβρίου 2026

  ##### Ύμνοι Χριστουγέννων Φεστιβάλ: Ημέρες Βυζαντινής Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-ymnoi-xristougennon/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66722_thum.jpg)
  Τετάρτη 21 Οκτωβρίου 2026   
  -Τετάρτη 06 Ιανουαρίου 2027

  ##### «Το Τανγκό των Χαμένων Ονείρων»*ΘΕΑΤΡΟ ΑΛΚΜΗΝΗ - ΚΕΝΤΡΙΚΗ ΣΚΗΝΗ*](/event/theatro-alkmini-to-tango-ton-xamenon-oneiron/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67011_thum2.jpg)
  Πέμπτη 22 Οκτωβρίου 2026

  ##### Ύμνοι της Θείας Λειτουργίας - Ύμνοι από την Παράκληση και τους Χαιρετισμούς στην Υπεραγία Θεοτόκο Φεστιβάλ: Ημέρες Βυζαντινής Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-ymnoi-theias-leitourgias/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66464_General.jpg)
  ΦΘΙΝΟΠΩΡΟ 2026

  ##### ΠΟΛΥ ΚΟΥΛ Game Night*Αρχιτεκτονική Club Live Stage*](/event/poli-cool-game-night/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67012_thum3.jpg)
  Παρασκευή 23 Οκτωβρίου 2026

  ##### Ύμνοι της Μεγάλης Εβδομάδας και της Ανάστασης Φεστιβάλ: Ημέρες Βυζαντινής Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-ymnoi-megalis-evdomadas/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66956_thum.jpg)
  Παρασκευή 23 Οκτωβρίου 2026

  ##### «Ο άνθρωπος για τον άνθρωπο»*Gustav Athens*](/event/gustav-o-anthropos-gia-ton-anthropo/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_22798_cccc_thumbnail.jpg)
  Παρασκευή 23 Οκτωβρίου 2026   
  -Κυριακή 25 Οκτωβρίου 2026

  ##### Σλάβομιρ Μρόζεκ - Μεσοπέλαγα*ΠΟΛΙΤΙΣΤΙΚΟ ΣΥΝΕΔΡΙΑΚΟ ΚΕΝΤΡΟ ΗΡΑΚΛΕΙΟΥ - ΠΕΙΡΑΜΑΤΙΚΟ ΘΕΑΤΡΟ*](/event/cccc-mesopelaga-slavomir-mrozek/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66005_thumb.jpg)
  Παρασκευή 23 Οκτωβρίου 2026

  ##### ΠΑΝΑΓΙΩΤΗΣ ΛΑΜΠΟΥΡΑΣ*ΠΛΥΦΑ*](/event/panagiotis-lambouras-plyfa/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66748_thumb.jpg)
  Παρασκευή 23 Οκτωβρίου 2026   
  -Σάββατο 09 Ιανουαρίου 2027

  ##### Μέχρι Κάθε Αύριο*ΘΕΑΤΡΟ ARROYO*](/event/mexri-kathe-avrio-arroyo/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_64681_2.jpg)
  Σάββατο 24 Οκτωβρίου 2026   
  -Κυριακή 25 Οκτωβρίου 2026

  ##### ΜΙΣΗ ΠΑΤΡΙΔΑ*Κέντρο Πολιτισμού & Τέχνων «Θεατρίνη» ΒΟΛΟΣ*](/event/misi-patrida-volos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67014_thum4.jpg)
  Σάββατο 24 Οκτωβρίου 2026

  ##### Ύμνοι της Αγρυπνίας Φεστιβάλ: Ημέρες Βυζαντινής Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-ymnoi-agrypnias/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66118_thumbnail.jpg)
  Σάββατο 24 Οκτωβρίου 2026

  ##### Γεωργία Νταγάκη «Από την Κρήτη ως το 'Απειρο»*ΑΓΓΛΙΚΑΝΙΚΗ ΕΚΚΛΗΣΙΑ ΑΓΙΟΥ ΠΑΥΛΟΥ*](/event/georgia-dagaki-apo-tin-kriti-os-to-apeiro/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66755_blanche-front.jpg)
  Σάββατο 24 Οκτωβρίου 2026   
  -Κυριακή 10 Ιανουαρίου 2027

  ##### Blanche After*ΘΕΑΤΡΟ ARROYO*](/event/blanche-after-arroyo/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66844_thum.jpg)
  Σάββατο 24 Οκτωβρίου 2026

  ##### Thomas Meleteas Quintet BREATHWORKS παρουσίαση δίσκου*BAUMSTRASSE*](/event/baumstrasse-thomas-meleteas-quintet-breathworks/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_61737_phantom-spell-front.jpg)
  Κυριακή 25 Οκτωβρίου 2026

  ##### PHANTOM SPELL*ΚΥΤΤΑΡΟ LIVE*](/event/phantom-spell-live-in-athens/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65295_msm.jpg)
  Κυριακή 25 Οκτωβρίου 2026

  ##### ΤΕΤΤΤΙΞ: Πέντε μονοπάτια Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-tettix/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66834_th8m.jpg)
  Κυριακή 25 Οκτωβρίου 2026   
  -Κυριακή 29 Νοεμβρίου 2026

  ##### «Ανάμεσα σε Χαλάσματα»*BAUMSTRASSE*](/event/baumstrasse-anamesa-se-xalasmata/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66673_paizontas-front.jpg)
  Οκτώβριος 2026 - Μάρτιος 2027

  ##### Παίζοντας... Μουσική! Εργαστήριο μουσικής εξερεύνησης για παιδιά και εφήβους*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ*](/event/gno-paizontas-mousiki/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66836_th8m.jpg)
  Τετάρτη 28 Οκτωβρίου 2026   
  -Κυριακή 01 Νοεμβρίου 2026

  ##### TRIPTYCH*ΠΛΥΦΑ*](/event/plyfa-triptych/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65296_msm.jpg)
  Πέμπτη 29 Οκτωβρίου 2026

  ##### Ρήσεις και ρωγμές - Αφιέρωμα στον Γκιαιργκ Κούρταγκ Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-sayings-and-cracks/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65484_thumbnail.jpg)
  Από 29 Οκτωβρίου 2026

  ##### Ιουλιέττα (η)*ΘΕΑΤΡΟ ΜΕΤΣ*](/event/ioulietta-h-theatro-mets/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67024_Thumbnail_Psychosomatics__Vicky_Stamou_2026.jpg)
  Πέμπτη 29 Οκτωβρίου 2026   
  -Παρασκευή 15 Ιανουαρίου 2027

  ##### «Τα ψυχοσωματικά μου μέσα» από την ομάδα θεάτρου nunc*ΣΚΗΝΗ ΜΠΕΚΕΤ*](/event/ta-psixosomatika-mou-mesa-skini-mpeket/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_64981_Coroner_Depressive Age_Cryptic Shift-Banner Ticket Services Athens 2026 01.jpg)
  Παρασκευή 30 Οκτωβρίου 2026

  ##### Dissonance Over Europe Part I CORONER (Switzerland) +DEPRESSIVE AGE (Germany) +CRYPTIC SHIFT (U.K)*Gagarin 205 Live Music Space*](/event/gagarin-dissonance-over-europe-part-1/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65943_th8mmmm.jpg)
  Παρασκευή 30 Οκτωβρίου 2026   
  -Σάββατο 14 Νοεμβρίου 2026

  ##### Ορφέας*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ*](/event/gno-2627-orfeas/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65297_msm.jpg)
  Παρασκευή 30 Οκτωβρίου 2026

  ##### Ηχητικές πολυπλοκότητες - Αφιέρωμα στον Γκιαιργκ Λίγκετι Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-sonic-complexities/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65486_thumbnail.jpg)
  Από 30 Οκτωβρίου 2026

  ##### Ο ΚΥΚΛΟΣ ΤΩΝ ΑΝΩΝΥΜΩΝ ΕΞΑΡΤΗΣΕΩΝ*ΘΕΑΤΡΟ ΜΕΤΣ*](/event/o-kyklos-ton-anonimon-eksartiseon-theatro-mets/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67127_30_10 afi__769_sa.jpg)
  Παρασκευή 30 Οκτωβρίου 2026

  ##### VIRONAS NTOLAS QUARTET*BAUMSTRASSE*](/event/baumstrasse-vironas-ntolas-quartet/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65956_thum.jpg)
  Παρασκευή 30 Οκτωβρίου 2026

  ##### Το γιοφύρι που έμοιαζε σαμάρι στη ράχη του θεού*Μικρός Κεραμεικός*](/event/mikros-kerameikos-to-giofiri-pou-emoiaze-samari-sti-raxi-tou-theou/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65298_msm.jpg)
  Σάββατο 31 Οκτωβρίου 2026

  ##### Τάσος Ρωσόπουλος: Τραγούδια για μια επιστροφή Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-tasos-rossopoulos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_61874_FRONT.jpg)
  Διαθέσιμη για on demand μετάδοση από 1 Μαρτίου έως 1 Νοεμβρίου 2026

  ##### Ο ΚΑΡΑΓΚΙΟΖΗΣ ΡΙΓΟΛΕΤΤΟΣ*GNO TV - ON DEMAND*](/event/gno-tv-karagiozis-as-rigoletto/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_61876_FRONT.jpg)
  Διαθέσιμη για on demand μετάδοση από 1 Μαρτίου έως 1 Νοεμβρίου 2026

  ##### ΡΙΓΟΛΕΤΤΟΣ*GNO TV - ON DEMAND*](/event/gno-tv-rigoletto/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67130_thumbnail.jpg)
  Από 1 Νοεμβρίου 2026

  ##### «Ο Μικρός Πρίγκιπας» του Antoine de Saint Exupery - ΘΕΣΣΑΛΟΝΙΚΗ*ΑΡΙΣΤΟΤΕΛΕΙΟΝ ΘΕΑΤΡΟ - ΘΕΣΣΑΛΟΝΙΚΗ*](/event/the-little-prince-thessaloniki/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65299_msm.jpg)
  Κυριακή 01 Νοεμβρίου 2026

  ##### Χορωδία της ΕΡΤ, Ένωση Ελλήνων Μουσουργών: Ποιητικά ηχοτοπία Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-poetic-soundscapes/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65300_msm.jpg)
  Κυριακή 01 Νοεμβρίου 2026

  ##### Re:Trace Kurtág - Διεθνής Διαγωνισμός Σύνθεσης Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-trace-kurtag/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66489_thum.jpg)
  Κυριακή 01 Νοεμβρίου 2026

  ##### Βασίλης Γκόφας Παρουσίαση Δίσκου "Σευγή"*BAUMSTRASSE*](/event/baumstrasse-vassilis-gkofas-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66610_th8m.jpg)
  Από 2 Νοεμβρίου 2026

  ##### «Lacrimosa ή το Απέπρωτο» 2ος χρόνος*ΘΕΑΤΡΟ NOŪS*](/event/nous-kentriki-skini-lacrimosa-apeproto-2os-xronos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66705_Psemata i alitheia- afisa katheti.jpg)
  Δευτέρα 02 Νοεμβρίου 2026   
  -Τρίτη 05 Ιανουαρίου 2027

  ##### Ψέματα ή Αλήθεια*ΘΕΑΤΡΟ NOŪS - BLACK BOX*](/event/nous-black-box-psemata-h-alitheia/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66763_th8m.jpg)
  Δευτέρα 02 Νοεμβρίου 2026   
  -Τρίτη 03 Νοεμβρίου 2026

  ##### «Τα κορίτσια δεν πρέπει να παίζουν ποδόσφαιρο»*ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΘΕΣΣΑΛΟΝΙΚΗ*](/event/theatro-avlaia-ta-koritsia-den-prepei-na-paizoyn-podosfairo/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65301_msm.jpg)
  Τρίτη 03 Νοεμβρίου 2026

  ##### Η εξέγερση του κοντραμπάσου: Από τον μύθο στον λόγο Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-the-revolt-of-the-double-bass/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_50142_FRONT.jpg)
  Διαθέσιμη για on demand μετάδοση από 4 Μαρτίου έως 4 Νοεμβρίου 2026

  ##### ΙΖΑΝΤΟΡΑ ΝΤΑΚ*GNO TV - ON DEMAND*](/event/gno-tv-isadora-duck/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65302_msm.jpg)
  Τετάρτη 04 Νοεμβρίου 2026

  ##### Τόποι, μνήμες, Σειρήνες - Ρεσιτάλ βιολοντσέλου Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-places-memories-sirens/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65488_thumbnail.jpg)
  Τετάρτη 04 Νοεμβρίου 2026   
  -Τετάρτη 25 Νοεμβρίου 2026

  ##### «Τι θα γινόταν αν» με τη Ναταλία Λαμπαδάκη*ΘΕΑΤΡΟ ΜΕΤΣ*](/event/ti-tha-ginotan-an-theatro-mets/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65303_msm.jpg)
  Πέμπτη 05 Νοεμβρίου 2026

  ##### The Cabinet of Dr. Caligari Revisited - Συναυλία / Προβολή ταινίας Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-the-cabinet-of-dr-caligari-revisited/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_61868_front.jpg)
  Διαθέσιμη για on demand μετάδοση από 6 Μαρτίου έως 6 Νοεμβρίου 2026

  ##### FLORA MIRABILIS*GNO TV - ON DEMAND*](/event/gno-tv-flora-mirabilis/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66146_thumbnail.jpg)
  Παρασκευή 06 Νοεμβρίου 2026

  ##### Παρουσίαση δίσκου Κος Κ. «Γραμματόσημα»*ΘΕΑΤΡΟ NOŪS*](/event/parousiasi-diskou-kos-k-grammatoshma-theatro-nous/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65304_msm.jpg)
  Παρασκευή 06 Νοεμβρίου 2026

  ##### Άνθη είμαστε - Αφιέρωμα στον Γκιαιργκ Κούρταγκ Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-flowers-we-are/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_62109_front.jpg)
  Παρασκευή 06 Νοεμβρίου 2026   
  -Κυριακή 20 Δεκεμβρίου 2026

  ##### Ο θάνατος του Ιβάν Ιλίτς*Οικία Ιλίτς - Αθήνα*](/event/o-thanatos-tou-ivan-ilits/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66880_thum.jpg)
  Παρασκευή 06 Νοεμβρίου 2026   
  -Παρασκευή 08 Ιανουαρίου 2027

  ##### The D.O.G. του Γιώργου Τσαγκαράκη*ΘΕΑΤΡΟ ΒΑΦΕΙΟ - ΛΑΚΗΣ ΚΑΡΑΛΗΣ*](/event/the-dog-theatro-vafeio/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67090_front.jpg)
  Παρασκευή 06 Νοεμβρίου 2026

  ##### Μπουζούκια στην Πίστα Μουσική Παράσταση*ΛΑΡΙΣΑ - CIRCUS ENTERTAINMENT HUB*](/event/bouzoukia-stin-pista-larisa-november-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65305_msm.jpg)
  Σάββατο 07 Νοεμβρίου 2026

  ##### Στέφανος Θωμόπουλος - Μεσόγειος έρημος: Διάλογοι με τη φύση Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-stephanos-thomopoulos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65306_msm.jpg)
  Σάββατο 07 Νοεμβρίου 2026

  ##### Σεχραζάντ - Ρεσιτάλ τραγουδιού Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-scheherazade/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66970_DROSIS-CENTER.jpg)
  Σάββατο 07 Νοεμβρίου 2026

  ##### Στάθης Δρογώσης & Οδυσσέας Τσάκαλος*Gustav Athens*](/event/gustav-drogosis-tsakalos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66231_thumbnail.jpg)
  Κυριακή 08 Νοεμβρίου 2026   
  -Κυριακή 31 Ιανουαρίου 2027

  ##### Ο ΜΙΚΥ ΚΑΙ Η ΠΑΡΕΑ ΤΟΥ ΣΤΟ ΧΡΙΣΤΟΥΓΕΝΝΙΑΤΙΚΟ ΤΡΕΝΑΚΙ*ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΠΟΛΥΧΩΡΟΣ ΤΕΧΝΩΝ ΠΕΙΡΑΙΑΣ*](/event/o-miky-kai-i-parea-tou-sto-xristougenniatiko-trenaki/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65307_msm.jpg)
  Κυριακή 08 Νοεμβρίου 2026

  ##### Το Παρίσι του Απέργη Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-aperghis-paris/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_52389_front.jpg)
  Διαθέσιμη για on demand μετάδοση από 09/03/2026 έως 09/11/2026

  ##### ΘΕΛΩ ΝΑ ΔΩ ΤΟΝ ΠΑΠΑ! Θεόφραστος Σακελλαρίδης*GNO TV - ON DEMAND*](/event/gno-tv-thelo-na-do-ton-papa/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65308_msm.jpg)
  Τρίτη 10 Νοεμβρίου 2026

  ##### Νέα γενιά - Νέες διαδρομές: Ρεσιτάλ για τρεις νεαρούς σολίστες Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-new-generation-new-routes/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66000_thum.jpg)
  Τρίτη 10 Νοεμβρίου 2026   
  -Τρίτη 01 Δεκεμβρίου 2026

  ##### Η ΓΕΝΝΗΣΗ ΕΝΟΣ ΦΑΣΙΣΤΑ Η ΑΠΟΛΟΓΙΑ ΤΟΥ ΘΕΟΦΙΛΟΥ ΤΣΑΦΟΥ*Μικρός Κεραμεικός*](/event/mikros-kerameikos-i-gennisi-enos-fasista/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65309_msm.jpg)
  Τετάρτη 11 Νοεμβρίου 2026

  ##### Greek Percussion Group: Σύγχρονη μουσική για κρουστά Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-greek-percussion-group/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66616_thum.jpg)
  Τετάρτη 11 Νοεμβρίου 2026   
  -Πέμπτη 26 Νοεμβρίου 2026

  ##### «Lacrimosa ή το Απέπρωτο» του Θανάση Τριαρίδη - 2ος χρόνος*ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΘΕΣΣΑΛΟΝΙΚΗ*](/event/lacrimosa-h-to-apeproto-theatro-avlaia-thessaloniki/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67117_228x222_generic_1.jpg)
  Πέμπτη 12 Νοεμβρίου 2026   
  -Κυριακή 15 Νοεμβρίου 2026

  ##### Τζουζέπε Βέρντι, Ναμπούκο*ΠΟΛΙΤΙΣΤΙΚΟ ΣΥΝΕΔΡΙΑΚΟ ΚΕΝΤΡΟ ΗΡΑΚΛΕΙΟΥ - ΑΙΘΟΥΣΑ ΑΝΔΡΕΑΣ ΚΑΙ ΜΑΡΙΑ ΚΑΛΟΚΑΙΡΙΝΟΥ*](/event/cccc-nabucco/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65310_msm.jpg)
  Πέμπτη 12 Νοεμβρίου 2026

  ##### Magna Grecia: Ένας τόπος Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-magna-grecia/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65311_msm.jpg)
  Παρασκευή 13 Νοεμβρίου 2026

  ##### 19 χρόνια ARTéfacts ensemble Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-19-years-of-artefacts-ensemble/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65944_thum.jpg)
  Από 13 Νοεμβρίου 2026

  ##### Ο ΦΟΝΙΑΣ*ΠΛΥΦΑ - ΚΤΗΡΙΟ 7Α*](/event/plyfa-fonias/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66257_center.jpg)
  Από: Παρασκευή 13 Νοεμβρίου 2026

  ##### ΑΜΕΡΙΚΑΝΙΚΟΣ ΒΟΥΒΑΛΟΣ*ΠΟΛΛΑΠΛΟΙ ΧΩΡΟΙ*](/event/amerikanikos-vouvalos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67093_front.jpg)
  Παρασκευή 13 Νοεμβρίου 2026

  ##### Μπουζούκια στην Πίστα Μουσική Παράσταση*ΙΩΑΝΝΙΝΑ - STAGE IOANNINA*](/event/bouzoukia-stin-pista-ioannina-november-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66474_thum.jpg)
  Από 14 Νοεμβρίου 2026

  ##### Η ΛΙΜΝΗ ΤΩΝ ΚΥΚΝΩΝ*ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΠΟΛΥΧΩΡΟΣ ΤΕΧΝΩΝ ΠΕΙΡΑΙΑΣ*](/event/i-limni-ton-kyknon-theatro-avlaia-peiraias/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65312_msm.jpg)
  Σάββατο 14 Νοεμβρίου 2026

  ##### A Fragment Concert - A Concert in Fragments: Αφιέρωμα στους Γκιαιργκ Λίγκετι και Γκιαιργκ Κούρταγκ Ημέρες Σύγχρονης Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-a-fragment-concert/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66767_th8m.jpg)
  Σάββατο 14 Νοεμβρίου 2026   
  -Κυριακή 15 Νοεμβρίου 2026

  ##### «Τα κορίτσια δεν πρέπει να παίζουν ποδόσφαιρο»*Κέντρο Πολιτισμού & Τέχνων «Θεατρίνη» ΒΟΛΟΣ*](/event/volos-ta-koritsia-den-prepei-na-paizoyn-podosfairo/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66003_thumbnail.jpg)
  Από 15 Νοεμβρίου 2026

  ##### Ο ΚΑΡΥΟΘΡΑΥΣΤΗΣ 4ος χρόνος*ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΠΟΛΥΧΩΡΟΣ ΤΕΧΝΩΝ ΠΕΙΡΑΙΑΣ*](/event/o-kariothraustis-theatro-avlaia-peiraias/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_61870_front.jpg)
  Διαθέσιμη για on demand μετάδοση από 16 Μαρτίου έως 16 Νοεμβρίου 2026

  ##### ΤΟΣΚΑ*GNO TV - ON DEMAND*](/event/gno-tv-tosca/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65016_thumbnail.jpg)
  Δευτέρα 16 Νοεμβρίου 2026   
  -Δευτέρα 07 Δεκεμβρίου 2026

  ##### ΜΙΣΗ ΠΑΤΡΙΔΑ*Μικρός Κεραμεικός*](/event/mikros-kerameikos-misi-patrida/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_53594_front.jpg)
  Διαθέσιμη για on demand μετάδοση από 17/03/2026 έως 17/11/2026

  ##### ΜΑΚΑΡΙΟΙ ΟΙ ΜΑΣΤΟΙ ΟΙ ΟΥΚ ΕΘΗΛΑΣΑΝ...*GNO TV - ON DEMAND*](/event/gno-tv-makarioi-oi-mastoi-oi-ouk-ethilasan/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66921_TH8M.jpg)
  Τετάρτη 18 Νοεμβρίου 2026   
  -Πέμπτη 17 Δεκεμβρίου 2026

  ##### «Χήνες» (2ος χρόνος)*ΠΛΥΦΑ*](/event/plyfa-xines/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65313_mpm.jpg)
  Πέμπτη 19 Νοεμβρίου 2026

  ##### Το baryton του πρίγκιπα Έστερχαζυ και οι βιολοντσελίστες του Μπετόβεν Ημέρες Παλαιάς Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-prince-esterhzys-baryton/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66864_thum.jpg)
  Πέμπτη 19 Νοεμβρίου 2026   
  -Παρασκευή 27 Νοεμβρίου 2026

  ##### flux playground *ΠΛΥΦΑ - ΚΤΗΡΙΟ 7Α*](/event/plyfa-flux-playground/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65314_mpm.jpg)
  Παρασκευή 20 Νοεμβρίου 2026

  ##### Λούντβιχ βαν Μπετόβεν – Σονάτες για βιολί και φορτεπιάνο Ημέρες Παλαιάς Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-beethoven-sonatas-for-violin-and-fortepiano/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67096_front.jpg)
  Παρασκευή 20 & 27 Νοεμβρίου 2026

  ##### Μπουζούκια στην Πίστα Μουσική Παράσταση*ΘΕΣΣΑΛΟΝΙΚΗ - BLOCK 33*](/event/bouzoukia-stin-pista-thessaloniki-november-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66240_1.jpg)
  Σάββατο 21 Νοεμβρίου 2026

  ##### 22ο Διεθνές Φεστιβάλ Μουσικών Συνόλων *Αίθουσα Τελετών ΑΠΘ - ΘΕΣΣΑΛΟΝΙΚΗ*](/event/22o-diethnes-festival-mousikon-synolon/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65315_mpm.jpg)
  Σάββατο 21 Νοεμβρίου 2026

  ##### Λούντβιχ βαν Μπετόβεν, Φραντς Σούμπερτ: Κουιντέτα εγχόρδων Ημέρες Παλαιάς Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-beethoven-schubert-string-quintets/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66287_261121_FedericoAlbanese_228x222_THUMBNAIL.jpg)
  Σάββατο 21 Νοεμβρίου 2026

  ##### Federico Albanese*Φιλολογικός Σύλλογος «Παρνασσός»*](/event/fsp-federico-albanese/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67111_thum.jpg)
  Σάββατο 21 Νοεμβρίου 2026

  ##### ΔΑΥΙΔ ΝΑΧΜΙΑΣ Αφιέρωμα στον ΑΤΤΙΚ*ΩΔΕΙΟ ΑΘΗΝΩΝ - Αμφιθέατρο Ιωάννης Δεσποτόπουλος*

  *141 χρόνια φέτος απ' τη γέννηση του ιππότη μιας τέχνης εφήμερης αλλά ανίκητης.Τον θυμόμαστε μέσα από μια αξέχαστη παράσταση με τα υπέροχα τραγούδια του....Ζητάτε να σας πω, Τα τελευταία γιασεμιά, Τα μαραμένα γιούλια, Τα καημένα τα νιάτα και πολλά άλλα, μοναδικά ερμηνευμένα απ' την Χριστίνα Σαμαρά.*](/event/oa-david-nahmias-afieroma-ston-attik/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66676_xatzis-front.jpg)
  Σάββατο 21 Νοεμβρίου 2026

  ##### Συναυλία Κώστα Χατζή*Αίθουσα Τελετών του Αριστοτελείου Πανεπιστημίου Θεσσαλονίκης*

  *Ο αγαπητός Κώστας Χατζής υπόσχεται μία μεγαλειώδη συναυλία θα μας κρατήσει συντροφιά με αγαπημένα τραγούδια που άφησαν εποχή. Μαζί με τον Κώστα Χατζή ο Μάκης Ψαραδέλλης και η Δανιέλα Χατζή*](/event/kostas-xatzis-thessaloniki/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66825_front.jpg)
  Σάββατο 21 Νοεμβρίου 2026

  ##### Otra Rota*Eightball Club & Live Stage - Θεσσαλονίκη*](/event/otra-rota-eightball-thessaloniki/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_22798_cccc_thumbnail.jpg)
  Σάββατο 21 Νοεμβρίου 2026

  ##### Nikolai Lugansky*ΠΟΛΙΤΙΣΤΙΚΟ ΣΥΝΕΔΡΙΑΚΟ ΚΕΝΤΡΟ ΗΡΑΚΛΕΙΟΥ - ΑΙΘΟΥΣΑ ΑΝΔΡΕΑΣ ΚΑΙ ΜΑΡΙΑ ΚΑΛΟΚΑΙΡΙΝΟΥ*](/event/cccc-nikolai-lugansky/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65316_mpm.jpg)
  Κυριακή 22 Νοεμβρίου 2026

  ##### Τραγούδια σε καιρούς που αλλάζουν – Χάυντν, Μότσαρτ, Μπετόβεν / Μπετόβεν – Σεπτέτο Ημέρες Παλαιάς Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-songs-in-shifting-times/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_53800_front.jpg)
  Διαθέσιμη για on demand μετάδοση από 26/03/2026 έως 25/11/2026

  ##### MADRE SALONICO*GNO TV - ON DEMAND*](/event/gno-tv-madre-salonico/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65317_mpm.jpg)
  Τετάρτη 25 Νοεμβρίου 2026

  ##### Τιμολέων και Ιουλία: Μια μπαρόκ ιστορία παρένδυσης Ημέρες Παλαιάς Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-timoleon-and-julia/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65318_mpm.jpg)
  Πέμπτη 26 Νοεμβρίου 2026

  ##### Στραβαγκάντσα Ημέρες Παλαιάς Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-stravaganza/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_61872_front.jpg)
  Διαθέσιμη για on demand μετάδοση από 27 Μαρτίου έως 27 Νοεμβρίου 2026

  ##### ΖΙΖΕΛ*GNO TV - ON DEMAND*](/event/gno-tv-giselle/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65319_mpm.jpg)
  Παρασκευή 27 Νοεμβρίου 2026

  ##### VOLKS:LIEDER:ABEND – Τραγούδια του Γιοχάννες Μπραμς Ημέρες Παλαιάς Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-volks-lieder-abend/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65320_mpm.jpg)
  Παρασκευή 27 Νοεμβρίου 2026

  ##### Γ. Σ. Μπαχ: Παραλλαγές Γκόλντμπεργκ Ημέρες Παλαιάς Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-j-s-bach-goldberg-variations/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65870_3.jpg)
  Από 28 Νοεμβρίου 2026

  ##### Ο ΒΥΣΣΙΝΟΚΗΠΟΣ*ΕΘΝΙΚΟ ΘΕΑΤΡΟ - ΚΕΝΤΡΙΚΗ ΣΚΗΝΗ*](/event/n-t-vissinokipos-2/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66296_b_55110_or_b_44044_or_thum.jpg)
  Σάββατο 28 Νοεμβρίου 2026

  ##### L. v. Beethoven: 3 σονάτες για πιάνο*MOMus - ΜΟΥΣΕΙΟ ΣΥΓΧΡΟΝΗΣ ΤΕΧΝΗΣ - Αμφιθέατρο ''Ξανθίππη Χόιπελ''*](/event/mousikes-sto-mouseio-l-v-beethoven-3-sonates-gia-piano/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65321_mpm.jpg)
  Σάββατο 28 Νοεμβρίου 2026

  ##### Τριστάνος Ημέρες Παλαιάς Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-tristan/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67120_228x222_generic_1.jpg)
  Σάββατο 28 Νοεμβρίου 2026

  ##### Alekos Vretos Quartet «Mediterranean Echoes»*ΠΟΛΙΤΙΣΤΙΚΟ ΣΥΝΕΔΡΙΑΚΟ ΚΕΝΤΡΟ ΗΡΑΚΛΕΙΟΥ - ΑΙΘΟΥΣΑ ΣΥΝΑΥΛΙΩΝ*](/event/cccc-alekos-vretos-quartet-mediterranean-echoes/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65916_thum.jpg)
  Κυριακή 29 Νοεμβρίου 2026   
  -Κυριακή 20 Δεκεμβρίου 2026

  ##### ΤΑ ΞΥΛΙΝΑ ΣΠΑΘΙΑ του Παντελή Καλιότσου 3η χρονιά*RADIO CITY - ΘΕΣΣΑΛΟΝΙΚΗ*](/event/radio-city-ta-xilina-spathia-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66431_thumbnail.jpg)
  29.11 - 30.12.2026

  ##### 'Ενα παράξενο πρωτοχρονιάτικο ταξίδι*ΜΟΥΣΙΚΗ ΒΙΒΛΙΟΘΗΚΗ ΣΤΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ - ΑΙΘΟΥΣΑ ΓΙΑΝΝΗΣ ΜΑΡΙΝΟΣ*](/event/mmb-ena-parakseno-prwtoxroniatiko-taksidi-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65322_mpm.jpg)
  Κυριακή 29 Νοεμβρίου 2026

  ##### Camino medieval: Το μακρύ οδοιπορικό της πίστης Ημέρες Παλαιάς Μουσικής*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-camino-medieval/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63590_9bd0a9f46d0be2304f6a8e0e718fefae_M_1_.jpg)
  Κυριακή 06 Δεκεμβρίου 2026   
  -Τρίτη 05 Ιανουαρίου 2027

  ##### Ντάμα πίκα*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ*](/event/gno-2627-ntama-pika/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65274_SPYRIDOYLES-228x222.jpg)
  από 10 Δεκεμβρίου 2026

  ##### ΣΠΥΡΙΔΟΥΛΕΣ της Νεφέλης Μαϊστράλη*ΣΥΓΧΡΟΝΟ ΘΕΑΤΡΟ*](/event/spyridoules-sychrono-theatro/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66430_b_54910_or_COMEDY CLUB.jpg)
  12 – 27.12.2026

  ##### Comedy Club για παιδιά: Xmas Special*ΜΟΥΣΙΚΗ ΒΙΒΛΙΟΘΗΚΗ ΣΤΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ - ΑΙΘΟΥΣΑ ΓΙΑΝΝΗΣ ΜΑΡΙΝΟΣ*](/event/comedy-club-gia-paidia-xmas-special-2026/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65283_0ed1eb326532392735add2ea1ae3f6e6_M_1_.jpg)
  Σάββατο 12 Δεκεμβρίου 2026   
  -Σάββατο 09 Ιανουαρίου 2027

  ##### Viva la mamma!*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-viva-la-mamma-snfcc-members/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66277_228x222.jpg)
  Σάββατο 12 Δεκεμβρίου 2026

  ##### «ΑΥΤΟΚΡΑΤΟΡΙΚΗ ΒΙΕΝΝΗ & ΒΙΕΝΝΕΖΙΚΑ ΒΑΛΣ» JOHANN STRAUSS VIRTUOSI*ΔΗΜΟΤΙΚΟ ΘΕΑΤΡΟ ΒΟΛΟΥ «ΒΑΓΓΕΛΗΣ ΠΑΠΑΘΑΝΑΣΙΟΥ»*](/event/johann-strauss-virtuosi-autokratoriki-vienni-kai-viennezika-vals-volos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65284_58bb2b941541c01fa36a411d1d717292_M_1_.jpg)
  Κυριακή 13 Δεκεμβρίου 2026   
  -Σάββατο 09 Ιανουαρίου 2027

  ##### Ο Καραγκιόζης Ριγολέττος*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-karagiozis-as-rigoletto/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65560_thum.jpg)
  Κυριακή 13 Δεκεμβρίου 2026

  ##### ΔΑΥΙΔ ΝΑΧΜΙΑΣ Ελληνική ΟΠΕΡΕΤΑ Τα κωμικά τραγούδια*Φιλολογικός Σύλλογος «Παρνασσός»*](/event/parnassos-david-nachmias-elliniki-opereta/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66088_228x222.jpg)
  Κυριακή 13 Δεκεμβρίου 2026

  ##### «ΑΥΤΟΚΡΑΤΟΡΙΚΗ ΒΙΕΝΝΗ & ΒΙΕΝΝΕΖΙΚΑ ΒΑΛΣ» JOHANN STRAUSS VIRTUOSI*ΘΕΑΤΡΟ ΠΑΝΘΕΟΝ - ΠΑΤΡΑ*](/event/johann-strauss-virtuosi-autokratoriki-vienni-kai-viennezika-vals-patra/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65496_thumbnail.jpg)
  Τρίτη 15 Δεκεμβρίου 2026   
  -Τρίτη 05 Ιανουαρίου 2027

  ##### Πάνος Βλάχος acoustic live*ΘΕΑΤΡΟ ΜΕΤΣ*](/event/panos-vlaxos-acoustic-live-theatro-mets/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_67060_THUM.jpg)
  Κυριακή 20 Δεκεμβρίου 2026   
  -Τετάρτη 30 Δεκεμβρίου 2026

  ##### Η ΜΑΓΙΚΗ ΚΑΜΙΝΑΔΑ ΤΩΝ ΧΡΙΣΤΟΥΓΕΝΝΩΝ 10η χρονιά*ΠΟΛΛΑΠΛΟΙ ΧΩΡΟΙ*](/event/i-magiki-kaminada-ton-xristougennon-10-xronia/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63591_964461e18e0c6d415a4e6793fc38b836_M_1_.jpg)
  Κυριακή 20 Δεκεμβρίου 2026   
  -Κυριακή 10 Ιανουαρίου 2027

  ##### Ζιζέλ*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ*](/event/gno-2627-zizel/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66866_thum.jpg)
  Τετάρτη 23 Δεκεμβρίου 2026

  ##### ΤΣΕΡΡΥ ΜΠΡΑΝΤΥ και Τέλος Χρόνου + TBA έκπληξη*ΚΥΤΤΑΡΟ LIVE*](/event/kyttaro-live-cherry-brandy/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65490_thumbnail.jpg)
  Τετάρτη 23 Δεκεμβρίου 2026   
  -Τετάρτη 30 Δεκεμβρίου 2026

  ##### Χριστίνα Μαξούρη «Τραγούδια για τον πόνο του ανθρώπου & των πραγμάτων» Μέρος 2ο*ΘΕΑΤΡΟ ΜΕΤΣ*](/event/tragoudia-gia-ton-pono-tou-anthropou-kai-ton-pragmaton-theatro-mets/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63592_140bbc5f1d3c577712bf8e9fb16239b7_M_1_.jpg)
  Κυριακή 27 Δεκεμβρίου 2026   
  -Κυριακή 10 Ιανουαρίου 2027

  ##### Το αηδόνι του αυτοκράτορα*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ*](/event/gno-2626-to-aidoni-tou-aftokratora/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_44645_FRONT.jpg)
  Φεβρουάριος - Μάιος 2026

  ##### Τοίχος Αναρρίχησης*ΚΠΙΣΝ - Buffer Zone (πίσω από το Parking)*](/event/snfcc-climbing-wall/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65492_thumbnail.jpg)
  Τετάρτη 06 Ιανουαρίου 2027   
  -Τετάρτη 27 Ιανουαρίου 2027

  ##### Χρήστος Αδαμόπουλος «ΠΡΙΒΕ»*ΘΕΑΤΡΟ ΜΕΤΣ*](/event/xristos-adamopoulos-prive-theatro-mets/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66535_thy.jpg)
  από 23 Ιανουαρίου 2027

  ##### Παραλλαγές Πάπιας*ΘΕΑΤΡΟ ΑΛΚΜΗΝΗ - ΣΚΗΝΗ INTERMEDIA*](/event/theatro-alkmini-parallages-papias/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66299_b_55110_or_b_44044_or_thum.jpg)
  Σάββατο 23 Ιανουαρίου 2027

  ##### Βίοι παράλληλοι Μελωδίες της μεγάλης οθόνης*MOMus - ΜΟΥΣΕΙΟ ΣΥΓΧΡΟΝΗΣ ΤΕΧΝΗΣ - Αμφιθέατρο ''Ξανθίππη Χόιπελ''*](/event/mousikes-sto-mouseio-bioi-paralliloi-melodies-tis-megalis-othonis/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65286_ffc60810ac8d6da81339d1db1e98545d_M_1_.jpg)
  Σάββατο 23 Ιανουαρίου 2027   
  -Τετάρτη 27 Ιανουαρίου 2027

  ##### Notes on Camp*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-notes-on-camp/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63593_c119827c4b997d3713e1222e73d94218_M_1_.jpg)
  Κυριακή 24 Ιανουαρίου 2027   
  -Πέμπτη 11 Φεβρουαρίου 2027

  ##### Τόσκα*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ*](/event/gno-2627-tosca/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65494_thumbnail.jpg)
  Τετάρτη 03 Φεβρουαρίου 2027   
  -Τετάρτη 24 Φεβρουαρίου 2027

  ##### «Από λιμάνι σε λιμάνι...»*ΘΕΑΤΡΟ ΜΕΤΣ*](/event/apo-limani-se-limani-theatro-mets/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65287_675e778ba8686cf2b8ba20d276bed1fb_M_1_.jpg)
  Παρασκευή 05 Φεβρουαρίου 2027   
  -Σάββατο 13 Φεβρουαρίου 2027

  ##### Paradise Lost - Μορφαί δαιμονίων*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/paradise-lost-morfai-demonion/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66202_beethoven-front.jpg)
  6 ,18 Φεβρουαρίου & 5 Μαρτίου 2027 

  ##### ΚΥΚΛΟΣ ΜΠΕΤΟΒΕΝ 2027*Φιλολογικός Σύλλογος «Παρνασσός»*](/event/parnassos-kyklos-beethoven-2027/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63594_e6f3d5080af6d142056d3c1a9dda7670_M_1_.jpg)
  Παρασκευή 12 Φεβρουαρίου 2027   
  -Κυριακή 07 Μαρτίου 2027

  ##### Λεωφορείον ο Πόθος*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ*](/event/gno-2627-leoforeion-o-pothos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65499_thumbnail.jpg)
  4 - 7 Μαρτίου 2027

  ##### UP THE HAMMERS XXI 2027*ΑΘΗΝΑ - GAGARIN - KYTTARO*](/event/up-the-hammers-xxi/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63595_8e2c3e7db2de9896549c07c11a299421_M_1_.jpg)
  Παρασκευή 05 Μαρτίου 2027   
  -Παρασκευή 19 Μαρτίου 2027

  ##### Ασώτου ανάβασις (The Rake's Progress)*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ*](/event/gno-2627-asotou-anavasis/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66305_b_55110_or_b_44044_or_thum.jpg)
  Σάββατο 27 Μαρτίου 2027

  ##### Αντηχήσεις δύο αιώνων*MOMus - ΜΟΥΣΕΙΟ ΣΥΓΧΡΟΝΗΣ ΤΕΧΝΗΣ - Αμφιθέατρο ''Ξανθίππη Χόιπελ''*](/event/mousikes-sto-mouseio-antixiseis-dyo-aionon/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65288_3ceb855a6870dce87035e4af81df6dfe_M_1_.jpg)
  Σάββατο 27 Μαρτίου 2027   
  -Κυριακή 28 Μαρτίου 2027

  ##### Κάθοδος*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-descent/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63596_59ce8749c8d7df0e143865bb77684077_M_1_.jpg)
  Πέμπτη 08 Απριλίου 2027   
  -Κυριακή 09 Μαΐου 2027

  ##### Οθέλλος*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ*](/event/gno-262w7-othellos/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65290_c168b6e6a9ebcb72eb1b0fcf1b4dd3ca_M_1_.jpg)
  Παρασκευή 09 Απριλίου 2027   
  -Κυριακή 18 Απριλίου 2027

  ##### Αντίχριστος*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-antichrist/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_65285_f4dd5c1a7bbb150619bc2bac1c3d9648_M_1_.jpg)
  Παρασκευή 23 Απριλίου 2027   
  -Σάββατο 24 Απριλίου 2027

  ##### Η προσφορά*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ*](/event/gno-the-offer/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63597_58f6221a9daf67e9183a6b412beeae22_M_1_.jpg)
  Κυριακή 23 Μαΐου 2027   
  -Τετάρτη 02 Ιουνίου 2027

  ##### Missa solemnis*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ*](/event/gno-2626-missa-solemnis/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_66310_b_55110_or_b_44044_or_thum.jpg)
  Σάββατο 29 Μαΐου 2027

  ##### Σκιές και φώτα του μεσοπολέμου*MOMus - ΜΟΥΣΕΙΟ ΣΥΓΧΡΟΝΗΣ ΤΕΧΝΗΣ - Αμφιθέατρο ''Ξανθίππη Χόιπελ''*](/event/mousikes-sto-mouseio-skies-kai-fota-tou-mesopolemou/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_64400_KOLLINES-FRONT-LOYKY.jpg)
  18 - 19 - 20 - 21 Ιουνίου 2027

  ##### KOLLINES SOUND FESTIVAL II*Κολλίνες Αρκαδίας*](/event/kollines-sound-festival-II/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63598_8e481b6d0e658fe6d85565ec9d0b85b3_M_1_.jpg)
  Παρασκευή 25 Ιουνίου 2027   
  -Κυριακή 18 Ιουλίου 2027

  ##### Μαντάμα Μπαττερφλάι*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ*](/event/gno-2627-madama-butterfly/?lang=el)
* [![](https://stream.ticketservices.gr/www.ticketservices.gr/pictures/main/main4_63599_565b1e1bb1e978b64d02ee140ef206aa_M_1_.jpg)
  Σάββατο 17 Ιουλίου 2027   
  -Παρασκευή 30 Ιουλίου 2027

  ##### Ριγολέττος*ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ - ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ*](/event/gno-2627-rigolettos/?lang=el)

div.searchtextwrap { text-align: center; margin-top: 20px; }
div.searchtextwrap input.searchtext { font-size: 15px; width: 400px; display: inline-block; padding: 2px 2px 2px 30px; border: 5px solid #f0f0f0; border-radius: 5px; background: url('/images/search-grey.png') no-repeat 0px 0px; }
div.searchtextwrap a.btnclearsearchtext { visibility: hidden; color: #800000; text-decoration: none; font-weight: bold; margin-left: 10px; }
.hassearchtext div.searchtextwrap a.btnclearsearchtext { visibility: visible; }
div.filters { text-align: center; max-width: 1020px; margin: 0 auto; }
div.filters a { color: #000; }
div.filters ul.dates { margin: 10px 0 ; }
div.filters ul.dates li { list-style-type: none; background-image: none; padding: 0; margin: 10px 10px; display: inline-block;}
div.filters ul.dates li a { display: block; text-decoration: none; background-color: #F0F0F0; padding: 10px 10px; /\*border-radius: 8px; box-shadow: 2px 2px 2px #808080;\*/ position: relative; }
div.filters ul.dates li.checked { border: 1px solid #808080; }
div.filters ul.dates li a:hover { box-shadow: 5px 5px 5px #802020; color: #000; }
div.filters ul.dates li a label { display: block; font-weight: bold; }
/\* div.filters ul.dates li a label.day { } \*/
div.filters ul.dates li a label.date { color: #800000; }
div.filters ul.dates li a label.descr { font-size: 0.8em; margin-top: 5px; }
div.filters ul.dates li.checked a { background-color: #800000; color: #fefefe;}
div.filters ul.dates li.checked a:hover { color: #808080; box-shadow: 5px 5px 5px #202020;}
div.filters ul.dates li.checked a label.date { color: #F0F0F0; }
div.filters ul.dates li.noevents a { background-color: #fff; color: #c0c0c0; }
div.filters ul.dates li.noevents a label.date { color: #F0c0c0; }
div.filters ul.dates li a div.btnremove { display: none; position: absolute; top: -10px; right: -10px; padding: 0px 4px; border-radius: 100px; color: #fff; border: 3px solid #FF0000; background-color: #FF0000; }
div.filters ul.dates li a:hover div.btnremove {background-color: #A00000; }
div.filters ul.dates li.checked a div.btnremove { display: block; }
.filtered ul#events\_list li { display: none; }
.filtered ul#events\_list li.filtermatch { display: inline-block; }
.hassearchtext ul#events\_list li { display: none; }
.hassearchtext ul#events\_list li.searchtextmatch { display: inline-block; }
.hassearchtext.filtered ul#events\_list li { display: none; }
.hassearchtext.filtered ul#events\_list li.searchtextmatch.filtermatch { display: inline-block; }
.cal { display: none; text-align: left; overflow-x: auto; height: auto; width: 100%; white-space: nowrap; /\*border: 3px dotted #800000; \*/padding: 0px; }
.cal div.month div.week { padding: 1px 2px; }
.cal div.month div.weekdays { padding: 1px 2px; font-weight: bold; }
.cal div.month div.weekdays span { display: inline-block; width: 25px; margin: 0 1px; text-align: center; font-size: 10px; }
.cal div.month div.week span { display: inline-block; width: 25px; margin: 0 1px; text-align: center; }
/\* .cal div.month a { text-decoration: none; display: block; background-color: #F0F0F0; border: 2px solid #f0f0f0; text-align: center; }\*/
.cal div.month a {
text-decoration: none;
display: block;
background-color: #fff;
border: 2px solid #f0f0f0;
text-align: center;
}
.cal div.month a:hover { border: 2px solid black;}
.cal a { text-decoration: none; font-size: 10px; line-height: 18px; }
.cal a:hover { text-decoration: none; color: inherit; }
.cal span.past a { background-color: #fff; color: #808080; border-color: #fff; cursor: no-drop; }
/\* .cal span.noevents a { background-color: #fff; color: #808080; border-color: #fff; }\*/
.cal span.noevents a { background-color: #f0f0f0; color: #808080; border-color: #f0f0f0; }
.cal span.today a { border-color: orange; }
.cal span.checked a { background-color: #800000; color: #fff; }
/\* .cal div.month { display: inline-block; margin: 10px 10px; vertical-align: top; }\*/
.cal div.month {
display: inline-block;
margin: 10px 10px;
vertical-align: top;
background: #f0f0f0;
padding: 1rem;
border-radius: 7px;
}
.cal div.month .name { font-weight: bold; background-color: #F0F0F0; padding: 2px 0; text-align: center; }
div.areasfilter { text-align: center; padding: 20px 0px; }
div.areasfilter div.area { display: inline-block; }
div.areasfilter div.area a.areaname { position: relative; background-color: #F0F0F0; text-decoration: none; display: block; margin: 10px 10px; padding: 14px 8px; /\*border-radius: 5px; box-shadow: 5px 5px 5px #802020;\*/ }
div.areasfilter div.area a.areaname:hover { background-color: #808080; color: #fff; }
div.areasfilter div.area.checked a.areaname { background-color: #800000; color: #fff; }
div.areasfilter div.area.checked a.areaname:hover { background-color: #808080; color: #fff; }
div.areasfilter div.area a.areaname div.btnremove { display: none; position: absolute; font-size: 10px; top: -5px; right: -8px; padding: 0px 2px; border-radius: 100px; color: #fff; border: 3px solid #ff0000; background-color: #ff0000; }
div.areasfilter div.area a.areaname:hover div.btnremove { background-color: #800000; }
div.areasfilter div.area.checked a.areaname div.btnremove { display: block; }
div.venuesfilter { text-align: left; }
div.venuesfilter div.venues div.venue a.venuename { background-color: #fff; text-decoration: none; display: block; margin: 2px 0; padding: 2px 4px; }
div.venuesfilter div.venues div.venue a.venuename:hover { background-color: #f0f0f0; color: #800000; } \*/
div.venuesfilter div.venueswrap { margin: 10px auto; }
div.venuesfilter div.venues { padding: 0; margin: 0; height: 200px; overflow-x: hidden; overflow-y: scroll; border: 1px solid #000; }
div.venuesfilter div.venues div.venue > div.name { background-color: #f0f0f0; }
div.venuesfilter div.venues div.venue.checked a.venuename { background-color: #800000; color: #fff; position: relative; }
div.venuesfilter div.venues div.venue a.venuename div.btnremove { display: none; position: absolute; font-size: 10px; top: 1px; right: 4px; padding: 0px 2px; border-radius: 100px; color: #fff; border: 3px solid #ff0000; background-color: #ff0000; }
div.venuesfilter div.venues div.venue a.venuename:hover div.btnremove { background-color: #800000; }
div.venuesfilter div.venues div.venue.checked a.venuename div.btnremove { display: block; }
div.venuesfilter div.venueswrap div.venues div.area { display: block; margin-bottom: 10px; }
div.venuesfilter div.venueswrap div.venues div.area div.areavenues { margin-left: 20px; margin-right: 20px; }
div.venuesfilter div.venueswrap div.venues div.area div.name { font-weight: bold; font-size: 10px; background-color: #F0f0e0; padding: 2px 0; }
div.venuesfilter div.venueswrap.filtered div.venues div.area { display: none; }
div.venuesfilter div.venueswrap.filtered div.venues div.area.infilter { display: block; }
div.venuesfilter div.venueswrap.hassearch div.venues div.venue { display: none; }
div.venuesfilter div.venueswrap.hassearch div.venues div.venue.searchmatch { display: block; }
div.venuesfilter div.venueswrap.hassearch div.area div.name { display: none; }
div.venuesfilter div.venueswrap.hassearch div.area div.name.searchmatch { display: block; }
div.venuesfilter div.venueswrap .title { text-align: center;}
div.venuesfilter div.venueswrap input.searchvenues { border: 1px solid #808080; width: 300px; line-height: 20px; margin: 10px 0px; font-size: 14px; }
div.venuesfilter div.venueswrap a.btnclearsearchvenues { visibility: hidden; font-size: 10px; padding: 0px 4px; border-radius: 100px; color: #800000; text-decoration: none; }
div.venuesfilter div.venueswrap.hassearch a.btnclearsearchvenues { visibility: visible; }
.venuesfilterwrap {
max-width: 400px;
margin: 0 auto;
}
.filterstopbuttons { text-align: center; }
.filterstopbuttons .fltbuttonwrap { display: inline-block; margin: 10px 10px; }
.filterstopbuttons .fltbuttonwrap a.filterstoggler { display: block; text-decoration: none; font-weight: bold; color: #000; background-color: #f0f0f0; display: inline-block; padding: 8px 10px;}
.filterstopbuttons .fltbuttonwrap.expanded a.filterstoggler { background-color: #800000; color: #fff; }
.filterstopbuttons .fltbuttonwrap a.filterstoggler:hover { background-color: #808080; color: #fff; }
.filterstopbuttons .fltbuttonwrap.expanded a.filterstoggler:hover { background-color: #A00000; color: #C0C0C0; }
.filterstopbuttons .fltbuttonwrap a.filterstoggler .label { display: inline-block; width: 150px; text-align: left; }
.filterstopbuttons .fltbuttonwrap a.filterstoggler .arrow { display: inline-block; width: 20px; }
.filterstopbuttons .fltbuttonwrap a.filterstoggler .arrow:after { content: '\25B6'}
.filterstopbuttons .fltbuttonwrap.expanded a.filterstoggler .arrow:after { content: '\25BC'}
/\* .filterssections {} \*/
.filterssections .filterswrap { display: none; }
.filterssections .filterswrap.expanded { display: block; }
.filterssections .venuesfilterswrap {
max-width: 500px;
margin: 0 auto;
}
.selectedfilters { /\*min-height: 60px;\*/ padding: 5px 5px; border: 3px solid transparent; margin: 10px 0px; display: none; }
.selectedfilters.hasfilters { border: 3px solid #800000; display: block; }
.selectedfilters .label { font-weight: bold; padding: 4px 5px; }
/\* .selectedfilters .activefilters { } \*/
.selectedfilters .activefilters .filter { display: inline-block; margin: 5px 10px; }
.selectedfilters .activefilters .filter a { display: block; padding: 5px 8px; background-color: #f0f0f0; color: #000; text-decoration: none; position: relative; }
.selectedfilters .activefilters .filter a div.btnremove { display: block; position: absolute; font-size: 10px; top: -8px; right: -8px; padding: 0px 2px; border-radius: 100px; color: #fff; border: 3px solid #ff0000; background-color: #ff0000; }
.selectedfilters .activefilters .filter a div.btnremove:after { content: "X" }
.selectedfilters .activefilters .filter a:hover div.btnremove { background-color: #800000; }
.selectedfilters .result { margin-top: 10px; }
.selectedfilters .found span.resultmsg { color: #000; }
.selectedfilters .notfound span.resultmsg { background-color: #F00000; color: #fff; display: inline-block; padding: 4px 8px; border-radius: 5px; }
.filters .sclearfilters { margin-left: 20px; }
.filters .btnclearfilters { color: #800000; }

moment.locale('el');
var eventids = [];
var events = {};
var evgroups = {};
var evgroupids = [];
var dates = {};
var venueids = [3,5,6,21,24,34,48,55,61,67,69,74,84,101,102,104,109,116,125,130,135,137,142,196,203,205,209,227,247,293,308,312,318,336,386,449,453,471,531,534,548,549,556,560,572,582,625,642,655,812,834,845,864,865,869,873,874,876,884,949,1028,1077,1084,1184,1191,1208,1233,1238,1243,1247,1266,1280,1353,1359,1364,1374,1389,1407,1411,1412,1504,1505,1514,1517,1549,1560,1574,1579,1613,1614,1626,1628];
var hallids = [3,5,6,22,25,38,55,59,68,75,81,83,89,121,125,131,137,144,157,163,173,175,177,243,251,253,257,260,278,298,345,366,373,398,455,523,527,528,548,618,621,636,643,647,662,672,722,739,755,923,933,934,949,950,957,961,983,984,988,993,995,996,999,1008,1078,1141,1151,1162,1216,1219,1226,1337,1344,1361,1387,1392,1397,1401,1404,1422,1437,1511,1515,1518,1523,1534,1539,1549,1552,1575,1579,1580,1676,1677,1687,1690,1720,1727,1738,1754,1759,1794,1795,1807,1808,1810];
var areaids = [1,2,3,7,16,17,18,19,22,30,50,71,92,153];
var venues = {3:{"id":"3","name":"Φιλολογικός Σύλλογος «Παρνασσός»","areaid":"1","vorder":null},5:{"id":"5","name":"Gagarin 205 Live Music Space","areaid":"1","vorder":null},6:{"id":"6","name":"ΘΕΑΤΡΟ ΚΑΠΠΑ","areaid":"1","vorder":null},21:{"id":"21","name":"ΘΕΑΤΡΟ ΚΑΤΕΡΙΝΑ ΒΑΣΙΛΑΚΟΥ","areaid":"1","vorder":null},24:{"id":"24","name":"ΕΘΝΙΚΟ ΘΕΑΤΡΟ","areaid":"1","vorder":null},34:{"id":"34","name":"ΒΕΑΚΕΙΟ ΘΕΑΤΡΟ - ΠΕΙΡΑΙΑΣ","areaid":"1","vorder":null},48:{"id":"48","name":"ΘΕΑΤΡΟ ΡΟΕΣ","areaid":"1","vorder":null},55:{"id":"55","name":"ΘΕΑΤΡΟ ΤΖΕΝΗ ΚΑΡΕΖΗ","areaid":"1","vorder":null},61:{"id":"61","name":"ΚΥΤΤΑΡΟ LIVE","areaid":"1","vorder":null},67:{"id":"67","name":"ΑΓΓΛΙΚΑΝΙΚΗ ΕΚΚΛΗΣΙΑ ΑΓΙΟΥ ΠΑΥΛΟΥ","areaid":"1","vorder":null},69:{"id":"69","name":"ΘΕΑΤΡΟ ΚΙΒΩΤΟΣ","areaid":"1","vorder":null},74:{"id":"74","name":"BLOCK 33 - ΘΕΣΣΑΛΟΝΙΚΗ","areaid":"2","vorder":null},84:{"id":"84","name":"ΩΔΕΙΟ ΑΘΗΝΩΝ","areaid":"1","vorder":null},101:{"id":"101","name":"ΣΥΝΕΔΡΙΑΚΟ ΚΕΝΤΡΟ «ΙΩΑΝΝΗΣ ΒΕΛΛΙΔΗΣ» - ΘΕΣΣΑΛΟΝΙΚΗ","areaid":"2","vorder":null},102:{"id":"102","name":"ΘΕΑΤΡΟ ΤΗΣ ΗΜΕΡΑΣ","areaid":"1","vorder":null},104:{"id":"104","name":"ΜΟΥΣΙΚΗ ΒΙΒΛΙΟΘΗΚΗ ΣΤΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ","areaid":"1","vorder":null},109:{"id":"109","name":"ΑΡΙΣΤΟΤΕΛΕΙΟΝ ΘΕΑΤΡΟ - ΘΕΣΣΑΛΟΝΙΚΗ","areaid":"2","vorder":null},116:{"id":"116","name":"RADIO CITY - ΘΕΣΣΑΛΟΝΙΚΗ","areaid":"2","vorder":null},125:{"id":"125","name":"ΣΧΟΛΕΙΟΝ ΤΗΣ ΑΘΗΝΑΣ - ΕΙΡΗΝΗ ΠΑΠΑ","areaid":"1","vorder":null},130:{"id":"130","name":"ΘΕΑΤΡΟ ΟΔΟΥ ΚΥΚΛΑΔΩΝ<br>ΛΕΥΤΕΡΗΣ ΒΟΓΙΑΤΖΗΣ","areaid":"1","vorder":null},135:{"id":"135","name":"ΘΕΑΤΡΟ ΦΟΥΡΝΟΣ","areaid":"1","vorder":null},137:{"id":"137","name":"ΣΥΓΧΡΟΝΟ ΘΕΑΤΡΟ","areaid":"1","vorder":null},142:{"id":"142","name":"ΘΕΑΤΡΟ ΑΛΚΜΗΝΗ","areaid":"1","vorder":null},196:{"id":"196","name":"Αίθουσα Τελετών ΑΠΘ - ΘΕΣΣΑΛΟΝΙΚΗ","areaid":"2","vorder":null},203:{"id":"203","name":"ΘΕΑΤΡΟ ΠΑΝΘΕΟΝ - ΠΑΤΡΑ","areaid":"3","vorder":null},205:{"id":"205","name":"ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΘΕΣΣΑΛΟΝΙΚΗ","areaid":"2","vorder":null},209:{"id":"209","name":"ΕΘΝΙΚΗ ΛΥΡΙΚΗ ΣΚΗΝΗ - ΚΠΙΣΝ","areaid":"1","vorder":null},227:{"id":"227","name":"ΘΕΑΤΡΟ ΒΑΦΕΙΟ - ΛΑΚΗΣ ΚΑΡΑΛΗΣ","areaid":"1","vorder":null},247:{"id":"247","name":"ΠΟΛΛΑΠΛΟΙ ΧΩΡΟΙ","areaid":null,"vorder":null},293:{"id":"293","name":"ΘΕΑΤΡΟ ΜΟΡΦΕΣ ΕΚΦΡΑΣΗΣ","areaid":"1","vorder":null},308:{"id":"308","name":"ΚΕΝΤΡΟ ΠΟΛΙΤΙΣΜΟΥ ΙΔΡΥΜΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ","areaid":"1","vorder":null},312:{"id":"312","name":"ΔΗΜΟΤΙΚΟ ΘΕΑΤΡΟ ΑΣΤΕΡΙΑ - ΣΕΡΡΕΣ","areaid":"50","vorder":null},318:{"id":"318","name":"ΚΙΝΗΜΑΤΟΘΕΑΤΡΟ ΑΣΤΟΡΙΑ - ΗΡΑΚΛΕΙΟ","areaid":"16","vorder":null},336:{"id":"336","name":"ΧΩΡΟΣ ΤΕΧΝΗΣ ΑΣΩΜΑΤΩΝ","areaid":"1","vorder":null},386:{"id":"386","name":"ΔΗΜΟΤΙΚΟ ΘΕΑΤΡΟ ΒΟΛΟΥ<br>«ΒΑΓΓΕΛΗΣ ΠΑΠΑΘΑΝΑΣΙΟΥ»","areaid":"19","vorder":null},449:{"id":"449","name":"ΘΕΑΤΡΟ 104","areaid":"1","vorder":null},453:{"id":"453","name":"ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ ΚΟΜΟΤΗΝΗΣ","areaid":"71","vorder":null},471:{"id":"471","name":"ΘΕΑΤΡΟ ΧΩΡΟΣ","areaid":"1","vorder":null},531:{"id":"531","name":"ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΠΟΛΥΧΩΡΟΣ ΤΕΧΝΩΝ<br>ΠΕΙΡΑΙΑΣ","areaid":"7","vorder":null},534:{"id":"534","name":"CIRCO","areaid":null,"vorder":null},548:{"id":"548","name":"ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ ΑΘΗΝΩΝ","areaid":"1","vorder":null},549:{"id":"549","name":"ΚΑΦΩΔΕΙΟ ΕΛΛΗΝΙΚΟ","areaid":"2","vorder":null},556:{"id":"556","name":"Σταυρός του Νότου Club","areaid":"1","vorder":null},560:{"id":"560","name":"CINELAND PANTELIS - ΡΕΘΥΜΝΟ","areaid":"17","vorder":null},572:{"id":"572","name":"ΘΕΑΤΡΟ ΑΒΑΤΟΝ","areaid":"1","vorder":null},582:{"id":"582","name":"VIDEO ON DEMAND","areaid":null,"vorder":null},625:{"id":"625","name":"Βοτανικός Κήπος Διομήδους","areaid":"92","vorder":null},642:{"id":"642","name":"ΘΕΑΤΡΟ ΚΑΛΛΙΡΡΟΗΣ","areaid":"1","vorder":null},655:{"id":"655","name":"ΠΕΙΡΑΙΩΣ 260","areaid":"1","vorder":null},812:{"id":"812","name":"Μικρός Κεραμεικός","areaid":"1","vorder":null},834:{"id":"834","name":"ΠΟΛΙΤΙΣΤΙΚΟ ΣΥΝΕΔΡΙΑΚΟ ΚΕΝΤΡΟ ΗΡΑΚΛΕΙΟΥ","areaid":"16","vorder":null},845:{"id":"845","name":"ΦΙΑΤ<br>Φαλήρου 97, Κουκάκι","areaid":"1","vorder":null},864:{"id":"864","name":"ΘΕΑΤΡΟ ΕΛΕΡ - ΕΛΕΝΗ ΕΡΗΜΟΥ","areaid":"1","vorder":null},865:{"id":"865","name":"ΘΕΑΤΡΟ ARROYO","areaid":"1","vorder":null},869:{"id":"869","name":"TGI Fridays&#8482; Loft Kapnikareas","areaid":"1","vorder":null},873:{"id":"873","name":"ΘΕΑΤΡΟ ΑΛΦΑ - ΛΗΝΑΙΟΣ-ΦΩΤΙΟΥ","areaid":"1","vorder":null},874:{"id":"874","name":"ΔΗΠΕΘΕ ΚΟΜΟΤΗΝΗΣ","areaid":"71","vorder":null},876:{"id":"876","name":"ΕΠΙΚΕΝΤΡΟ+ \/ ΠΑΤΡΑ","areaid":"3","vorder":null},884:{"id":"884","name":"ΠΛΥΦΑ","areaid":"1","vorder":null},949:{"id":"949","name":"Eightball Club & Live Stage - Θεσσαλονίκη","areaid":"2","vorder":null},1028:{"id":"1028","name":"Πολυχώρος hello kids","areaid":"1","vorder":null},1077:{"id":"1077","name":"ΘΕΑΤΡΟ NO&#362;S","areaid":"1","vorder":null},1084:{"id":"1084","name":"ΘΕΑΤΡΟ SUREAL - ΘΕΣΣΑΛΟΝΙΚΗ","areaid":"2","vorder":null},1184:{"id":"1184","name":"MOMus - ΜΟΥΣΕΙΟ ΣΥΓΧΡΟΝΗΣ ΤΕΧΝΗΣ","areaid":"2","vorder":null},1191:{"id":"1191","name":"CIRCUS ENTERTAINMENT HUB - ΛΑΡΙΣΑ","areaid":"18","vorder":null},1208:{"id":"1208","name":"BAUMSTRASSE","areaid":"1","vorder":null},1233:{"id":"1233","name":"ΔΗΜΟΤΙΚΟ ΩΔΕΙΟ ΛΑΡΙΣΑΣ","areaid":"18","vorder":null},1238:{"id":"1238","name":"Apollon Cinema - ΚΑΒΑΛΑ","areaid":"30","vorder":null},1243:{"id":"1243","name":"Gustav Athens","areaid":"1","vorder":null},1247:{"id":"1247","name":"ΔΙΑΧΡΟΝΟ ΘΕΑΤΡΟ","areaid":"0","vorder":null},1266:{"id":"1266","name":"Architecture Rock Cafe - Live Stage","areaid":"1","vorder":null},1280:{"id":"1280","name":"ΓΡΑΜΜΕΣ ΤΕΧΝΗΣ - ΠΑΤΡΑ","areaid":"3","vorder":null},1353:{"id":"1353","name":"ΘΕΑΤΡΟ ΠΟΡΕΙΑ","areaid":"1","vorder":null},1359:{"id":"1359","name":"ΘΕΑΤΡΟ ΔΡΟΜΟΣ","areaid":"1","vorder":null},1364:{"id":"1364","name":"ΡΕΚΤΙΦΙΕ - Κέντρο Έρευνας<br> Μεικτών Παραστατικών Τεχνών","areaid":"1","vorder":null},1374:{"id":"1374","name":"Τεχνοχώρος Εργοτάξιον","areaid":"1","vorder":null},1389:{"id":"1389","name":"41 Street Cafe","areaid":"1","vorder":null},1407:{"id":"1407","name":"STAGE IOANNINA - ΙΩΑΝΝΙΝΑ","areaid":"22","vorder":null},1411:{"id":"1411","name":"Οικία Ιλίτς - Αθήνα","areaid":"1","vorder":null},1412:{"id":"1412","name":"Goethe - Institut Thessaloniki","areaid":"2","vorder":null},1504:{"id":"1504","name":"ΣΚΗΝΗ BRECHT 2510","areaid":"1","vorder":null},1505:{"id":"1505","name":"ΕΚΘΕΣΗ","areaid":"0","vorder":null},1514:{"id":"1514","name":"ΣΚΗΝΗ ΜΠΕΚΕΤ","areaid":"1","vorder":null},1517:{"id":"1517","name":"ΙΩΝΙΚΟ ΚΕΝΤΡΟ - Πλάκα","areaid":"1","vorder":null},1549:{"id":"1549","name":"ΘΕΑΤΡΟ ΜΕΤΣ","areaid":"1","vorder":null},1560:{"id":"1560","name":"ΘΕΑΤΡΟ ΜΑΒΙΛΗ","areaid":"1","vorder":null},1574:{"id":"1574","name":"Κολλίνες Αρκαδίας","areaid":"153","vorder":null},1579:{"id":"1579","name":"Πολιτιστικός Πολυχώρος itravelpoetry","areaid":"1","vorder":null},1613:{"id":"1613","name":"ΘΕΑΤΡΟ ΕΡΓΟΝ","areaid":"1","vorder":null},1614:{"id":"1614","name":"Κέντρο Πολιτισμού & Τέχνων «Θεατρίνη» ΒΟΛΟΣ","areaid":"19","vorder":null},1626:{"id":"1626","name":"SHAMONE CLUB","areaid":"1","vorder":null},1628:{"id":"1628","name":"NO52 - ΑΘΗΝΑ","areaid":"1","vorder":null}};
var halls = {3:{"id":"3","name":"Φιλολογικός Σύλλογος «Παρνασσός»","venueid":"3","vorder":null},5:{"id":"5","name":"Gagarin 205 Live Music Space","venueid":"5","vorder":null},6:{"id":"6","name":"ΘΕΑΤΡΟ ΚΑΠΠΑ","venueid":"6","vorder":null},22:{"id":"22","name":"ΘΕΑΤΡΟ ΚΑΤΕΡΙΝΑ ΒΑΣΙΛΑΚΟΥ","venueid":"21","vorder":null},25:{"id":"25","name":"ΚΕΝΤΡΙΚΗ ΣΚΗΝΗ","venueid":"24","vorder":null},38:{"id":"38","name":"ΒΕΑΚΕΙΟ ΘΕΑΤΡΟ - ΠΕΙΡΑΙΑΣ","venueid":"34","vorder":null},55:{"id":"55","name":"ΣΚΗΝΗ «ΝΙΚΟΣ ΚΟΥΡΚΟΥΛΟΣ»","venueid":"24","vorder":null},59:{"id":"59","name":"ΘΕΑΤΡΟ ΡΟΕΣ","venueid":"48","vorder":null},68:{"id":"68","name":"ΘΕΑΤΡΟ ΤΖΕΝΗ ΚΑΡΕΖΗ","venueid":"55","vorder":null},75:{"id":"75","name":"ΚΥΤΤΑΡΟ LIVE","venueid":"61","vorder":null},81:{"id":"81","name":"ΑΓΓΛΙΚΑΝΙΚΗ ΕΚΚΛΗΣΙΑ ΑΓΙΟΥ ΠΑΥΛΟΥ","venueid":"67","vorder":null},83:{"id":"83","name":"ΘΕΑΤΡΟ ΚΙΒΩΤΟΣ","venueid":"69","vorder":null},89:{"id":"89","name":"BLOCK 33 - ΘΕΣΣΑΛΟΝΙΚΗ","venueid":"74","vorder":null},121:{"id":"121","name":"ΣΥΝΕΔΡΙΑΚΟ ΚΕΝΤΡΟ «ΙΩΑΝΝΗΣ ΒΕΛΛΙΔΗΣ» - ΘΕΣΣΑΛΟΝΙΚΗ","venueid":"101","vorder":null},125:{"id":"125","name":"ΠΑΙΔΙΚΗ ΣΚΗΝΗ","venueid":"102","vorder":null},131:{"id":"131","name":"ΑΙΘΟΥΣΑ ΔΙΔΑΣΚΑΛΙΑΣ","venueid":"104","vorder":null},137:{"id":"137","name":"ΑΡΙΣΤΟΤΕΛΕΙΟΝ ΘΕΑΤΡΟ - ΘΕΣΣΑΛΟΝΙΚΗ","venueid":"109","vorder":null},144:{"id":"144","name":"RADIO CITY - ΘΕΣΣΑΛΟΝΙΚΗ","venueid":"116","vorder":null},157:{"id":"157","name":"ΣΧΟΛΕΙΟΝ ΤΗΣ ΑΘΗΝΑΣ - ΕΙΡΗΝΗ ΠΑΠΑ","venueid":"125","vorder":null},163:{"id":"163","name":"ΘΕΑΤΡΟ ΟΔΟΥ ΚΥΚΛΑΔΩΝ<br>ΛΕΥΤΕΡΗΣ ΒΟΓΙΑΤΖΗΣ","venueid":"130","vorder":null},173:{"id":"173","name":"ΑΙΘΟΥΣΑ ΓΙΑΝΝΗΣ ΜΑΡΙΝΟΣ","venueid":"104","vorder":null},175:{"id":"175","name":"ΘΕΑΤΡΟ ΦΟΥΡΝΟΣ","venueid":"135","vorder":null},177:{"id":"177","name":"ΣΥΓΧΡΟΝΟ ΘΕΑΤΡΟ","venueid":"137","vorder":null},243:{"id":"243","name":"Αίθουσα Τελετών ΑΠΘ - ΘΕΣΣΑΛΟΝΙΚΗ","venueid":"196","vorder":null},251:{"id":"251","name":"ΘΕΑΤΡΟ ΠΑΝΘΕΟΝ - ΠΑΤΡΑ","venueid":"203","vorder":null},253:{"id":"253","name":"ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΘΕΣΣΑΛΟΝΙΚΗ","venueid":"205","vorder":null},257:{"id":"257","name":"ΑΙΘΟΥΣΑ ΣΤΑΥΡΟΣ ΝΙΑΡΧΟΣ","venueid":"209","vorder":null},260:{"id":"260","name":"ΕΝΑΛΛΑΚΤΙΚΗ ΣΚΗΝΗ","venueid":"209","vorder":null},278:{"id":"278","name":"ΘΕΑΤΡΟ ΒΑΦΕΙΟ - ΛΑΚΗΣ ΚΑΡΑΛΗΣ","venueid":"227","vorder":null},298:{"id":"298","name":"ΠΟΛΛΑΠΛΟΙ ΧΩΡΟΙ","venueid":"247","vorder":null},345:{"id":"345","name":"ΘΕΑΤΡΟ ΜΟΡΦΕΣ ΕΚΦΡΑΣΗΣ","venueid":"293","vorder":null},366:{"id":"366","name":"ΔΗΜΟΤΙΚΟ ΘΕΑΤΡΟ ΑΣΤΕΡΙΑ - ΣΕΡΡΕΣ","venueid":"312","vorder":null},373:{"id":"373","name":"ΚΙΝΗΜΑΤΟΘΕΑΤΡΟ ΑΣΤΟΡΙΑ - ΗΡΑΚΛΕΙΟ","venueid":"318","vorder":null},398:{"id":"398","name":"ΧΩΡΟΣ ΤΕΧΝΗΣ ΑΣΩΜΑΤΩΝ","venueid":"336","vorder":null},455:{"id":"455","name":"ΔΗΜΟΤΙΚΟ ΘΕΑΤΡΟ ΒΟΛΟΥ<br>«ΒΑΓΓΕΛΗΣ ΠΑΠΑΘΑΝΑΣΙΟΥ»","venueid":"386","vorder":null},523:{"id":"523","name":"ΘΕΑΤΡΟ 104","venueid":"449","vorder":null},527:{"id":"527","name":"MusiX LAB","venueid":"104","vorder":null},528:{"id":"528","name":"ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ ΚΟΜΟΤΗΝΗΣ","venueid":"453","vorder":null},548:{"id":"548","name":"ΘΕΑΤΡΟ ΧΩΡΟΣ","venueid":"471","vorder":null},618:{"id":"618","name":"ΘΕΑΤΡΟ ΑΥΛΑΙΑ - ΠΟΛΥΧΩΡΟΣ ΤΕΧΝΩΝ<br>ΠΕΙΡΑΙΑΣ","venueid":"531","vorder":null},621:{"id":"621","name":"CIRCO","venueid":"534","vorder":null},636:{"id":"636","name":"ΚΑΦΩΔΕΙΟ ΕΛΛΗΝΙΚΟ","venueid":"549","vorder":null},643:{"id":"643","name":"Σταυρός του Νότου Club","venueid":"556","vorder":null},647:{"id":"647","name":"CINELAND PANTELIS - ΡΕΘΥΜΝΟ","venueid":"560","vorder":null},662:{"id":"662","name":"ΘΕΑΤΡΟ ΑΒΑΤΟΝ","venueid":"572","vorder":null},672:{"id":"672","name":"VIDEO ON DEMAND","venueid":"582","vorder":null},722:{"id":"722","name":"Βοτανικός Κήπος Διομήδους","venueid":"625","vorder":null},739:{"id":"739","name":"ΘΕΑΤΡΟ ΚΑΛΛΙΡΡΟΗΣ","venueid":"642","vorder":null},755:{"id":"755","name":"ΧΩΡΟΣ Η","venueid":"655","vorder":null},923:{"id":"923","name":"Μικρός Κεραμεικός","venueid":"812","vorder":null},933:{"id":"933","name":"ΣΚΗΝΗ INTERMEDIA","venueid":"142","vorder":null},934:{"id":"934","name":"ΚΕΝΤΡΙΚΗ ΣΚΗΝΗ","venueid":"142","vorder":null},949:{"id":"949","name":"ΑΙΘΟΥΣΑ ΣΥΝΑΥΛΙΩΝ","venueid":"834","vorder":null},950:{"id":"950","name":"ΠΕΙΡΑΜΑΤΙΚΟ ΘΕΑΤΡΟ","venueid":"834","vorder":null},957:{"id":"957","name":"ΑΙΘΟΥΣΑ ΑΝΔΡΕΑΣ ΚΑΙ ΜΑΡΙΑ ΚΑΛΟΚΑΙΡΙΝΟΥ","venueid":"834","vorder":null},961:{"id":"961","name":"ΦΙΑΤ<br>Φαλήρου 97, Κουκάκι","venueid":"845","vorder":null},983:{"id":"983","name":"ΘΕΑΤΡΟ ΕΛΕΡ - ΕΛΕΝΗ ΕΡΗΜΟΥ","venueid":"864","vorder":null},984:{"id":"984","name":"ΘΕΑΤΡΟ ARROYO","venueid":"865","vorder":null},988:{"id":"988","name":"TGI Fridays&#8482; Loft Kapnikareas","venueid":"869","vorder":null},993:{"id":"993","name":"SECRET ROOM","venueid":"142","vorder":null},995:{"id":"995","name":"ΔΗΠΕΘΕ ΚΟΜΟΤΗΝΗΣ","venueid":"874","vorder":null},996:{"id":"996","name":"ΘΕΑΤΡΟ ΑΛΦΑ - ΛΗΝΑΙΟΣ-ΦΩΤΙΟΥ","venueid":"873","vorder":null},999:{"id":"999","name":"ΕΠΙΚΕΝΤΡΟ+ \/ ΠΑΤΡΑ","venueid":"876","vorder":null},1008:{"id":"1008","name":"ΠΛΥΦΑ","venueid":"884","vorder":null},1078:{"id":"1078","name":"Eightball Club & Live Stage - Θεσσαλονίκη","venueid":"949","vorder":null},1141:{"id":"1141","name":"ΞΕΝΑΓΗΣΕΙΣ","venueid":"308","vorder":null},1151:{"id":"1151","name":"ΑΜΦΙΘΕΑΤΡΟ ΙΩΑΝΝΗΣ ΔΕΣΠΟΤΟΠΟΥΛΟΣ","venueid":"84","vorder":null},1162:{"id":"1162","name":"Πολυχώρος hello kids","venueid":"1028","vorder":null},1216:{"id":"1216","name":"BLACK BOX","venueid":"1077","vorder":null},1219:{"id":"1219","name":"ΘΕΑΤΡΟ NO&#362;S","venueid":"1077","vorder":null},1226:{"id":"1226","name":"ΘΕΑΤΡΟ SUREAL - ΘΕΣΣΑΛΟΝΙΚΗ","venueid":"1084","vorder":null},1337:{"id":"1337","name":"Αμφιθέατρο ''Ξανθίππη Χόιπελ''","venueid":"1184","vorder":null},1344:{"id":"1344","name":"CIRCUS ENTERTAINMENT HUB - ΛΑΡΙΣΑ","venueid":"1191","vorder":null},1361:{"id":"1361","name":"BAUMSTRASSE","venueid":"1208","vorder":null},1387:{"id":"1387","name":"ΔΗΜΟΤΙΚΟ ΩΔΕΙΟ ΛΑΡΙΣΑΣ","venueid":"1233","vorder":null},1392:{"id":"1392","name":"Apollon Cinema - ΚΑΒΑΛΑ","venueid":"1238","vorder":null},1397:{"id":"1397","name":"Gustav Athens","venueid":"1243","vorder":null},1401:{"id":"1401","name":"ΔΙΑΧΡΟΝΟ ΘΕΑΤΡΟ","venueid":"1247","vorder":null},1404:{"id":"1404","name":"ΑΙΘΟΥΣΑ ΧΡΗΣΤΟΣ ΛΑΜΠΡΑΚΗΣ","venueid":"548","vorder":null},1422:{"id":"1422","name":"Architecture Rock Cafe - Live Stage","venueid":"1266","vorder":null},1437:{"id":"1437","name":"ΓΡΑΜΜΕΣ ΤΕΧΝΗΣ - ΠΑΤΡΑ","venueid":"1280","vorder":null},1511:{"id":"1511","name":"ΘΕΑΤΡΟ ΠΟΡΕΙΑ","venueid":"1353","vorder":null},1515:{"id":"1515","name":"Τοίχος Αναρρίχησης","venueid":"308","vorder":null},1518:{"id":"1518","name":"ΘΕΑΤΡΟ ΔΡΟΜΟΣ","venueid":"1359","vorder":null},1523:{"id":"1523","name":"ΡΕΚΤΙΦΙΕ - Κέντρο Έρευνας<br> Μεικτών Παραστατικών Τεχνών","venueid":"1364","vorder":null},1534:{"id":"1534","name":"Τεχνοχώρος Εργοτάξιον","venueid":"1374","vorder":null},1539:{"id":"1539","name":"ΚΤΗΡΙΟ 7Α","venueid":"884","vorder":null},1549:{"id":"1549","name":"ΕΓΚΑΤΑΣΤΑΣΕΙΣ ΕΛΣ - ΚΠΙΣΝ","venueid":"209","vorder":null},1552:{"id":"1552","name":"41 Street Cafe","venueid":"1389","vorder":null},1575:{"id":"1575","name":"STAGE IOANNINA - ΙΩΑΝΝΙΝΑ","venueid":"1407","vorder":null},1579:{"id":"1579","name":"Οικία Ιλίτς - Αθήνα","venueid":"1411","vorder":null},1580:{"id":"1580","name":"Αίθουσα SAL","venueid":"1412","vorder":null},1676:{"id":"1676","name":"ΣΚΗΝΗ BRECHT 2510","venueid":"1504","vorder":null},1677:{"id":"1677","name":"ΕΚΘΕΣΗ","venueid":"1505","vorder":null},1687:{"id":"1687","name":"ΣΚΗΝΗ ΜΠΕΚΕΤ","venueid":"1514","vorder":null},1690:{"id":"1690","name":"ΙΩΝΙΚΟ ΚΕΝΤΡΟ - Πλάκα","venueid":"1517","vorder":null},1720:{"id":"1720","name":"BLACK BOX","venueid":"449","vorder":null},1727:{"id":"1727","name":"ΘΕΑΤΡΟ ΜΕΤΣ","venueid":"1549","vorder":null},1738:{"id":"1738","name":"ΘΕΑΤΡΟ ΜΑΒΙΛΗ","venueid":"1560","vorder":null},1754:{"id":"1754","name":"Κολλίνες Αρκαδίας","venueid":"1574","vorder":null},1759:{"id":"1759","name":"Πολιτιστικός Πολυχώρος itravelpoetry","venueid":"1579","vorder":null},1794:{"id":"1794","name":"ΘΕΑΤΡΟ ΕΡΓΟΝ","venueid":"1613","vorder":null},1795:{"id":"1795","name":"Κέντρο Πολιτισμού & Τέχνων «Θεατρίνη» ΒΟΛΟΣ","venueid":"1614","vorder":null},1807:{"id":"1807","name":"SHAMONE CLUB","venueid":"1626","vorder":null},1808:{"id":"1808","name":"MEET & GREET","venueid":"548","vorder":null},1810:{"id":"1810","name":"NO52 - ΑΘΗΝΑ","venueid":"1628","vorder":null}};
var areas = {1:{"id":"1","name":"ΑΘΗΝΑ","vorder":null},2:{"id":"2","name":"ΘΕΣΣΑΛΟΝΙΚΗ","vorder":null},3:{"id":"3","name":"ΠΑΤΡΑ","vorder":null},7:{"id":"7","name":"ΠΕΙΡΑΙΑΣ","vorder":null},16:{"id":"16","name":"ΗΡΑΚΛΕΙΟ","vorder":null},17:{"id":"17","name":"ΡΕΘΥΜΝΟ","vorder":null},18:{"id":"18","name":"ΛΑΡΙΣΑ","vorder":null},19:{"id":"19","name":"ΒΟΛΟΣ","vorder":null},22:{"id":"22","name":"ΙΩΑΝΝΙΝΑ","vorder":null},30:{"id":"30","name":"ΚΑΒΑΛΑ","vorder":null},50:{"id":"50","name":"ΣΕΡΡΕΣ","vorder":null},71:{"id":"71","name":"KOMOTHNH","vorder":null},92:{"id":"92","name":"ΧΑΙΔΑΡΙ","vorder":null},153:{"id":"153","name":"ΚΟΛΛΙΝΕΣ ΑΡΚΑΔΙΑΣ","vorder":null}};
var filters = { dates: {}, areas: {}, venues: {}, text: '' };
// Αντικαθιστώ την window.upperGreeklish στο functions.new.js που είναι UTF-8
window.upperGreeklish = function upperGreeklish(s)
{
if(!s) return "";
SSGreek = 'ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩΆ¶ΈΉΊΌΎΏΪΫαβγδεζηθικλμνξοπρσςτυφχψωάέήίόύώϊϋΐΰ';
SSEnglish = 'ABGDEZH8IKLMN3OPRSTYFXCWAAEHIOYWIYABGDEZH8IKLMN3OPRSSTYFXCWAEHIOYWIYIY';
SPass1 = ['OY', 'PS', 'CH', 'PH', 'TH', 'SS', 'KS', 'NN', 'MM', 'PH', 'LL', 'AY', 'EY', 'W', 'H', 'Y', 'V'];
SPass2 = ['OU', 'C', 'X', 'F', '8', 'S', '3', 'N', 'M', 'F', 'L', 'AB', 'EB', 'O', 'I', 'I', 'B'];
s = s.toUpperCase();
var ret = "";
var slen = s.length;
for(var i=0; i < slen; i++)
{
var c = s.substr(i, 1);
var j = SSGreek.indexOf(c);
if(j !== -1)
{
ret += SSEnglish.substr(j, 1);
}
else
{
ret += c;
}
}
// και τώρα τα διπλά
for(var i = 0; i < SPass1.length; i++) {
ret = ret.replaceAll(SPass1[i], SPass2[i]);
}
return ret;
}
$(function() {
readEvents();
if(window['useeventfilters']) {
createFilters();
}
createSearch()
initFilterDOMEvents();
});
function readEvents() {
var lis = $('#events\_list li');
lis.each(function() {
var li = $(this);
var eventid = li.attr('data-eventid') >> 0;
var eventtitle = li.attr('data-title');
var eventkeywords\_fixed = li.attr('data-keywords\_fixed');
var eventvenues = li.attr('data-venues');
var eventareas = li.attr('data-areas');
var eventdates = li.attr('data-dates');
var evgroupid = li.attr('data-evgroupid') >> 0;
if(eventid) {
var eventvenues = eventvenues.split('|');
var eventareas = eventareas.split('|');
var eventdates = eventdates.split('|');
var eventhallids = li.attr('data-hallids').split(',');
var eventvenueids = li.attr('data-venueids').split(',');
var eventareaids = li.attr('data-areaids').split(',');
var eventshorttext = $('#eventshortext\_' + eventid).text() || '';
if(!events[eventid]) {
eventids.push(eventid);
events[eventid] = { id: eventid, title: eventtitle, hallids: eventhallids, venueids: eventvenueids, areaids: eventareaids
, search: upperGreeklish(eventtitle + ' ' + eventshorttext) + ' ' + eventkeywords\_fixed };
}
for(var i = 0; i < eventvenueids.length; i++) {
var venueid = eventvenueids[i];
var venue = venues[venueid];
if(!venue) continue;
if(!venue['eventids']) { venue.eventids = [], venue.eventids\_ = {} };
if(!venue.eventids\_[eventid]) {
venue.eventids\_[eventid] = eventid;
venue.eventids.push(eventid);
}
}
for(var i = 0; i < eventhallids.length; i++) {
var hallid = eventhallids[i];
var hall = halls[hallid];
if(!hall) continue;
if(!hall['eventids']) { hall.eventids = [], hall.eventids\_ = {} };
if(!hall.eventids\_[eventid]) {
hall.eventids\_[eventid] = eventid;
hall.eventids.push(eventid);
}
}
for(var i = 0; i < eventareaids.length; i++) {
var areaid = eventareaids[i];
var area = areas[areaid];
if(!area) continue;
if(!area['eventids']) { area.eventids = [], area.eventids\_ = {} };
if(!area.eventids\_[eventid]) {
area.eventids\_[eventid] = eventid;
area.eventids.push(eventid);
}
}
for(var i = 0; i < eventdates.length; i++) {
var eventdate = eventdates[i];
if(!eventdate) continue;
if(!dates[eventdate]) {
dates[eventdate] = { date: eventdate, eventids\_: {}, eventids: [] };
}
if(!dates[eventdate].eventids\_[eventid]) {
dates[eventdate].eventids\_[eventid] = eventid;
dates[eventdate].eventids.push(eventid);
}
}
} else if(evgroupid) {
if(!evgroups[evgroupid]) {
var evgrouptitle = eventtitle; // όπως διαβάστηκε στο <li>
var evgroupsearch = upperGreeklish(li.text());
evgroupids.push(evgroupid);
evgroups[evgroupid] = { id: evgroupid, title: evgrouptitle, search: evgroupsearch };
}
}
});
for(var venueid in venues) {
var venue = venues[venueid];
venue.search = upperGreeklish(venue.name);
if(venue.eventids\_) for(var eventid in venue.eventids\_) {
var event = events[eventid];
event.search += ' ' + venue.search;
}
}
for(var hallid in halls) {
var hall = halls[hallid];
hall.search = upperGreeklish(hall.name);
if(hall.eventids\_) for(var eventid in hall.eventids\_) {
var event = events[eventid];
event.search += ' ' + hall.search;
}
}
for(var areaid in areas) {
var area = areas[areaid];
area.search = upperGreeklish(area.name);
if(area.eventids\_) for(var eventid in area.eventids\_) {
var event = events[eventid];
event.search += ' ' + area.search;
}
}
}
function createSearch() {
var html = "";
html += ""
+ "<div id='searchtextwrap' class='searchtextwrap'>"
+ " <input type='search' id='searchtext' class='searchtext' value='' placeholder='" + (lang == 'en' ? 'Search for an event' : 'Αναζήτηση εκδήλωσης') + "'>"
+ " <a href='javascript:;' class='btnclearsearchtext'>X</a>"
+ "</div>"
+ "";
$('#events\_list').before(html);
}
function createFilters() {
var html = "";
var hidenondatefilters = window['useonlydatefilters'] == 1 ? ' display: none; ' : '';
html += ""
+ "<div id='filterstopbuttons' class='filterstopbuttons'>"
+ " <div class='fltbuttonwrap' data-divid='datesfilterwrap'>"
+ " <a href='javascript:;' class='filterstoggler'><span class='label'>" + (lang == 'en' ? 'Dates' : 'Ημερομηνίες') + "</span> <span class='arrow'></span></a>"
+ " </div>"
+ " <div class='fltbuttonwrap' data-divid='areasfilterwrap' style='" + hidenondatefilters + "'>"
+ " <a href='javascript:;' class='filterstoggler'><span class='label'>" + (lang == 'en' ? 'Areas' : 'Περιοχές') + "</span> <span class='arrow'></span></a>"
+ " </div>"
+ " <div class='fltbuttonwrap' data-divid='venuesfilterwrap' style='" + hidenondatefilters + "'>"
+ " <a href='javascript:;' class='filterstoggler'><span class='label'>" + (lang == 'en' ? 'Venues' : 'Χώροι') + "</span> <span class='arrow'></span></a>"
+ " </div>"
+ "</div>"
+ "<div id='filterssections' class='filterssections'>"
+ " <div id='datesfilterwrap' class='datefilterswrap filterswrap'>"
+ " <div id='dbuttons' class='dbuttons'>"
+ " </div>"
+ " <div id='cal' class='cal'>"
+ " </div>"
+ " </div>"
+ " <div id='venuesfilterwrap' class='venuesfilterwrap filterswrap'>"
+ " <div id='venuesfilter' class='venuesfilter filtersdiv'>"
+ " </div>"
+ " </div>"
+ " <div id='areasfilterwrap' class='areasfilterwrap filterswrap'>"
+ " <div id='areasfilter' class='areasfilter filtersdiv'>"
+ " </div>"
+ " </div>"
+ "</div>"
+ "<div id='selectedfilters' class='selectedfilters'>"
+ "</div>"
;
var divfilters = $('#filters');
if(!divfilters.length) {
// var page = $('#pagedata > .page:first');
// page.append("<div id='filters' class='filters'></div>");
$('#events\_list').before("<div id='filters' class='filters'></div>");
}
var divfilters = $('#filters');
divfilters.html(html);
createDateButtons();
createCalendar();
createVenuesFilter();
createAreasFilter();
}
function createDateButtons() {
var dbuttons = [];
var today = moment();
// find last date of events
var last = '';
for(var d in dates) if(d > last) last = d;
if(!last) last = today.format('YYYY-MM-DD');
last = moment(last);
var lastOfLastMonth = last.clone().endOf('month');
for(var i = 0; i < 7; i++) {
var date = moment().add(i, 'day');
var sdate = date.format('YYYY-MM-DD');
var wday = date.format('dddd');
var wdate = date.format('DD/MM');
var descr = '';
if(lang == 'el') {
descr = i == 0 ? 'Σήμερα' : (i == 1 ? 'Αύριο' : (i == 2 ? 'Μεθαύριο' : ('Σε ' + i + ' ημέρες')));
} else {
descr = i == 0 ? 'Today' : (i == 1 ? 'Tomorrow' : ('In ' + i + ' days'));
}
var dayclasses = [];
if(date.isBefore(today, 'date')) dayclasses.push('past');
if(date.isSame(today, 'date')) dayclasses.push('today');
if(date.isSame(last, 'date')) dayclasses.push('last');
if(date.isAfter(last, 'date')) dayclasses.push('afterlast');
var dateevents = 0;
var datef = date.format('YYYY-MM-DD');
var d = dates[datef];
if(d && d.eventids) {
dateevents = d.eventids.length;
}
if(!dateevents) dayclasses.push('noevents');
dayclasses = dayclasses.join(' ');
dbuttons.push(""
+ " <li id='filter-date-" + sdate + "' class='filter date " + dayclasses + "' data-date='" + sdate + "' data-events='" + dateevents + "'>"
+ " <a href='javascript:;'>"
+ " <label class='descr'>" + descr + "</label>"
+ " <label class='day'>" + wday + "</label>"
+ " <label class='date'>" + wdate + "</label>"
+ " <div class='btnremove'>X</div>"
+ " </a>"
+ " </li>");
}
dbuttons.push(""
+ " <li class='filter toggle\_calendar'>"
+ " <a href='javascript:;'>"
+ " <label class='descr'>&nbsp;</label>"
+ " <label class='day'>" + (lang == 'en' ? 'Calendar...' : 'Ημερολόγιο...') + "</label>"
+ " <label class='date'>&nbsp;</label>"
+ " <div class='btnremove'>X</div>"
+ " </a>"
+ " </li>");
var html = ""
+ "<ul class='dates'>"
+ dbuttons.join('')
+ "</ul>";
$('#dbuttons').html(html);
}
function countObjectItems(o) {
if(!o) return 0;
var ret = 0;
for(var item in o) ret++;
return ret;
}
function createAreasFilter() {
var html = "";
html += ""
+ "<div class='areaswrap' id='areaswrap'>"
;
for(var i = 0; i < areaids.length; i++) {
var areaid = areaids[i];
var area = areas[areaid];
html += ""
+ "<div class='area' data-areaid='" + areaid + "' id='area" + areaid + "'>"
+ " <a href='javascript:;' class='areaname'>"
+ " " + area.name
+ " <div class='btnremove'>X</div>"
+ " </a>"
+ "</div>"
;
}
html += ""
+ "</div>";
$('#areasfilter').html(html);
}
function createVenuesFilter() {
var html = "";
var halllist = [];
for(var hallid in halls) halllist.push(halls[hallid]);
halllist.sort(
// function(h1, h2) {
// var ret = (
function(h1, h2) {
var v1 = venues[h1.venueid] || { id: h1.venueid >> 0, name: '???', areaid: 0, eventids: [] };
var v2 = venues[h2.venueid] || { id: h2.venueid >> 0, name: '???', areaid: 0, eventids: [] };
var a1 = areas[v1.areaid] || { id: v1.areaid >> 0, name: '???', vorder : 0 };
var a2 = areas[v2.areaid] || { id: v2.areaid >> 0, name: '???', vorder : 0 };
var ret = ((a1.vorder >> 0) ? (a1.vorder >> 0) : (a1.id >> 0)) - ((a2.vorder >> 0) ? (a2.vorder >> 0) : (a2.id >> 0));
if(ret != 0) return ret;
ret = -(v1.eventids.length - v2.eventids.length);
if(ret != 0) return ret;
ret = (v1.vorder >> 0) - (v2.vorder >> 0);
if(ret != 0) return ret;
ret = (v1.id >> 0) - (v2.id >> 0);
if(ret != 0) return ret;
ret = (h1.vorder >> 0) - (h2.vorder >> 0);
if(ret != 0) return ret;
ret = (h1.id >> 0) - (h2.id >> 0);
if(ret != 0) return ret;
return 0;
// }
// )(h1, h2);
// return ret;
}
);
html += ""
+ "<div class='venueswrap' id='venueswrap'>"
+ " <div class='title'>"
+ " <input id='searchvenues' class='searchvenues' type='search' placeholder='" + (lang == 'en' ? 'Search venue name' : 'Αναζήτηση χώρου') + "'> <a href='javascript:;' class='btnclearsearchvenues'>X</a>"
+ " </div>"
+ " <div class='venues'>"
;
var currentareaid = -1;
for(var i = 0; i < halllist.length; i++) {
var hall = halllist[i];
var venue = venues[hall.venueid];
var areaid = venue.areaid;
var area = areas[areaid] || { id: areaid, name: '' };
if(venue.name == hall.name) {
var venuehallname = venue.name;
} else {
var venuehallname = venue.name + ' - ' + hall.name;
}
if(areaid != currentareaid) {
if(currentareaid != -1) {
html += "</div></div>"; // div.areavenues div.area
}
currentareaid = areaid;
html += "<div class='area' data-areaid='" + areaid + "' id='areasection" + areaid + "'>"
+ "<div class='name' id='venuearea" + areaid + "'>"
+ area.name
+ "</div>"
+ "<div class='areavenues area" + areaid + "' id='venuesofarea" + areaid + "'>"
}
html += "<div class='venue hall area" + areaid + "' data-venueid='" + venue.id + "' data-hallid='" + hall.id + "' id='hall" + hall.id + "'>"
+ "<a class='venuename' href='javascript:;'>" + venuehallname + " <div class='btnremove'>X</div></a>"
+ "</div>";
}
html += ""
+ "</div></div>" // div.areavenues div.area
+ "</div>" // div.venues
+ "<div class='clear'></div>"
+ "</div>" // div.venueswrap;
+ "<div class='clear'></div>"
$('#venuesfilter').html(html);
}
function initFilterDOMEvents() {
$(document).on('click', '.filters li.date a, .filters .cal .date a', function clicked\_filter\_date(e) {
e.preventDefault();
var a = $(this);
var item = a.closest('.date');
if(item.hasClass('past')) return ;
var date = item.attr('data-date');
setFilterDateChecked(date, !item.hasClass('checked'), e.ctrlKey);
});
$(document).on('click', '.filters li.toggle\_calendar a', function(e) {
e.preventDefault();
var a = $(this);
var li = a.closest('li');
if(li.hasClass('checked')) {
li.removeClass('checked');
$('#cal').slideUp('fast');
} else {
li.addClass('checked');
$('#cal').slideDown('fast');
}
});
$(document).on('click', 'div.area a.areaname', function(e) {
e.preventDefault();
var a = $(this);
var area = a.closest('div.area');
var areaid = area.attr('data-areaid');
var checked = area.hasClass('checked');
setFilterAreaChecked(areaid, !area.hasClass('checked'), e.ctrlKey);
});
$(document).on('click', '.venueswrap div.venue a.venuename', function(e) {
e.preventDefault();
var a = $(this);
var hall = a.closest('div.venue');
var hallid = hall.attr('data-hallid');
var checked = hall.hasClass('checked');
setFilterHallChecked(hallid, !hall.hasClass('checked'), e.ctrlKey);
});
$(document).on('input', 'input.searchvenues', function(e) {
searchVenues();
});
$(document).on('keydown', '.searchvenues', function(e) {
if(e.originalEvent.keyCode == 27) {
clearSearchVenues();
}
});
$(document).on('click', '.btnclearsearchvenues', function(e) {
e.preventDefault();
clearSearchVenues();
});
$(document).on('input', 'input.searchtext', function(e) {
searchText();
});
$(document).on('keydown', '.searchtext', function(e) {
if(e.originalEvent.keyCode == 27) {
clearSearchText();
}
});
$(document).on('click', '.btnclearsearchtext', function(e) {
e.preventDefault();
clearSearchText();
});
$(document).on('click', '.filterstopbuttons .fltbuttonwrap a.filterstoggler', function(e) {
e.preventDefault();
var a = $(this);
var additive = e.ctrlKey;
var buttonwrap = a.closest('.fltbuttonwrap');
var filterswrapid = buttonwrap.attr('data-divid');
var filterswrap = $('#' + filterswrapid);
var expanded = buttonwrap.hasClass('expanded');
if(expanded) {
filterswrap.slideUp('fast', function() {
filterswrap.removeClass('expanded');
buttonwrap.removeClass('expanded');
filterswrap.css('display', '');
});
} else {
if(!additive) {
// Θέλω να κλείσει πρώτα τυχόν άλλο ανοιχτό div φίλτρων και μετά να ανοίξει αυτό.
// Θα κάνω τα animations παράλληλα, για να μην κάθομαι τώρα να κοιτάω πότε κλείνει το ένα, για να αρχίσω να ανοίγω το άλλο κτλ
var others = $('#filterstopbuttons .fltbuttonwrap.expanded').not(buttonwrap);
others.each(function() {
var buttonwrap = $(this);
var filterswrapid = buttonwrap.attr('data-divid');
var filterswrap = $('#' + filterswrapid);
filterswrap.fadeOut('fast', function() {
filterswrap.removeClass('expanded');
buttonwrap.removeClass('expanded');
filterswrap.css('display', '');
});
});
}
filterswrap.slideDown('fast', function() {
filterswrap.addClass('expanded');
buttonwrap.addClass('expanded');
filterswrap.css('display', '');
});
}
});
$(document).on('click', '.selectedfilters .filter a', function(e) {
e.preventDefault();
var a = $(this);
var div = a.closest('div');
if(div.hasClass('datefilter')) {
var value = div.attr('data-date');
div.fadeOut('fast', function() {
div.remove();
setFilterDateChecked(value, false);
});
} else if(div.hasClass('hallfilter')) {
var value = div.attr('data-hallid');
div.fadeOut('fast', function() {
div.remove();
setFilterHallChecked(value, false);
});
} else if(div.hasClass('areafilter')) {
var value = div.attr('data-areaid');
div.fadeOut('fast', function() {
div.remove();
setFilterAreaChecked(value, false);
});
}
});
$(document).on('click', '.btnclearfilters', function(e) {
e.preventDefault();
clearFilters();
clearSearchText();
});
}
var searchVenuesDelay = 0;
function searchVenues(s, doitnow) {
clearTimeout(searchVenuesDelay);
if(!doitnow) {
searchVenuesDelay = setTimeout(function() {
searchVenues(s, true);
}, 300);
return ;
}
if(!s) s = $('#searchvenues').val();
if(!s) {
$('#venueswrap').removeClass('hassearch').find('div.venue').removeClass('searchmatch');
$('#venueswrap .area .name').removeClass('searchmatch');
return ;
}
var sgu = upperGreeklish(s);
var foundhallids = {};
var foundareaids = {};
for(var hallid in halls) {
var hall = halls[hallid];
var venue = venues[hall.venueid];
var area = areas[venue.areaid];
if(
(hall.search && hall.search.indexOf(sgu) > -1)
|| (venue.search && venue.search.indexOf(sgu) > -1)
|| (area.search && area.search.indexOf(sgu) > -1)
) {
foundhallids[hallid] = hallid;
foundareaids[area.id] = area.id;
}
}
$('#venueswrap div.venue').removeClass('searchmatch');
$('#venueswrap div.area div.name').removeClass('searchmatch');
for(var hallid in foundhallids) {
$('#hall' + hallid).addClass('searchmatch');
}
for(var areaid in foundareaids) {
$('#venuearea' + areaid).addClass('searchmatch');
}
$('#venueswrap').addClass('hassearch');
}
function clearSearchVenues() {
$('#searchvenues').val('').focus();
searchVenues('', true);
}
var searchTextDelay = 0;
function searchText(s, doitnow) {
clearTimeout(searchTextDelay);
if(!doitnow) {
searchTextDelay = setTimeout(function() {
searchText(s, true);
}, 300);
return ;
}
if(!s) s = $('#searchtext').val();
if(!s) {
$('body:first').removeClass('hassearchtext');
$('#events\_list li').removeClass('searchtextmatch');
return ;
}
// Αίτημα από την παραγωγή της παράστασης "8" - όταν κάποιος γράφει 8 να εμφανίζεται η παράσταση (τώρα εμφανίζονται πάρα πολλές λόγω 8 ==> th (θήτα))
if(s == '8') {
dlog('8 ==> «8»');
s = '«8»';
}
var sgu = upperGreeklish(s);
$('#events\_list li').removeClass('searchtextmatch');
for(var eventid in events) {
var event = events[eventid];
if(event.search && event.search.indexOf(sgu) > -1) {
$('#ev' + eventid).addClass('searchtextmatch');
}
}
for(var evgroupid in evgroups) {
var evgroup = evgroups[evgroupid];
if(evgroup.search && evgroup.search.indexOf(sgu) > -1) {
$('#ev-' + evgroupid).addClass('searchtextmatch');
}
}
$('body:first').addClass('hassearchtext');
}
function clearSearchText() {
$('#searchtext').val('').focus();
searchText('', true);
}
function setFilterDateChecked(dates\_to\_check\_uncheck, checked, additive) { // dates\_to\_check\_uncheck: 'YYYY-MM-DD' ή [date1, date2, date3]
if(!dates\_to\_check\_uncheck) {
filters.dates = {};
$('#filters li.date.checked').removeClass('checked');
$('#cal span.date.checked').removeClass('checked');
applyFilters();
return ;
}
if(typeof dates\_to\_check\_uncheck == 'string') {
dates\_to\_check\_uncheck = [dates\_to\_check\_uncheck];
}
if(checked && !additive) filters.dates = {};
for(var i = 0; i < dates\_to\_check\_uncheck.length; i++) {
if(checked) {
filters.dates[dates\_to\_check\_uncheck[i]] = dates\_to\_check\_uncheck[i];
} else {
delete filters.dates[dates\_to\_check\_uncheck[i]];
}
}
$('#filters li.date.checked').removeClass('checked');
$('#cal span.date.checked').removeClass('checked');
for(var date in filters.dates) {
$('#filter-date-' + date).addClass('checked');
$('#cal-date-' + date).addClass('checked');
}
applyFilters();
}
function setFilterAreaChecked(areaid, checked, additive) {
if(typeof areaid == "undefined") {
filters.areas = {};
filters.halls = {};
$('#filters .hall').removeClass('checked');
$('#filters .area').removeClass('checked');
applyFilters();
return ;
}
if(checked && !additive) filters.areas = {};
if(checked) {
filters.areas[areaid] = areaid;
} else {
delete filters.areas[areaid];
}
// και θέλω να αφαιρεθούν από τα φίλτρα αιθουσών όσες αίθουσες ΔΕΝ ανήκουν στα επιλεγμένα areas
// if(checked) {
var hh = {};
for(var hallid in filters.halls) {
var hall = halls[hallid];
if(!hall) continue;
var venue = venues[hall.venueid];
if((venue.areaid in filters.areas)) hh[hallid] = hallid;
}
filters.halls = hh;
// }
$('#filters .area').removeClass('checked');
for(var areaid in filters.areas) {
$("#area" + areaid).addClass('checked');
}
$('#filters .hall').removeClass('checked');
for(var hallid in filters.halls) {
$("#hall" + hallid).addClass('checked');
}
applyFilters();
}
function setFilterHallChecked(hallid, checked, additive) {
if(typeof hallid == "undefined") {
filters.halls = {};
$('#filters .hall').removeClass('checked');
applyFilters();
return ;
}
if(checked && !additive) filters.halls = {};
if(checked) {
filters.halls[hallid] = hallid;
} else {
delete filters.halls[hallid];
}
$('#filters .hall').removeClass('checked');
for(var hallid in filters.halls) {
$("#hall" + hallid).addClass('checked');
}
applyFilters();
}
function createCalendar() {
if(createCalendar.built) return ;
createCalendar.built = true;
var html = "";
var today = moment();
var date = today.clone().startOf('month');
// find last date of events
var last = '';
for(var d in dates) if(d > last) last = d;
if(!last) last = today.format('YYYY-MM-DD');
last = moment(last);
var lastOfLastMonth = last.clone().endOf('month');
var currentmonth = -1;
var currentweekday = -1;
while(date.isBefore(lastOfLastMonth)) {
var month = date.month(); // 0 = january
// var weekday = date.weekday(); // 0 = monday
var weekday = (date.isoWeekday() - 1) % 7;
if(month != currentmonth) {
if(currentmonth == -1) {
html += ""
+ "<div class='month'>"
+ " <div class='name'>" + date.format('MMMM YYYY') + "</div>"
+ " <div class='weekdays'>"
+ lang\_elen(" <span>Δ</span><span>Τ</span><span>Τ</span><span>Π</span><span>Π</span><span>Σ</span><span>Κ</span>"
, " <span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span><span>S</span>")
+ " </div>"
+ " <div class='week'>"
} else {
html += ""
+ " </div>" // div.week
+ "</div>" // div.month
+ "<div class='month'>"
+ " <div class='name'>" + date.format('MMMM YYYY') + "</div>"
+ " <div class='weekdays'>"
+ lang\_elen(" <span class='day'>Δ</span><span class='day'>Τ</span><span class='day'>Τ</span><span class='day'>Π</span><span class='day'>Π</span><span class='day'>Σ</span><span class='day'>Κ</span>"
, " <span class='day'>M</span><span class='day'>T</span><span class='day'>W</span><span class='day'>T</span><span class='day'>F</span><span class='day'>S</span><span class='day'>S</span>")
+ " </div>"
+ " <div class='week'>"
}
currentmonth = month;
for(var i = 0; i < weekday; i++) {
html += "<span class='space'>&nbsp;</span>";
}
} else {
if(weekday < currentweekday) {
html += ""
+ "</div>" // week
+ "<div class='week'>";
}
}
var dayclasses = [];
if(date.isBefore(today, 'date')) dayclasses.push('past');
if(date.isSame(today, 'date')) dayclasses.push('today');
if(date.isSame(last, 'date')) dayclasses.push('last');
if(date.isAfter(last, 'date')) dayclasses.push('afterlast');
var dateevents = 0;
var datef = date.format('YYYY-MM-DD');
var d = dates[datef];
if(d && d.eventids) {
dateevents = d.eventids.length;
}
if(!dateevents) dayclasses.push('noevents');
dayclasses = dayclasses.join(' ');
html += "<span class='day date " + dayclasses + "' id='cal-date-" +datef + "' data-date='" + datef + "' data-events='" + dateevents + "'><a href='javascript:;' data-date='" + date.format('YYYY-MM-DD') + "'>" + date.format('D') + "</a></span>"
currentweekday = weekday;
date.add(1, 'day');
}
html += ""
+ " </div>" // week
+ "</div>" // month
;
$('#cal').html(html);
}
function clearFilters() {
// filters.dates = {};
// filters.areas = {};
// filters.venues = {};
// filters.text = '';
// applyFilters();
setFilterHallChecked();
setFilterDateChecked();
setFilterAreaChecked();
clearSearchText();
}
var applyFiltersDelay = 0;
function applyFilters(doitnow) {
clearTimeout(applyFiltersDelay);
if(!doitnow) {
applyFiltersDelay = setTimeout(function() {
applyFilters(true);
}, 300);
return ;
}
var atleastonefilter = false;
var eventids\_matched\_dates = {};
var eventids\_matched\_areas = {};
var eventids\_matched\_halls = {};
var html = "";
for(var d in filters.dates) {
atleastonefilter = true;
var date = dates[d];
if(date) {
for(var eventid in date.eventids\_) {
eventids\_matched\_dates[eventid] = eventid;
}
var md = moment(d).format('dd DD/MM/YY');
html += "<div class='filter datefilter' data-date='" + d + "'><a href='javascript:;' class='btnfilter'>" + md + "<div class='btnremove'></div></a></div>";
}
}
var vareaids = [];
for(var areaid in filters.areas) {
atleastonefilter = true;
var area = areas[areaid];
if(area) {
vareaids.push(areaid);
for(var eventid in area.eventids\_) {
eventids\_matched\_areas[eventid] = eventid;
}
html += "<div class='filter areafilter' data-areaid='" + areaid + "'><a href='javascript:;' class='btnfilter'>" + area.name + "<div class='btnremove'></div></a></div>";
}
}
if(vareaids.length) {
var vw = $('#venueswrap');
var divs = $('#venueswrap div.area');
divs.removeClass('infilter');
for(var i = 0; i < vareaids.length; i++) {
var areaid = vareaids[i];
$('#areasection' + areaid).addClass('infilter');
}
vw.addClass('filtered');
if(vareaids.length > 1) {
vw.addClass('multiple');
} else {
vw.removeClass('multiple');
}
} else {
$('#venueswrap').removeClass('filtered');
}
for(var hallid in filters.halls) {
atleastonefilter = true;
var hall = halls[hallid];
for(var eventid in hall.eventids\_) {
eventids\_matched\_halls[eventid] = eventid;
}
var venue = venues[hall.venueid] || { name: hall.name };
if(venue.name == hall.name) {
var venuehallname = venue.name;
} else {
var venuehallname = venue.name + ' - ' + hall.name;
}
html += "<div class='filter hallfilter' data-hallid='" + hallid + "'><a href='javascript:;' class='btnfilter'>" + venuehallname + "<div class='btnremove'></div></a></div>";
}
var eventscount = 0;
if(atleastonefilter) {
var eventids\_matched = {};
var has\_dates = !$.isEmptyObject(eventids\_matched\_dates);
var has\_areas = !$.isEmptyObject(eventids\_matched\_areas);
var has\_halls = !$.isEmptyObject(eventids\_matched\_halls);
for(eventid in events) {
if(has\_dates && !eventids\_matched\_dates[eventid]) continue;
if(has\_areas && !eventids\_matched\_areas[eventid]) continue;
if(has\_halls && !eventids\_matched\_halls[eventid]) continue;
eventids\_matched[eventid] = eventid;
}
$('body:first').addClass('filtered');
var lis = $('#events\_list li');
lis.removeClass('filtermatch');
for(var eventid in eventids\_matched) {
$('#ev' + eventid).addClass('filtermatch');
eventscount++;
}
} else {
$('#events\_list li').removeClass('filtermatch')
$('body').removeClass('filtered');
}
if(html) {
var chtml = '';
var cclass = '';
if(eventscount > 0) {
chtml = lang == 'en' ? ('Events found for the above criteria: <b>' + eventscount + '</b>') : ('Παραστάσεις/Θεάματα που πληρούν τα παραπάνω κριτήρια: <b>' + eventscount + '</b>');
cclass = 'found';
} else {
chtml = lang == 'en' ? ('No events found for the above criteria') : ('Δεν βρέθηκαν παραστάσεις/Θεάματα τα οποία πληρούν τα παραπάνω κριτήρια');
cclass = 'notfound';
}
var cancelhtml = lang == 'en' ? 'Clear filters' : 'Ακύρωση φίλτρων';
cancelhtml = "<span class='sclearfilters'><a href='javascript:;' class='btnclearfilters'>" + cancelhtml + "</a></span>";
html = ""
+ "<div class='label'>" + (lang == 'en' ? 'Search criteria' : 'Κριτήρια αναζήτησης παραστάσεων') + ":</div>"
+ "<div class='activefilters'>"
+ html
+ "</div>"
+ "<div class='result " + cclass + "'>"
+ " <span class='resultmsg'>" + chtml + "</span>" + cancelhtml
+ "</div>";
var div = $('#selectedfilters');
if(div.hasClass('hasfilters')) {
div.html(html).addClass('hasfilters');
} else {
div.html(html).slideDown('fast', function() {
div.addClass('hasfilters');
div.css('display', '');
});
}
} else {
var div = $('#selectedfilters');
div.slideUp('fast', function() {
div.html('');
div.removeClass('hasfilters');
div.css('display', '');
});
}
}

##### ΕΠΙΚΟΙΝΩΝΙΑ

**TICKET SERVICES**  
ΥΠΗΡΕΣΙΑ ΕΙΣΙΤΗΡΙΩΝ - ΛΟΓΙΣΜΙΚΗ ΕΠΕ  
Τηλεφωνικό κέντρο: [**210 7234567**](tel:(+30)2107234567)  
e-mail: [info@ticketservices.gr](mailto:info@ticketservices.gr)  
Εκδοτήριο: Πανεπιστημίου 39 (Στοά Πεσμαζόγλου), Αθήνα [![](https://stream.ticketservices.gr/www.ticketservices.gr/images/button-gmaps.png)](http://goo.gl/maps/cnVA "χάρτης")  
Ώρες λειτουργίας εκδοτηρίου: Δευ-Παρ: 9πμ-5μμ  
[![](https://stream.ticketservices.gr/www.ticketservices.gr/images/button-facebook.png)](https://www.facebook.com/TicketServicesGr)

[![](https://stream.ticketservices.gr/www.ticketservices.gr/images/button-instagram.png)](https://www.instagram.com/ticketservices.gr/)

[Ticketing System by TicketServices.gr](https://www.ticketservices.gr)

.cookieprefs { display: none; position: fixed; bottom: 0; left: 0; right: 0; background-color: rgb(100,100,100); color: #fff; padding: 1rem; text-align: center; }
.cookieprefs .notes { display: inline-block; font-size: 1rem; margin: 0 1rem; text-align: left; max-width: 58%; vertical-align: top;}
.cookieprefs .notes a { color: #FBEC0B; text-decoration: underline; }
.cookieprefs .buttons { display: inline-block; margin: 0 1rem; vertical-align: top;}
.cookieprefs .buttons .btn { margin: 0.5rem; display: inline-block; padding: 10px; background-color: #F28715; color: #fff; border-radius: 10px; font-size: 1rem; text-decoration: none; }

Μας επιτρέπετε να αποθηκεύουμε στον φυλλομετρητή σας τα λεγόμενα cookies; Με αυτόν τον τρόπο θα καταγράφονται από εμάς και τρίτες συνεργαζόμενες εταιρείες (Google, Facebook κτλ) στοιχεία επισκεψιμότητας για στατιστικούς αλλά και διαφημιστικούς λόγους. Μπορείτε να διαβάσετε περισσότερα για την χρήση cookies από την ιστοσελίδα μας [εδώ](/el/cookies/).

[Ναι, επιτρέπω](javascript:;)
[Όχι, δεν επιτρέπω](javascript:;)

var cookieprefs = {"mandatory":1,"analytics":1,"advertising":0,"user\_has\_selected":0};
$(function() {
$('#cookieprefs').fadeIn('fast');
});
function openCookiePrefs() {
$('#cookieprefs').fadeIn('fast');
}
function clearCookiePrefs() {
jajax('setcookieprefs', { cookiechoice: 'clearchoice'}, function(result) {
// don't care about result for the moment
alert('OK');
});
}
$(function() {
$(document).on('click', '.cookieprefs .btn', function(e) {
e.preventDefault();
var a = $(this);
var choice = a.attr('data-choice');
$('#cookieprefs').fadeOut('slow');
jajax('setcookieprefs', { cookiechoice: choice}, function(result) {
// don't care about result for the moment
});
});
$(document).on('click', '.opencookieprefs', function(e) {
e.preventDefault();
openCookiePrefs();
});
});

$(document).ready(function() {
$('#login\_email').keyup(function(event){
var keycode = (event.keyCode ? event.keyCode : event.which);
if(keycode == 13) $('#login\_password').focus();
});
$('#login\_password').keypress(function(event){
var keycode = (event.keyCode ? event.keyCode : event.which);
if(keycode == 13) document.login.submit();
});
$('#searchboxbtn').show().click(function(){
var sb = $('#searchboxwrap');
if(sb.is(':visible'))
{
closeSearch();
}
else
{
sb.slideDown('fast', function() { $('#searchbox').focus();});
$('#searchbox').val('');
}
});
$('#searchboxclosebtn').click(function(){
closeSearch();
});
$('#searchbox').on('click', function() {
$('#searchnotes').show();
});
initSearchField();
$('li.article\_' + window.articleid).addClass('selected');
});

.list div#main { width: 90%; max-width: 1500px; margin: 0 auto; }
ul#events\_list { display: flex; flex-wrap: wrap; justify-content: center; }
ul#events\_list li { display: block; margin: 2px; padding: 2px; }
ul#events\_list li a { height: auto; }

.weatherinfo {
text-align: center;
margin: 1rem auto;
max-width: 400px;
font-size: 1.2rem;
background-color: #e0e0e0;
padding: 1rem;
}
.weatherinfo a {
padding: 1rem;
display: inline-block;
}

**Πληροφορίες σχετικά με τις καιρικές συνθήκες**  
[διαβάστε εδώ](https://www.ticketservices.gr/el/weather/)

function addWeatherInfo() {
// $('#weatherinfo').insertAfter('#pagedata > h1:first');
$('#weatherinfo').insertBefore('#eventtabs');
//$('#pagedata > h1:first').remove();
}

false && $(function() {
if(window.addWeatherInfo) {
addWeatherInfo();
$('#pagedata > h1:first').remove();
}
});
.waiting\_overlay { display: none; position: fixed; z-index: 1000; background: rgba(255,255,255,0.5); top: 0; left: 0; bottom: 0; right: 0; flex-direction: column; justify-content: center; align-items: center; }
.waiting .waiting\_overlay, .waitseatcapture .waiting\_overlay, .ajax .waiting\_overlay, .reloading .waiting\_overlay { display: flex!important; }

function waiting(state) {
console.log('Set waiting state to: ', state);
$('body').toggleClass('waiting', state ? true : false);
}

![](https://stream.ticketservices.gr/www.ticketservices.gr/images/wait.gif)

.eventsnew div#searchboxwrap { display: none; }

$(function() {
var admin\_menu\_item = "\r\n\t\t\t<li class='menulink menulink\_auto menuitem\_admin\_login'><a href='javascript:;'><span class='text'>Είσοδος διαχειριστή<\/span><\/a><\/li>\r\n\t\t";
$('#topmenu\_pop').append(admin\_menu\_item);
});
$(document).on('click', '.menuitem\_admin\_login a', function(e) {
e.preventDefault();
openAdminLogin();
});
$(document).on('submit', '.adminlogin', function(e) {
e.preventDefault();
var params = {
username: $('#admin\_username').val()
, password: $('#admin\_password').val()
}
if(window.eventid >> 0) params.eventid = window.eventid >> 0;
$('#admin\_login\_msg').html('Please wait...');
jajax('adminlogin', params, function(result) {
if(result.status == 'error') {
if(result.error == 'password\_needs\_to\_be\_reset') {
dyesno(`Πρέπει να γίνει ορισμός του password. Θέλετε να σας σταλεί email με τις σχετικές οδηγίες;`
, function(response) {
if(response) {
var params2 = { username: params.username, do: 'password\_reset' };
jajax('adminlogin', params2, function(result) {
if(result.status == 'error') {
dalert(result.msg || result.error);
} else {
dalert('OK, σας έχει σταλεί email με οδηγίες')
}
});
}
});
}
$('#admin\_login\_msg').html(result.msg || result.error);
return ;
}
$('#admin\_login\_msg').html('OK');
window.location.reload();
});
});
$(document).on('input', '.adminlogin input', function(e) {
e.preventDefault();
$('#admin\_login\_msg').html('');
});
$(document).on('click', '.menuitem\_admin\_logout', function(e) {
e.preventDefault();
jajax('adminlogin', { want\_to\_logout: 1 }, function(result) {
if(result.status == 'error') {
dalert(result.msg || result.error);
return ;
}
window.location.reload();
});
});
function openAdminLogin() {
$('body').removeClass('topmenuexpanded');
var html = `
<form id='adminlogin' class='adminlogin'>
<table>
<tr><td class='label'>Όνομα χρήστη</td><td class='field'><input type='text' id='admin\_username' class='admin\_username'></td></tr>
<tr><td class='label'>Password χρήστη</td><td class='field'><input type='password' id='admin\_password' class='admin\_password'></td></tr>
<tr><td colspan=2 class='btn'><input type='submit' value='ΕΙΣΟΔΟΣ'></td></tr>
<tr><td colspan=2 class='admin\_login\_msg' id='admin\_login\_msg'></td></tr>
</table>
</form>
`;
swal.fire({
html: html
, showConfirmButton: false
, showCloseButton: true
, width: '400px'
})
}

.topmenunewgui ul li.menulink\_auto.menuitem\_admin\_login a::before { background-image: url(/images/btnsettings\_white.png); }
.topmenunewgui ul li.menulink\_auto.menuitem\_admin\_logout a::before { background-image: url(/images/btnsettings\_white.png); }
.adminlogin form {
padding: 1rem;
}
.adminlogin table { border-collapse: collapse; }
.adminlogin table tr td { padding: 0.5rem; }
.adminlogin table tr td.label { text-align: right; }
.adminlogin table tr td.field { text-align: left; }
.adminlogin table tr td.field input { width: 25ch; max-width: 80vw; }
.adminlogin table tr td.btn { text-align: right }
.adminlogin table tr td.admin\_login\_msg { text-align: right }

window.want\_warning\_on\_iris = true;